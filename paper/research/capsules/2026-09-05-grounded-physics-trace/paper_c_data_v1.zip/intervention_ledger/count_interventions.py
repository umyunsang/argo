#!/usr/bin/env python3
"""
count_interventions.py — Camera-ready Pass 3.1 analysis.

Enumerates every human-originated event in the canonical 47-session run of
run_002 (Paper C) from the session .jsonl transcripts stored inside the
session folders, and classifies them for the human-intervention table.

SCOPE
-----
Canonical sessions with on-disk traces (44 of 47):
  depth x5, pilot S1, S2, S3 x5, pilot_gate x15, pilot_reflect x2,
  pre_production x1, production x4 (init + 3 continues),
  writing x10 (run_1/2/3 x {1A,1B,full} + final polish).
The 3 breadth sessions were reused from run_001 and have no traces under
run_002 (per session_trace_inventory.md, breadth row: "reused from run_001 —
not re-run"; interventions: none by construction for the canonical run).

Scope: the canonical run sessions with archived transcripts (44 of 47; the three
breadth sessions entered the run as on-disk corpus reports). Raw transcripts are
retained in the project archive; see counting_rules_AUDIT.md.

CLASSIFICATION RULES (documented for the audit)
-----------------------------------------------
A record is a TYPED HUMAN MESSAGE iff:
  - type == "user", isSidechain != True, isMeta != True
  - message.content is a string, or a list whose blocks include a "text"
    block and no "tool_result" block
  - after stripping <system-reminder>...</system-reminder> spans, text is
    non-empty
  - text is not a command wrapper (<command-name>/<local-command-stdout>/
    <command-message>) and not an interruption marker
    ("[Request interrupted by user...]": counted separately as interrupts,
    they carry no typed words)
Special handling:
  - The FIRST typed message of each session is the initial task prompt
    (boilerplate per-stage prompt): recorded, excluded from interventions.
  - Later near-duplicates of the initial prompt (>=90% prefix match on the
    first 200 chars) are /resume re-injections: excluded, counted separately.
Categories (auto-assigned; final assignment manually audited — see
count_interventions_AUDIT.md):
  continue      ^(continue|proceed|go ahead|resume|ok|yes)\b (<=6 words)
  stop          contains kill/killall/stop (<=8 words)
  oom_status    memory/oom/gb/swap/crash observations (<=20 words)
  paywall       "continue"-like message within 3 records after an assistant
                text block requesting a human download (paywall/DOI/
                reference_papers/"ask the user" patterns) -> tagged
  rule_reminder matches arxiv/houserule correction patterns
  patch_prompt  >=100 words and structured (## Task / ### Step / Patch)
  other         everything else (manually reviewed)
Every message goes to the ledger CSV with session, timestamp, word count,
category, and a 160-char excerpt, so every row is spot-checkable against the
raw jsonl.
"""
import csv, json, os, re, sys
from pathlib import Path

RUN = Path(__file__).resolve().parents[2]  # runs/run_002
OUT = Path(__file__).resolve().parent

SESSIONS = []  # (phase, session_name, folder)
def add(phase, name, folder): SESSIONS.append((phase, name, RUN / folder))
for i in range(1, 6):
    add("depth", f"depth_{i:02d}", f"depth/depth_{i:02d}")
add("pilot_setup", "session_1_prior_work", "pilot/session_1_prior_work")
add("pilot_setup", "session_2_tooling", "pilot/session_2_tooling")
for i in range(1, 6):
    add("pilot_reproduce", f"session_3_reproduce_{i:02d}", f"pilot/session_3_reproduce_{i:02d}")
for i in range(1, 16):
    add("pilot_gate", f"pilot_gate_{i:02d}", f"pilot/pilot_gate_{i:02d}")
add("pilot_reflect", "pilot_reflect_01", "pilot/pilot_reflect_01")
add("pilot_reflect", "pilot_reflect_II_02", "pilot/pilot_reflect_II_02")
add("pre_production", "pre_production", "pre_production")
add("production", "production_all4", "production")  # 4 traces in one folder
add("writing", "run_1", "paper/run_1")
add("writing", "run_2", "paper/run_2")
add("writing", "run_3", "paper/run_3")
add("writing", "final_polish", "paper/final")

SYSREM = re.compile(r"<system-reminder>.*?</system-reminder>", re.S)
CMD = re.compile(r"<(command-name|command-message|command-args|local-command-stdout|local-command-caveat)>", re.S)
INTERRUPT = re.compile(r"^\[Request interrupted by user( for tool use)?\]?\.?$", re.S)
# Harness-injected automated content that arrives as user-role records but is
# NOT typed by the human: background-task/monitor notifications, system
# notification wrappers, hook events, queued auto-continuations.
AUTOMATED = re.compile(
    r"^\s*(<task-notification>|\[SYSTEM NOTIFICATION|<automated-reminder>|"
    r"<session-(start|end)-hook>|<background-task|<task-reminder|"
    r"This session is being continued from a previous conversation)", re.S)

PAYWALL_REQ = re.compile(
    r"(paywall|published version.{0,200}(download|DOI)|reference_papers|"
    r"ask (the )?user.{0,120}(download|PDF|DOI)|need.{0,60}(main text PDF|supplementary PDF)|"
    r"place (the|it).{0,40}(PDF|paper)|download.{0,80}(PDF|paper).{0,120}continue)",
    re.I | re.S)

def text_of(content):
    """Returns (typed_text, is_pure_tool_result).
    A user record can contain tool_result blocks AND typed text blocks
    (e.g. the human interrupts a running tool and types a message in the
    same turn): extract the text blocks in that case too."""
    if isinstance(content, str):
        return content, False
    if isinstance(content, list):
        has_tr = any(isinstance(b, dict) and b.get("type") == "tool_result" for b in content)
        tx = "\n".join(b.get("text", "") for b in content
                       if isinstance(b, dict) and b.get("type") == "text").strip()
        if has_tr and not tx:
            return "", True
        return tx, False
    return "", False

def classify(txt, words, paywall_ctx):
    low = txt.lower().strip()
    if paywall_ctx and words <= 8:
        return "paywall_fulfillment"
    if re.match(r"^(continue|proceed|go ahead|resume|ok\b|yes\b)", low) and words <= 6:
        return "continue"
    if re.search(r"\b(killall|kill|stop)\b", low) and words <= 8:
        return "stop"
    if re.search(r"\b(memory|oom|gb|swap|crash|frozen|freeze)\b", low) and words <= 20:
        return "oom_status"
    if re.search(r"(arxiv.{0,40}(not|never).{0,40}published|houserule|house rule)", low):
        return "rule_reminder"
    if words >= 100 and re.search(r"(##+ ?task|###+ ?step|patch|abort condition)", low):
        return "patch_or_plan"
    return "other"

PATCH_TEMPLATE = (RUN / "pilot/session_3_reproduce_patch_if_below_T3.md").read_text().strip()

def is_architected_patch(txt):
    """The S3 below-T3 patch is a pre-written conditional stage prompt
    (pilot/session_3_reproduce_patch_if_below_T3.md), pasted verbatim when a
    reproduction concludes below T3. It is pipeline design, human-executed —
    classified as an architected stage prompt, not an intervention."""
    import difflib
    return difflib.SequenceMatcher(None, PATCH_TEMPLATE, txt.strip()).ratio() >= 0.95

ledger, summary, wakeup_report = [], {}, []
for phase, name, folder in SESSIONS:
    traces = sorted(folder.glob("*.jsonl"))
    if not traces:
        summary.setdefault(name, {"phase": phase, "traces": 0})
        continue
    for tr in traces:
        initial_prefix, n_typed, n_interrupt, n_reinject = None, 0, 0, 0
        recent_assistant = []  # rolling last-3 assistant texts
        scheduled_prompts = set()  # prompts the agent passed to ScheduleWakeup
        with open(tr) as f:
            for line in f:
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if r.get("isSidechain"):
                    continue
                t = r.get("type")
                if t == "assistant":
                    for b in r.get("message", {}).get("content", []) or []:
                        if isinstance(b, dict) and b.get("type") == "tool_use" \
                                and "akeup" in str(b.get("name", "")):
                            scheduled_prompts.add(str(b.get("input", {}).get("prompt", "")).strip())
                    atx, _ = text_of(r.get("message", {}).get("content"))
                    if atx:
                        recent_assistant.append(atx)
                        recent_assistant = recent_assistant[-3:]
                    continue
                if t != "user":
                    continue
                if r.get("isMeta"):
                    # isMeta user records are harness-injected. The only typed-
                    # text-looking ones are agent-scheduled wake-up prompts
                    # firing back; verify each against the agent's own
                    # ScheduleWakeup calls and report any that do not match.
                    c = r.get("message", {}).get("content")
                    if isinstance(c, str):
                        tt = c.strip()
                        if tt and tt != "<<autonomous-loop-dynamic>>" \
                                and not CMD.search(tt) and not AUTOMATED.match(tt):
                            matched = tt in scheduled_prompts or any(
                                tt.startswith(s[:60]) or s.startswith(tt[:60])
                                for s in scheduled_prompts if s)
                            wakeup_report.append(dict(
                                session=name, trace=tr.name, ts=r.get("timestamp", ""),
                                matched_scheduled_wakeup=matched, excerpt=tt[:120]))
                    continue
                txt, has_tr = text_of(r.get("message", {}).get("content"))
                if has_tr:
                    continue
                txt = SYSREM.sub("", txt).strip()
                if not txt or CMD.search(txt):
                    continue
                if AUTOMATED.match(txt):
                    continue
                if INTERRUPT.match(txt):
                    n_interrupt += 1
                    continue
                if initial_prefix is None:
                    initial_prefix = txt[:200]
                    ledger.append(dict(session=name, phase=phase, trace=tr.name,
                                       ts=r.get("timestamp", ""), kind="initial_prompt",
                                       words=len(txt.split()), category="initial_prompt",
                                       excerpt=txt[:160].replace("\n", " ")))
                    continue
                if txt[:200] == initial_prefix or (len(txt) > 180 and txt[:180] == initial_prefix[:180]):
                    n_reinject += 1
                    continue
                if is_architected_patch(txt):
                    ledger.append(dict(session=name, phase=phase, trace=tr.name,
                                       ts=r.get("timestamp", ""),
                                       kind="architected_stage_prompt",
                                       words=len(txt.split()),
                                       category="architected_stage_prompt",
                                       excerpt=txt[:160].replace("\n", " ")))
                    continue
                words = len(txt.split())
                paywall_ctx = any(PAYWALL_REQ.search(a) for a in recent_assistant)
                cat = classify(txt, words, paywall_ctx)
                n_typed += 1
                ledger.append(dict(session=name, phase=phase, trace=tr.name,
                                   ts=r.get("timestamp", ""), kind="intervention",
                                   words=words, category=cat,
                                   excerpt=txt[:160].replace("\n", " ")))
        key = f"{name}:{tr.name[:8]}" if name == "production_all4" else name
        s = summary.setdefault(key, {"phase": phase, "traces": 0})
        s["traces"] = s.get("traces", 0) + 1
        s["interventions"] = s.get("interventions", 0) + n_typed
        s["interrupts"] = s.get("interrupts", 0) + n_interrupt
        s["reinjections"] = s.get("reinjections", 0) + n_reinject

with open(OUT / "interventions_ledger.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["session", "phase", "trace", "ts", "kind",
                                      "words", "category", "excerpt"])
    w.writeheader()
    w.writerows(ledger)

iv = [e for e in ledger if e["kind"] == "intervention"]
by_cat, by_phase = {}, {}
for e in iv:
    by_cat[e["category"]] = by_cat.get(e["category"], 0) + 1
    by_phase[e["phase"]] = by_phase.get(e["phase"], 0) + 1
report = {
    "total_typed_interventions_canonical_traces": len(iv),
    "by_category": by_cat,
    "by_phase": by_phase,
    "architected_stage_prompts":
        [e for e in ledger if e["kind"] == "architected_stage_prompt"],
    "isMeta_wakeup_verification": {
        "records": wakeup_report,
        "all_matched_agent_scheduled_wakeups":
            all(w["matched_scheduled_wakeup"] for w in wakeup_report),
    },
    "sessions_with_zero_interventions":
        sorted(k for k, v in summary.items()
               if v.get("traces") and not v.get("interventions")),
    "per_session": summary,
}
with open(OUT / "interventions_summary.json", "w") as f:
    json.dump(report, f, indent=2)
print(json.dumps(report, indent=2))
