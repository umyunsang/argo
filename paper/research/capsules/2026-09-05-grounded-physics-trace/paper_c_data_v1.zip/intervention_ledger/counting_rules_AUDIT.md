# Counting rules and audit — human-intervention ledger (paper Table 2)

Companion files: `count_interventions.py` (the counting script, as operated),
`intervention_events.csv` (the resulting per-event ledger). This document states the
classification rules and the audit performed on the counts published in Table 2 of the
paper. Date: 2026-07-02.

## Scope

The canonical 47-session run — the run the paper reports. 44 of the 47 sessions have
archived per-session transcripts in the project archive (raw transcripts are retained
there, not published, for sensitivity reasons); the three breadth sessions are shared
with the baseline run (paper §4) and entered the canonical run as their on-disk corpus
reports, without archived transcripts, so typed input to them is outside this count —
as stated in §3.2 of the paper.

## Classification rules (as implemented in `count_interventions.py`)

A typed human message = a user-role transcript record that is not harness-injected, whose
content is typed text, excluding:
- the per-stage boilerplate task prompt that starts each session (pipeline design);
- one pre-written conditional stage prompt — the below-T3 reproduction-extension patch,
  pasted byte-identically from its template (`prompts/session_3_reproduce_patch_if_below_T3.md`;
  difflib similarity ratio 1.0 against the pasted message) — classified as pipeline
  design per recorded operator decision (2026-07-02);
- harness-generated records: agent-scheduled wake-up prompts firing back as user-role
  records, monitor/task notifications, context-compaction summaries, /resume
  re-injections of the initial prompt, and interruption markers.

Offline curation = a transferable principle added to the curated knowledge base or house
rules between sessions following a failed reproduction (the paper's §3.2 intervention
channel).

## Result (= Table 2 of the paper)

9 typed in-session events across the 44 transcript-archived sessions, all operational:

| # | Session | UTC time | Event | Audited class |
|---|---------|----------|-------|---------------|
| 1 | session_3_reproduce_04 | 04-19 22:24 | "convergence seems plateued out" | compute-status observation |
| 2 | pilot_gate_05 | 04-24 03:31 | "continue" | paywall provisioning (Ye PRB + SM + dataset deposited) |
| 3 | pilot_gate_09 | 04-25 19:58 | "continue. For things I could not find, go for arxiv" | paywall provisioning (4 papers' materials; arXiv fallback granted for an arXiv-only preprint) |
| 4 | pilot_gate_12 | 04-26 13:18 | "both paper done. Please see and inventory" | paywall provisioning (2 papers + SM) |
| 5 | pilot_gate_13 | 04-26 20:48 | "continue" | paywall provisioning (KMM PRB deposited) |
| 6 | pilot_gate_13 | 04-27 00:57 | "continue" | crash/API-recovery green-light (API error) |
| 7 | production-init | 04-27 20:56 | "continue production." | crash/API-recovery green-light (resume after premature session end) |
| 8 | production-init | 04-28 00:56 | "continue production. The terminal died…" | crash/API-recovery green-light (terminal crash) |
| 9 | production-init | 04-28 19:36 | "continue" | crash/API-recovery green-light (API 529) |

Plus 3 offline curations (pipeline sanity check → house rules §3; Wannier validation
protocol → house rules §4; Hubbard U non-transferability → house rules §6 — all verifiable
verbatim in `prompts/PILOT_HOUSE_RULES.md`), and the one architected below-T3 patch
(recorded, not an intervention). Zero events constitute scientific direction, parameter
choice, or interpretation. 38 of the 44 transcript-archived sessions, including all ten
writing sessions, ran from task prompt to completion with no typed human input.

Paywall paper accounting (events 2–5): 8 published reference papers plus supplementary
materials and one dataset, enumerated from the gate sessions' `reference_papers/`
folders and the agent-written inventory files therein: Ye PRB 113,014413 (+SM, +dataset);
Xu PRB 112,125141 (+SI); Jiang Nat. Phys. 21,754 (+source data); Sun PRB 112,184416
(+supp); Li APL 127,132401 (SI); Lin npj QM (10.1038/s41535-025-00766-3); Su Nature
(10.1038/s41586-024-08436-3) (+SM+4 source spreadsheets); Khodas–Mu–Mazin PRB 113,104422.

## Audit performed

1. **100% context verification.** Every one of the 9 events was read in context in the
   raw transcript: each paywall "continue" follows an explicit agent pause requesting
   published PDFs (prompt-mandated, see the paywall rule in
   `prompts/pilot_gate_prompt_latest.md` Step 1); each green-light follows an API error,
   terminal crash, or premature session end; the compute-status note follows a monitor
   timeout on a long SCF.
2. **Wake-up false-positive analysis.** Several user-role "continue …" records that a
   naive count would attribute to the human are verbatim matches to ScheduleWakeup
   prompts issued by the agent itself in the same transcript (verified programmatically;
   see `isMeta_wakeup_verification` in the script's summary output). These are agent
   self-scheduling, excluded.
3. **Template match.** The below-T3 patch message is byte-identical to its on-disk
   template (similarity ratio 1.0).
4. **Curation verification.** The three curated principles were located verbatim in the
   operative house rules (sections 3, 4, 6 of `prompts/PILOT_HOUSE_RULES.md`), and the
   published `knowledge/INDEX.md` is the 470-line post-pilot state (identical to the
   state inherited by the no-pilot ablation).

Note on reproducibility: `count_interventions.py` reads the raw per-session transcripts,
which are retained in the project archive and not published here; the script and this
document make the count auditable at the rule and per-event level.
