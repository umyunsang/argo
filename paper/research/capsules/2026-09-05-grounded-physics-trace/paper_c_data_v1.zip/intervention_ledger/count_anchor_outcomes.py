#!/usr/bin/env python3
"""
count_anchor_outcomes.py — Camera-ready Pass 3.3 analysis.

Derives, from the figure source code that generated the shipped figures
(no figure regeneration), the counts used in the §4 quantitative roll-up:

1. Final per-anchor outcomes from figA1_multitrack_anchors.py POINTS
   (7 tracked anchors; outcome of the chronologically last point per track,
   session order per XMAP in _paper_c_style.py).
2. Fig 3B episode counts from PANEL_B_INCIDENTS in
   fig3_anchor_and_fault_tolerance.py (as rendered in the shipped PDF/PNG).
3. Literature totals from _paper_c_style.py CHANNELS_14 / PHASE_TOTALS and
   session count from figures/data/scaffolding_access_per_session.csv.

Runs either in the project tree or inside this package.
"""
import ast, csv, json, re
from pathlib import Path

FIGS = Path(__file__).resolve().parents[1] / "figures"
if not FIGS.exists():  # package layout
    _pkg = Path(__file__).resolve().parents[1]
    class _P:
        def __init__(self, base): self.base = base
        def __truediv__(self, rel):
            rel = str(rel)
            m = {"appendix/figA1_multitrack_anchors.py": "scripts/figures/figA1_multitrack_anchors.py",
                 "_paper_c_style.py": "scripts/figures/_paper_c_style.py",
                 "fig3_anchor_and_fault_tolerance.py": "scripts/figures/fig3_anchor_and_fault_tolerance.py",
                 "data/scaffolding_access_per_session.csv": "figure_data/scaffolding_access_per_session.csv"}
            return self.base / m.get(rel, rel)
    FIGS = _P(_pkg)

def literal_list(src, name):
    m = re.search(rf"{name}\s*=\s*(\[.*?\n\])", src, re.S)
    return ast.literal_eval(m.group(1))

# ---- 1. anchor outcomes -----------------------------------------------------
a1 = (FIGS / "appendix/figA1_multitrack_anchors.py").read_text()
points = literal_list(a1, "POINTS")   # (track, session, "ours/lit", ratio, status)
style = (FIGS / "_paper_c_style.py").read_text()
xmap_names = re.findall(r'"([^"]+)"\s*:\s*[\d.]+', re.search(r"XMAP\s*=\s*\{(.*?)\}", style, re.S).group(1))
xmap = {}
m = re.search(r"XMAP\s*=\s*\{(.*?)\n\}", style, re.S)
for k, v in re.findall(r'"([^"]+)"\s*:\s*([\d.]+)', m.group(1)):
    xmap[k] = float(v)

final = {}
for track, session, label, ratio, status in points:
    x = xmap.get(session, -1)
    if track not in final or x >= final[track][0]:
        final[track] = (x, session, label, ratio, status)
outcome_counts = {}
for track, (x, session, label, ratio, status) in final.items():
    outcome_counts[status] = outcome_counts.get(status, 0) + 1

# ---- 2. Fig 3B episodes -----------------------------------------------------
f3 = (FIGS / "fig3_anchor_and_fault_tolerance.py").read_text()
inc = literal_list(f3, "PANEL_B_INCIDENTS")  # (label, start, end, lane, caveat, flavor, jitter)
lanes, dashed = {}, []
for row in inc:
    lanes[row[3]] = lanes.get(row[3], 0) + 1
    if row[4]:
        dashed.append(row[0])

# ---- 3. literature totals ---------------------------------------------------
ch = re.search(r"CHANNELS_14\s*=\s*\[(.*?)\n\]", style, re.S).group(1)
ch_counts = [int(x) for x in re.findall(r",\s*(\d+)\s*,", ch)] or \
            [int(x) for x in re.findall(r"\b(\d+)\b(?=\s*,\s*\")", ch)]
# robust fallback: parse tuples
ch_tuples = ast.literal_eval("[" + ch + "]")
ch_total = sum(t[1] for t in ch_tuples)
pt = re.search(r"PHASE_TOTALS\s*=\s*\[(.*?)\n\]", style, re.S).group(1)
pt_tuples = ast.literal_eval("[" + pt + "]")
pt_total = sum(t[1] for t in pt_tuples)
with open(FIGS / "data/scaffolding_access_per_session.csv") as f:
    n_sessions = sum(1 for _ in f) - 1

out = {
    "anchors": {
        "n_tracks": len(final),
        "final_outcomes": {t: {"session": v[1], "values": v[2], "ratio": v[3],
                               "outcome": v[4]} for t, v in final.items()},
        "final_outcome_counts": outcome_counts,
    },
    "fig3B_episodes": {
        "total_markers": len(inc),
        "by_lane": lanes,
        "dashed_caveat_flagged": dashed,
    },
    "literature": {
        "channels": len(ch_tuples), "channel_sum": ch_total,
        "phase_sum": pt_total, "sessions_in_scaffolding_csv": n_sessions,
    },
}
Path(__file__).with_name("anchor_outcomes_summary.json").write_text(json.dumps(out, indent=2))
print(json.dumps(out, indent=2))
