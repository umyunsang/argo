# Episode recount audit — Fig. 3B "15 catch episodes" (Phase A item A5)

Date: 2026-07-02. Author: camera-ready operator. Companion analyses:
`count_anchor_outcomes.py` (extracts the marker list programmatically),
the project worklog (why the submitted "13 (4/5/2/2)" was stale).

## Counting rule

**One episode = one labeled incident marker drawn in the shipped Fig. 3B**, i.e. one entry
of `PANEL_B_INCIDENTS` in `figures/fig3_anchor_and_fault_tolerance.py` (lines 21–38; the
list the shipped PDF/PNG was rendered from; byte-identical copies in `camera_ready/figures/`
and `ARCHIVE_original_submission/figures/`). An episode is a single catch event: one
suspect result (or hypothesis) refuted, corrected, or caveat-flagged by one mechanism at
one point in the pilot chronology. A marker may bundle several same-kind items caught in
the same session by the same mechanism (see "multi-item events" below). Mechanism
assignment follows the figure's operational rule (`analysis/13_fig3B_mechanisms_review.md`
lines 280–283): catch driven by a controlled computational experiment → Falsification;
catch driven by re-reading/re-deriving prior data or literature → Adversarial review;
caught inside the same session that produced the error → Within-session debug; caught
because a missed reference surfaced through a different phase/channel → Distributed
grounding. Scope: pilot chronology (S1 → pg15 + reflects), matching the panel's x-axis;
the §3.3 production-continuation strain-mode catch is prose, not a Fig. 3B marker.

## Per-episode ledger (marker → source artifact)

| # | Marker (lane) | Sessions | Source artifact (evidence) |
|---|---|---|---|
| 1 | KV2Se2O AM (Distributed grounding) | S1→pg09 | `pilot/pilot_gate_09/` (C-vs-G ground state; away_summary "KV₂Se₂O … is G-type AFM, not C-type — drops from the Λ-tensor headline"); surfaced via literature deposited at the pg09 paywall pause (`pilot_gate_09/reference_papers/INVENTORY.md`) |
| 2 | Ye 2.4x (Adversarial review, lit) | pg04→ref01 | `pilot/pilot_reflect_01/reflect_report.md` (NOT PASS; sub-agent gap-hunt surfaced Ye value; HIGH→LOW retraction) |
| 3 | lit retractions x3 (Adversarial review, lit) | S3-04→ref01 | `pilot/pilot_reflect_01/reflect_report.md` (one reflect session retracting three prior literature-comparison diagnoses; cf. exploration report §"three retractions … reflect_01 retracting 3 prior diagnoses") |
| 4 | Λorb −2.82→−0.019 (Adversarial review, internal) | pg04→pg11 | `pilot/pilot_gate_11/` (away_summary: "retracting pg04's −2.82 (150× off due to gauge mismatch)"; `comparison_lambda_orb_symmetric_fd.png`) |
| 5 | no plateau (Adversarial review, internal) | pg06→pg07 | `pilot/pilot_gate_06/` (final verdict: "No plateau exists. pg05's '1.35× Ye' value of 0.238 is a local peak of an oscillating function") |
| 6 | ref-II cap (Adversarial review, internal) | pg08→ref-II | `pilot/pilot_reflect_II_02/reflect_II_report.md` (iteration-cap activation; transition plan pg09–pg15) |
| 7 | KMM 40x unit error (Adversarial review, internal) | pg11→pg13 | `pilot/pilot_gate_13/` (16-SCF J(ε) bridge; unit-conversion catch per figure label and gate report) |
| 8 | CrSb sigma sign (Adversarial review, lit; DASHED) | pg12 | `pilot/pilot_gate_12/pilot_gate_verdict.md` (unresolved literature sign discrepancy — caveat-flagged) |
| 9 | T1g/T2g (Within-session debug) | S3-04 | `pilot/session_3_reproduce_04/` (T1g vs T2g ground-state configuration caught in-session) |
| 10 | pw2wan wfcU (Within-session debug) | pg04 | `pilot/pilot_gate_04/` (pw2wannier90 Hubbard-projector handling caught in-session) |
| 11 | CrSb antiunitary (Within-session debug) | pg12 | `pilot/pilot_gate_12/` (antiunitary symmetry handling caught in-session) |
| 12 | Mn3NiN 17x (Falsification) | S3-04→pg02 | `session_3_reproduce_04/reproduction_report.md:23` ("factor of ~17× too small"); `pilot_gate_02/pilot_gate_report.md:94` ("Each hypothesized driver of the 17× gap is at most a 10% effect") |
| 13 | atomic relax (Falsification) | pg03 | `pilot_gate_03/pilot_gate_report.md` §7.5 ("total force = 0.000000 on every atom … Forces vanish identically by symmetry … rules out atomic relaxation as a driver") |
| 14 | basis extension (Falsification; DASHED) | pg07→pg08 | `pilot_gate_08/pilot_gate_report.md:109–117` ("Hypothesis: pg07 'basis insufficiency' → FALSIFIED ❌ … 36-WF basis … reduces |M_z| from 0.190 to ~0.001") |
| 15 | PAW unconverge (Falsification; DASHED) | pg08 | `pilot_gate_08/pilot_gate_report.md` §2.6 ("SCF failed in 4 attempts … PAW test deferred") — a controlled test that failed to converge; dashed = caveat |

Lane totals: Distributed grounding 1, Adversarial review 7, Within-session debug 3,
Falsification 4 → **15**. Dashed (caveat-flagged): #8, #14, #15.

## Multi-item events counted as ONE episode — justification

- **#3 "lit retractions x3"**: three prior diagnoses retracted in a single adversarial
  review session (reflect_01) by the same mechanism at the same chronological point. One
  catch event (one session's adversarial re-read), three affected items. Counting it as
  three would triple-count a single mechanism firing once; the figure encodes it as one
  marker with an "×3" label, and the recount follows the figure.
- **#12 "Mn3NiN 17x"**: the S3-04 17× discrepancy plus the pg02 factorial that refuted all
  three hypothesized causes is drawn as one marker spanning S3-04→pg02 (one suspect result,
  one controlled-experiment campaign). The subsequent pg03 atomic-relax refutation is a
  distinct hypothesis and is its own marker (#13), so no under-counting.

## Spot-checks against raw records (≥3, per Discipline §2)

1. **#12/#13** — verified verbatim: `session_3_reproduce_04/reproduction_report.md` line 23
   ("Mn₃NiN Q'₁₁ = 0.00292 G/MPa … vs paper 0.051 … ~17× too small"; `paper_verdict.json`
   line 8 concurs); `pilot_gate_03/pilot_gate_report.md` lines 338–357 ("BFGS converged in
   0 steps", "contrary to my earlier §7 hypothesis").
2. **#14/#15** — verified verbatim: `pilot_gate_08/pilot_gate_report.md` line 109
   ("FALSIFIED ❌"), line 111 (0.190 → ~0.001), §2.6 lines 82–95 ("SCF failed in 4
   attempts", "PAW test deferred to pilot_gate_09").
3. **#2** — verified: `pilot_reflect_01` away_summary ("verdict NOT PASS") and
   `reflect_report.md` in folder; Ye value comparison and HIGH→LOW retraction per §3.2 of
   the paper and Fig. 3A trajectory data (`figures/data/pilot_anchor_data.csv` pg04/ref01
   rows).
4. **#5** — verified: `pilot_gate_06` final assistant verdict quoted in
   `session_trace_inventory.md` §19 ("No plateau exists…"), consistent with the dfroz-scan
   deliverables in the folder.
