# Provenance — companion Supplemental Material

`supplementary.pdf` is the companion manuscript's Supplemental Material exactly as
produced by the pipeline's writing phase (compiled 2026-05-03; binary-unmodified).
Its title page carries the byline as produced at that time ("Claude Opus and Haonan
Huang"). The camera-ready companion manuscript (Appendix J of the paper) carries the
final authorship decision (Claude Opus as sole author, with the pipeline design credited
via citation); this archived SM predates that decision and is preserved as produced,
consistent with the paper's §J framing of pipeline outputs as primary data.
