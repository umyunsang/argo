# No-pilot ablation: dfroz-scan characterization (verbatim excerpt)

Provenance: `run_003_ablation/production/production_reflect_report_04.md` (the ablation's
fourth reflect-continuation cycle; full report retained in the project archive). The line
quoted in §4 of the paper:

> 5. **Phase R6 — MnTe dis_froz_max plateau [DOCUMENTED CAVEAT]:** Re-Wannierized at dfroz ∈ {12.0, 12.5, 13.0} eV; computed σ_xy and M_orb_z. **Plateau is BROAD: 219% σ_xy spread, 191% M_orb_z spread. Above L2.2 5% threshold.** Symmetry is preserved (forbidden machine zero). Documented as systematic uncertainty; OQ19 added.

The accompanying scan data is `mnte_dfroz_plateau.csv` in this directory; the ablation's
M_orb_z(ε=0) = 0.0661 μB/cell headline value appears in `cross_material_synthesis.csv`.
