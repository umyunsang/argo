# QE 7.5 pw2wannier90.x wfcU allocation patch (lesson L12)

Provenance: excerpt of `pre_production/lessons_learned.md` (pipeline output, canonical run),
and the fix line from `pilot/pilot_gate_04/WORKLOG.md` (where the segfault was diagnosed
and patched). No standalone .patch file exists in the run tree; the fix is the one-line
defensive allocation below, applied to QE 7.5 `PP/src/pw2wannier90.f90` (compute_orb branch).

Fix line (from pilot_gate_04 WORKLOG):

```fortran
`IF (.NOT. ALLOCATED(wfcU)) ALLOCATE(wfcU(npwx*npol, nwfcU))`.
```

---

## L12 — QE 7.5 pw2wannier90.x with LDA+U+SOC+`uHu`/`uIu` requires a 4-line patch to allocate `wfcU` inside `compute_orb`; without the patch, runs segfault silently

**Rule.** Before any noncol+SOC+Hubbard+Wannier90 chain (needed for m_orb), apply the 4-line allocation fix to QE 7.5 `PP/src/pw2wannier90.f90` documented in pg04 §4.4. Without it, `pw2wannier90.x` segfaults silently when computing `uHu` and `uIu` matrices for orbital magnetization.

**Evidence (pilot).** pg04 identified the segfault: `wfcU` array (the Hubbard-projected wavefunctions, allocated in SCF) is not re-allocated in the `compute_orb` subroutine inside `pw2wannier90.f90`. The fix: add 4 lines that allocate `wfcU` if not already allocated when entering `compute_orb`. Recompiled QE; chain runs cleanly.

**Why.** The QE 7.5 release inadvertently omitted the `wfcU` allocation in the orbital-related branch of `pw2wannier90.f90`. Most users do not compute `uHu`/`uIu` (only AHC needs `mmn`+`spn`); the Hubbard+SOC+orbital subset is rare enough that the bug went unnoticed in QE 7.5.

**How to apply.** (a) Production must have the patched `pw2wannier90.x` binary. (b) Document the patch in the production deliverables. (c) The patch is documented at `pilot_gate_04/WORKLOG.md` §4.4 — a drop-in 4-line addition. (d) If migrating to QE 7.6+, verify the patch is no longer needed (QE may have fixed upstream by then).

**Online cross-check.** This patch is not, to our knowledge, in the QE upstream as of QE 7.5. We did not search the QE GitLab issues exhaustively. The fix is a straightforward defensive `if (.not. allocated(wfcU)) allocate(...)` pattern; future versions may have it.

**Confidence: MEDIUM** (verified in pilot; root cause identified; not independently verified that no upstream fix exists).

---

