# MANIFEST — file → claim/promise justification

Paper = the ICML 2026 AI for Science Workshop camera-ready. Promises: Appendix C intro and
C.8 (full prompt set), Appendix E (categorization scripts + regex rules), Appendix G
(INDEX.md + PSEUDOPOTENTIALS.md), §J note (companion Supplemental Material), Fig. 5 caption
(prompt sources). Claims: 2,162 events / 14 channels (Fig. 1); 11,083-paper corpus and
12-theme categorization (Fig. 2, Table 5); 877 breadth-cited IDs / exactly-two counts
22/27/100 / consensus core 27 (§3.1, Appendix F, Table 6); 7 anchors, 4 PASS / 3 caveat
(Fig. 4, §4 roll-up); 15 catch episodes (Fig. 3B); T1–T4 tier scheme (Appendix A); 9+3
human-intervention events (Table 2); production recipes (§3.3, companion); ablation dfroz
collapse, 0.066 headline, and never-written anchor comparison (§4); 37 verified workflows
/ 17 analysis scripts (§2, Appendix G).

| Path | Justification |
|---|---|
| prompts/breadth_prompt_v2.md | Appendix C.1 verbatim source; prompt-set promise |
| prompts/depth_prompt_v3.md | Appendix C.2 verbatim source |
| prompts/pilot_gate_prompt_latest.md | Appendix C.3 verbatim source; tier scheme (T4 ≤20%) |
| prompts/pilot_reflect_prompt_1.md | Appendix C.4 verbatim source |
| prompts/pilot_reflect_II_prompt.md | Appendix C.5 verbatim source |
| prompts/PILOT_HOUSE_RULES.md | Appendix C.7 verbatim source; 3 curated principles (§3.2/App G) |
| prompts/session_1_prior_work_prompt.md | Appendix C.6 bullet 1 (see README note: prompt requests 3 papers; the session nominated 5, all executed) |
| prompts/session_2_tooling_prompt.md | Appendix C.6 bullet 2 |
| prompts/session_3_reproduce_template_3.md | Appendix C.6 bullet 3; tier definitions |
| prompts/session_3_reproduce_patch_if_below_T3.md | Table 2 caption (architected conditional prompt) |
| prompts/production_prompt.md | Appendix C.6 bullet 5 |
| prompts/production_continue_prompt_2.md | Appendix C.6 bullet 6 |
| prompts/pre_production_prompt.md | Appendix C.6 bullet 4 |
| prompts/pre_write_1A_prompt.md, pre_write_1B_prompt.md, full_write_prompt.md, polish_prompt.md | Appendix C.6 bullets 7–10 |
| knowledge/INDEX.md | Appendix G promise; 470-line and 37-workflow/17-script claims; ablation-inherited state (§4, App G) |
| knowledge/PSEUDOPOTENTIALS.md | Appendix G promise |
| scripts/categorization/* | Appendix E promise (scripts + regex rules + outputs + audit) |
| scripts/info_flow/* | 2,162-event / 14-channel extraction methodology (Fig. 1B,C; reads private-archive transcripts — see README script provenance note) |
| scripts/figures/* | Fig. 1/2/3/4/5 generation scripts + extractors (methodology documentation; see README script provenance note) |
| figure_data/pilot_anchor_data.csv | Fig. 3A & Fig. 4 trajectories; 7-anchor 4/3 accounting (§4) |
| figure_data/literature_total_dedup.json | 2,162 grand total (audited dedup) |
| figure_data/per_stage_summary.csv, cross_stage.csv | per-phase literature totals (Fig. 1C) |
| figure_data/scaffolding_access_per_session.csv | 47-session accounting; Fig. 1A bottom band |
| figure_data/breadth_cited_ids.json | §3.1 / Appendix F: 877 union, 22/27/100 exactly-two, 27 core, 701 exactly-one (recomputable) |
| figure_data/corpus_arxiv_ids.csv | 11,083 corpus with theme categories (Fig. 2, Table 5); corpus reconstructable from arXiv |
| verdicts/paper_verdict_s3_0{1..5}.json | tier scheme as operated (Appendix A); S3 outcomes |
| intervention_ledger/intervention_events.csv | Table 2 per-event evidence (9+3+patch) |
| intervention_ledger/count_interventions.py | Table 2 counting script, as operated (requires the archived transcripts; published with condensed scope header) |
| intervention_ledger/counting_rules_AUDIT.md | counting rules + per-event audit + paywall paper accounting |
| intervention_ledger/episode_recount.md | 15-episode ledger + counting rule (Fig. 3B) |
| intervention_ledger/count_anchor_outcomes.py, anchor_outcomes_summary.json | 7-anchor / 15-episode / 2,162 programmatic extraction (runnable in-package) |
| production_inputs/** | §3.3 production recipes; companion reproducibility surface (as archived; see README) |
| production_inputs/mnte_strain_recipe_pilot_gate11/** | the locked Λ_orb = −1.96 recipe's ε=±0.2% endpoint decks (pilot gate 11 → production) |
| toolchain/pw2wannier90_wfcU_patch.md | QE binary patch the runs depended on (L12; Fig. 3B pw2wan wfcU episode) |
| ablation_evidence/mnte_dfroz_plateau.csv | §4 dfroz collapse (0.140→0.005 across 1 eV) |
| ablation_evidence/cross_material_synthesis.csv | §4 ablation headline M_orb 0.066 μB/cell |
| ablation_evidence/reflect04_plateau_excerpt.md | §4 verbatim "Plateau is BROAD" quote + provenance |
| ablation_evidence/reflect_cycles_grep.md | §4 negative claim ("0.066 vs 0.176 never written") — grep verification |
| companion_SM/supplementary.pdf | §J note promise (Supplemental Material, as produced) |
| companion_SM/PROVENANCE.md | provenance/byline note for the as-produced SM |
| README.md, MANIFEST.md, LICENSE, SHA256SUMS | record hygiene |
