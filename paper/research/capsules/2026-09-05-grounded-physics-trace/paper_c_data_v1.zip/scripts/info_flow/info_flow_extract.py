#!/usr/bin/env python3
"""
info_flow_extract.py — extract per-session information-flow data from
Claude Code .jsonl conversation traces for run_002.

Outputs:
  per_session/<stage>__<session>.json     — full per-session structured record
  per_stage_summary.csv                   — one row per session with key counts
  cross_stage.csv                         — one row per stage with averages

Run:
    python3 info_flow_extract.py
    python3 info_flow_extract.py --validate breadth_01      # dump-only one session
    python3 info_flow_extract.py --no-cross                 # skip cross_stage roll-up

Idempotent: safe to rerun. Output files are overwritten.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# CANONICAL SESSION TABLE
# (stage label, session label, absolute jsonl path)
# Compiled from session_trace_inventory.md. Breadth lives in run_001 project
# dirs (re-used per inventory). Everything else is in run_002 project dirs.
# ---------------------------------------------------------------------------

CANONICAL: list[tuple[str, str, str]] = [
    # ---- breadth (3) — re-used from run_001 ----
    ("breadth", "breadth_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-001-breadth-breadth-01/fdc09af5-49bb-459a-aaa6-195f7ec1688e.jsonl"),
    ("breadth", "breadth_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-001-breadth-breadth-02/67401028-6bd2-447c-9955-49955d269cfb.jsonl"),
    ("breadth", "breadth_03",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-001-breadth-breadth-03/0ff1780a-af46-4d3c-83f7-510eab2407e6.jsonl"),

    # ---- depth (5) ----
    ("depth", "depth_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-depth-depth-01/c95cccd2-fe89-4a65-8b18-be7f8293ffe2.jsonl"),
    ("depth", "depth_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-depth-depth-02/818dd59e-214d-452d-b9d4-8da1fb70f734.jsonl"),
    ("depth", "depth_03",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-depth-depth-03/7f5e46cb-988e-4543-bfdb-39cae4553365.jsonl"),
    ("depth", "depth_04",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-depth-depth-04/efa2f56f-370b-47d6-be4c-112b9bb350f3.jsonl"),
    ("depth", "depth_05",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-depth-depth-05/a64ec89c-3cfe-4457-a192-5fa5907a97aa.jsonl"),

    # ---- pilot S1, S2, S3 ×5 ----
    ("pilot_S1", "session_1_prior_work",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-1-prior-work/9ac9c512-4c26-432a-b540-39813ec537ed.jsonl"),
    ("pilot_S2", "session_2_tooling",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-2-tooling/73d53ed1-4bdc-4f89-9131-fc83e2b6e4ca.jsonl"),
    ("pilot_S3", "session_3_reproduce_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-3-reproduce-01/ec7e27a1-cf2b-4f67-beae-33c318248490.jsonl"),
    ("pilot_S3", "session_3_reproduce_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-3-reproduce-02/2fff7155-dff8-4972-9f7c-0219f079034e.jsonl"),
    ("pilot_S3", "session_3_reproduce_03",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-3-reproduce-03/3633f047-951f-41b8-9115-7caae26af366.jsonl"),
    ("pilot_S3", "session_3_reproduce_04",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-3-reproduce-04/1845f388-643a-47e0-b4f5-95dd028e083e.jsonl"),
    ("pilot_S3", "session_3_reproduce_05",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot-session-3-reproduce-05/8fee505c-ae87-4187-8b54-8960ff06b210.jsonl"),

    # ---- pilot gates ×15 (all in main pilot dir) ----
    ("pilot_gate", "pilot_gate_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/f0115ffc-8208-4dfa-811e-334352499c81.jsonl"),
    ("pilot_gate", "pilot_gate_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/7faca369-d093-484b-bbd1-9fa4db650b1f.jsonl"),
    ("pilot_gate", "pilot_gate_03",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/165b0a24-9c34-4068-beaf-0bd18e33b4be.jsonl"),
    ("pilot_gate", "pilot_gate_04",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/fa0ff1fe-613e-4a09-ae85-f2cd5a0f5ce5.jsonl"),
    ("pilot_gate", "pilot_gate_05",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/0b19cba3-3685-4bb9-8b49-dd5de187fc61.jsonl"),
    ("pilot_gate", "pilot_gate_06",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/b5b57224-b189-421a-8762-8544eb651f9f.jsonl"),
    ("pilot_gate", "pilot_gate_07",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/b03b7e56-295b-4222-b64e-d90bd98eca51.jsonl"),
    ("pilot_gate", "pilot_gate_08",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/e3923739-0015-4ee6-98a0-24f34e7042c7.jsonl"),
    ("pilot_gate", "pilot_gate_09",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/86b89ae6-91d0-41ed-8ccd-12dc4e32909d.jsonl"),
    ("pilot_gate", "pilot_gate_10",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/42bfc7e5-1e9f-4330-a71f-8fd101dde89e.jsonl"),
    ("pilot_gate", "pilot_gate_11",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/b51b8e26-4857-47a1-ae2e-19f3c104a7c9.jsonl"),
    ("pilot_gate", "pilot_gate_12",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/8962edd9-f839-4c85-babf-eb694a584483.jsonl"),
    ("pilot_gate", "pilot_gate_13",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/a712e904-c550-4439-97d1-617390c6ceb7.jsonl"),
    ("pilot_gate", "pilot_gate_14",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/7f20117f-41dd-4223-8064-5f70efd0aa13.jsonl"),
    ("pilot_gate", "pilot_gate_15",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/038507ea-9841-4099-98ad-50653ca5bc4f.jsonl"),

    # ---- pilot reflects ×2 ----
    ("pilot_reflect", "pilot_reflect_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/4e52888e-5696-4c46-9570-99f7b6443513.jsonl"),
    ("pilot_reflect", "pilot_reflect_II_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/2066f4ae-ffeb-4098-90be-e1d434ce7b80.jsonl"),

    # ---- pre-production ----
    ("pre_production", "pre_production",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002-pilot/ba8d87f4-2a74-427c-94ed-66dc16546c22.jsonl"),

    # ---- production initial + 3 continues ----
    ("production_init", "production_initial",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/41ad1969-742a-4a77-b3e7-42f1799dece5.jsonl"),
    ("production_continue", "production_continue_01",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/e20cb4f2-5916-4ff3-8b2f-b9a6e30cfd3b.jsonl"),
    ("production_continue", "production_continue_02",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/4bd316f6-1cfc-4ebf-81b7-260de5ef2247.jsonl"),
    ("production_continue", "production_continue_03",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/00656337-8920-453d-9465-9b83d32a3f7c.jsonl"),

    # ---- writing pipeline ×3 (1A + 1B + full_write per run) ----
    ("write_1A", "run_1_1A",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/af8abf1c-1ea8-43df-a89f-d46eb3a6ee0b.jsonl"),
    ("write_1B", "run_1_1B",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/0e8c5f3d-519f-41b4-869d-262c269d8deb.jsonl"),
    ("write_full", "run_1_full",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/8baae150-deaa-4442-a01b-683143d81560.jsonl"),
    ("write_1A", "run_2_1A",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/9c4352b2-8d1d-4c37-8b94-8b3bc403f817.jsonl"),
    ("write_1B", "run_2_1B",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/5dd50b97-7f57-40ea-bbc2-42d55b6cb8f5.jsonl"),
    ("write_full", "run_2_full",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/e58a2dee-2ef3-4835-a2d8-f4cb4d0d26ce.jsonl"),
    ("write_1A", "run_3_1A",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/db0ed5c7-5387-44c9-a0df-c7e6cb4361c2.jsonl"),
    ("write_1B", "run_3_1B",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/552255a5-5324-4071-bc12-2bf434e33fbc.jsonl"),
    ("write_full", "run_3_full",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/12888cde-e397-4fd5-9744-f176ec7fad44.jsonl"),

    # ---- polish ----
    ("polish", "polish",
     "<HOME>/.claude/projects/-Users-<USER>-automatic-agent-physical-science-runs-run-002/fb586ab4-d444-4f15-8aff-1bcaa4a8f6d1.jsonl"),
]


# ---------------------------------------------------------------------------
# Filtering helpers — distinguish real user prompts from system noise
# ---------------------------------------------------------------------------

# Things that look like user messages but are NOT actual user prompts:
SYSTEM_NOISE_PREFIXES = (
    "<local-command-caveat>",
    "<command-name>",
    "<local-command-stdout>",
    "<task-notification>",
    "<system-reminder>",
    "<command-message>",
    "[Request interrupted",
    "<<autonomous-loop-dynamic>>",   # /loop dynamic sentinel — runtime-fired, not human
    "<<autonomous-loop>>",            # CronCreate-mode /loop sentinel
)

# Auto-injected /resume continuation summaries
RESUME_PREFIX = "This session is being continued from a previous conversation"


def is_real_user_text(text: str) -> bool:
    """True if this user-string-content is an actual human-typed message
    (not a slash command, tool result, monitor event, or /resume context)."""
    if not isinstance(text, str):
        return False
    stripped = text.strip()
    if not stripped:
        return False
    if any(stripped.startswith(p) for p in SYSTEM_NOISE_PREFIXES):
        return False
    if stripped.startswith(RESUME_PREFIX):
        return False
    return True


# Pattern detectors for assistant-text references
RE_INDEX_NUMBERED = re.compile(r"\bINDEX\s*#\s*(\d+)|\bINDEX\s+(?:entry|lesson)\s+#?(\d+)|\bLesson\s+(\d+)\b", re.IGNORECASE)
RE_RULE_REF = re.compile(
    r"\bHOUSE\s*RULES?\b[^.\n]{0,40}?§\s*(\d+)"        # HOUSE_RULES §3
    r"|\bHouse\s*Rule\s+(\d+)"                           # House Rule 3
    r"|\bPILOT_HOUSE_RULES?[^.\n]{0,30}?§\s*(\d+)"       # PILOT_HOUSE_RULES §3
    r"|\bhouserule\s*(\d+)?"                              # houserule N
    r"|\brule\s+§\s*(\d+)",                               # rule §3
    re.IGNORECASE,
)
RE_ARXIV_ID = re.compile(r"\b(arXiv:|arxiv:)?\s*(\d{4}\.\d{4,5})\b", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Core extraction
# ---------------------------------------------------------------------------

def extract_session(stage: str, label: str, jsonl_path: str) -> dict[str, Any]:
    """Walk one .jsonl file and return a structured info-flow record."""
    record: dict[str, Any] = {
        "stage": stage,
        "session_label": label,
        "jsonl_path": jsonl_path,
        "exists": os.path.exists(jsonl_path),
        "raw_line_count": 0,
        "type_counts": {},
        # Inputs
        "first_user_prompt": None,
        "first_user_prompt_chars": 0,
        "additional_user_messages": [],     # list of dicts {line, snippet, full_text}
        "real_user_message_count": 0,
        # Tool calls: deduped lists + counts
        "read_paths": [],            # in chronological order
        "read_count": 0,
        "write_paths": [],
        "write_count": 0,
        "edit_paths": [],
        "edit_count": 0,
        "webfetch_urls": [],
        "webfetch_count": 0,
        "websearch_queries": [],
        "websearch_count": 0,
        "bash_commands": [],          # truncated to ~200 chars
        "bash_count": 0,
        "task_descriptions": [],
        "task_count": 0,
        "todo_writes": 0,             # TaskCreate / TaskUpdate / TodoWrite calls
        "monitor_calls": 0,
        "other_tool_counts": {},      # any other tool name -> count
        # Assistant-text pattern hits
        "index_references": [],       # captured INDEX# / "Lesson N" numbers
        "rule_references": [],         # captured "House Rule N" / "rule §N" numbers
        "arxiv_ids_in_assistant": [],
        # Cwd evolution
        "cwd_first": None,
        "cwd_last": None,
        # Timestamps
        "first_timestamp": None,
        "last_timestamp": None,
    }

    if not record["exists"]:
        return record

    seen_first_prompt = False

    with open(jsonl_path, "r", errors="replace") as f:
        for ln_idx, line in enumerate(f, start=1):
            record["raw_line_count"] += 1
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue

            t = obj.get("type", "UNKNOWN")
            record["type_counts"][t] = record["type_counts"].get(t, 0) + 1

            # Track cwd
            cwd = obj.get("cwd")
            if cwd:
                if record["cwd_first"] is None:
                    record["cwd_first"] = cwd
                record["cwd_last"] = cwd

            # Track timestamps
            ts = obj.get("timestamp")
            if ts:
                if record["first_timestamp"] is None:
                    record["first_timestamp"] = ts
                record["last_timestamp"] = ts

            # ---- USER MESSAGES ----
            if t == "user":
                msg = obj.get("message", {})
                content = msg.get("content")
                if isinstance(content, str):
                    if is_real_user_text(content):
                        record["real_user_message_count"] += 1
                        if not seen_first_prompt:
                            record["first_user_prompt"] = content
                            record["first_user_prompt_chars"] = len(content)
                            seen_first_prompt = True
                        else:
                            record["additional_user_messages"].append({
                                "line": ln_idx,
                                "timestamp": ts,
                                "chars": len(content),
                                "snippet": content[:200],
                                "full_text": content if len(content) <= 4000 else content[:4000] + "...[truncated]",
                            })

            # ---- ASSISTANT MESSAGES ----
            elif t == "assistant":
                msg = obj.get("message", {})
                content = msg.get("content", [])
                if not isinstance(content, list):
                    continue
                for item in content:
                    if not isinstance(item, dict):
                        continue
                    itype = item.get("type")
                    if itype == "tool_use":
                        _classify_tool_use(item, record)
                    elif itype == "text":
                        _classify_text(item.get("text", ""), record)

    # Dedup-friendly counters: counts are total invocations; lists keep all values
    # (so duplicates are preserved — useful to know if same path was Read 5×).

    # Truncate giant lists to keep JSON manageable
    record["read_paths"] = record["read_paths"][:1500]
    record["bash_commands"] = record["bash_commands"][:1500]

    return record


def _classify_tool_use(item: dict, record: dict) -> None:
    """Update record in-place from a single tool_use content item."""
    name = item.get("name", "")
    inp = item.get("input", {}) or {}

    if name == "Read":
        path = inp.get("file_path") or inp.get("path") or ""
        record["read_paths"].append(path)
        record["read_count"] += 1
    elif name == "Write":
        path = inp.get("file_path") or inp.get("path") or ""
        record["write_paths"].append(path)
        record["write_count"] += 1
    elif name == "Edit":
        path = inp.get("file_path") or inp.get("path") or ""
        record["edit_paths"].append(path)
        record["edit_count"] += 1
    elif name == "WebFetch":
        url = inp.get("url", "")
        prompt_snippet = (inp.get("prompt") or "")[:120]
        record["webfetch_urls"].append({"url": url, "prompt_hint": prompt_snippet})
        record["webfetch_count"] += 1
    elif name == "WebSearch":
        q = inp.get("query", "")
        record["websearch_queries"].append(q)
        record["websearch_count"] += 1
    elif name == "Bash":
        cmd = inp.get("command", "")[:200]
        desc = inp.get("description", "")[:80]
        record["bash_commands"].append({"cmd": cmd, "desc": desc})
        record["bash_count"] += 1
    elif name in ("Task", "Agent"):
        desc = (inp.get("description") or inp.get("subject") or "")[:200]
        prompt = (inp.get("prompt") or "")[:300]
        record["task_descriptions"].append({"desc": desc, "prompt_snippet": prompt})
        record["task_count"] += 1
    elif name in ("TaskCreate", "TaskUpdate", "TodoWrite", "TaskGet", "TaskList"):
        record["todo_writes"] += 1
        record["other_tool_counts"][name] = record["other_tool_counts"].get(name, 0) + 1
    elif name in ("Monitor", "MonitorEvent"):
        record["monitor_calls"] += 1
        record["other_tool_counts"][name] = record["other_tool_counts"].get(name, 0) + 1
    else:
        record["other_tool_counts"][name] = record["other_tool_counts"].get(name, 0) + 1


def _classify_text(text: str, record: dict) -> None:
    """Update record in-place from one assistant-text item."""
    if not isinstance(text, str) or not text:
        return
    for m in RE_INDEX_NUMBERED.finditer(text):
        n = m.group(1) or m.group(2) or m.group(3)
        if n:
            record["index_references"].append(int(n))
    for m in RE_RULE_REF.finditer(text):
        for g in m.groups():
            if g and g.isdigit():
                record.setdefault("rule_references", []).append(int(g))
                break
        else:
            record.setdefault("rule_references", [])
            # capture even when no number (e.g., "houserule" alone)
            record["rule_references"].append(0)
    for m in RE_ARXIV_ID.finditer(text):
        record["arxiv_ids_in_assistant"].append(m.group(2))


# ---------------------------------------------------------------------------
# Aggregations
# ---------------------------------------------------------------------------

def write_per_session_json(record: dict, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    fname = f"{record['stage']}__{record['session_label']}.json"
    fp = out_dir / fname
    with open(fp, "w") as f:
        json.dump(record, f, indent=2, default=str)
    return fp


def write_per_stage_summary_csv(records: list[dict], out_path: Path) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    cols = [
        "stage", "session_label",
        "raw_line_count", "first_user_prompt_chars",
        "real_user_message_count",
        "read_count", "write_count", "edit_count",
        "webfetch_count", "websearch_count",
        "bash_count", "task_count", "todo_writes",
        "index_references_total", "index_references_unique",
        "arxiv_ids_total", "arxiv_ids_unique",
        "first_timestamp", "last_timestamp",
        "cwd_last",
    ]
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in records:
            ix = r.get("index_references", [])
            ax = r.get("arxiv_ids_in_assistant", [])
            w.writerow([
                r["stage"], r["session_label"],
                r["raw_line_count"], r["first_user_prompt_chars"],
                r["real_user_message_count"],
                r["read_count"], r["write_count"], r["edit_count"],
                r["webfetch_count"], r["websearch_count"],
                r["bash_count"], r["task_count"], r["todo_writes"],
                len(ix), len(set(ix)),
                len(ax), len(set(ax)),
                r["first_timestamp"], r["last_timestamp"],
                r["cwd_last"],
            ])


def write_cross_stage_csv(records: list[dict], out_path: Path) -> None:
    """Aggregate by stage label: average counts across sessions in each stage."""
    by_stage: dict[str, list[dict]] = {}
    for r in records:
        by_stage.setdefault(r["stage"], []).append(r)

    cols = [
        "stage", "n_sessions",
        "avg_read", "avg_write", "avg_edit",
        "avg_webfetch", "avg_websearch",
        "avg_bash", "avg_task_subagent", "avg_todo",
        "avg_index_refs", "avg_real_user_msgs",
        "total_real_user_msgs",
    ]
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for stage in [
            "breadth", "depth", "pilot_S1", "pilot_S2", "pilot_S3",
            "pilot_gate", "pilot_reflect", "pre_production",
            "production_init", "production_continue",
            "write_1A", "write_1B", "write_full", "polish",
        ]:
            rs = by_stage.get(stage, [])
            n = len(rs)
            if n == 0:
                continue

            def avg(key: str) -> float:
                return round(sum(r.get(key, 0) for r in rs) / n, 1)

            avg_idx = round(sum(len(r.get("index_references", [])) for r in rs) / n, 1)
            total_user = sum(r.get("real_user_message_count", 0) for r in rs)
            avg_user = round(total_user / n, 1)
            w.writerow([
                stage, n,
                avg("read_count"), avg("write_count"), avg("edit_count"),
                avg("webfetch_count"), avg("websearch_count"),
                avg("bash_count"), avg("task_count"), avg("todo_writes"),
                avg_idx, avg_user, total_user,
            ])


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out-dir", default="<PROJECT>/runs/run_002/analysis/info_flow_data")
    p.add_argument("--validate", help="Only run a single session by label (e.g. breadth_01)", default=None)
    p.add_argument("--no-cross", action="store_true", help="Skip cross-stage roll-up")
    args = p.parse_args()

    out_dir = Path(args.out_dir)
    per_session_dir = out_dir / "per_session"

    rows = []
    for stage, label, jsonl in CANONICAL:
        if args.validate and label != args.validate:
            continue
        if not os.path.exists(jsonl):
            print(f"  MISSING: {stage} / {label}: {jsonl}", file=sys.stderr)
            continue
        rec = extract_session(stage, label, jsonl)
        write_per_session_json(rec, per_session_dir)
        rows.append(rec)
        print(f"  done: {stage:18s}  {label:30s}  reads={rec['read_count']:5d}  "
              f"writes={rec['write_count']:4d}  webfetch={rec['webfetch_count']:3d}  "
              f"bash={rec['bash_count']:5d}  user_msgs={rec['real_user_message_count']:2d}")

    if not args.validate:
        write_per_stage_summary_csv(rows, out_dir / "per_stage_summary.csv")
        if not args.no_cross:
            write_cross_stage_csv(rows, out_dir / "cross_stage.csv")
        print(f"\nWrote summary CSVs to {out_dir}/", file=sys.stderr)

    print(f"\nProcessed {len(rows)} sessions.")


if __name__ == "__main__":
    main()
