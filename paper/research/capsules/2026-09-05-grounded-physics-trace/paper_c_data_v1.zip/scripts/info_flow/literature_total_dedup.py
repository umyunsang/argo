#!/usr/bin/env python3
"""
literature_total_dedup.py — produce ONE definitive number: total unique
(session, source, item) literature-consultation events across the entire
canonical pipeline.

Counting rule (user-specified, 2026-05-05):
  - For one session, same source+item counts as one event.
  - Source = SEMANTIC CHANNEL (delivery + storage), NOT the tool used.
    e.g. Read tool + Bash cat/head/grep of /corpus/markdown/X.md all collapse
    to source=local_corpus_md, item=X (same source+item → one event).
  - Item = canonical paper id (arxiv id / DOI / file basename / query string
    / sqlite keyword).
  - Sub-agents are treated as their own sessions for dedup purposes.
    Sub-agent attribution verified by `sessionId` field in sub-agent jsonls
    matching parent's UUID + sub-agent count == parent's Task/Agent call count.
  - Inheritance reads (writing-stage Reads of prior agent's literature_notes
    or bibliography.bib) are EXCLUDED — intra-pipeline product, not external
    info entering.
  - User-download asks are EXCLUDED — intent only; the eventual local Read
    of the delivered PDF is what counts as info entering.

Channels covered:
  Web channels (URL retrievals):
    - web_fetch_arxiv          (canonicalized: abs/html/pdf of same id collapse)
    - web_fetch_aps            (DOI key)
    - web_fetch_nature         (article slug)
    - web_fetch_<host>         (other journal/repository hosts)
    - web_search               (query string)
  API channels (structured Bash + Python requests):
    - api_arxiv                (id_list or search_query)
    - api_semanticscholar
    - api_openalex
    - api_crossref
    - api_elsevier
  Local-storage channels (any access mode: Read tool / Bash cat/head/grep):
    - local_corpus_md          (corpus/markdown/<arxiv_id>.md)
    - local_corpus_pdf         (corpus/pdfs/<arxiv_id>.pdf)
    - local_corpus_latex       (corpus/latex/<arxiv_id>.tar.gz)
    - local_prior_work_md      (prior_work/markdown/<id>.md)
    - local_prior_work_pdf     (prior_work/pdfs/<id>.pdf)
    - local_reference_paper    (pilot_gate_*/reference_papers/<file>)
  SQL channels:
    - sqlite_corpus_keyword    (LIKE '%<keyword>%' in corpus.db)
    - sqlite_corpus_paper      (WHERE arxiv_id IN (...) in corpus.db)
    - sqlite_corpus_query      (other SQL — fingerprint by query first 140c)
  Tooling-doc channel:
    - read_lit_access          (Read of literature_access.md itself)

Excluded by design:
  - Inheritance Reads of literature_notes.md, bibliography.bib, data_inventory.md, etc.
  - User-download-ask text (intent only; the post-delivery local Read is captured)
  - Edits/Writes (info OUT of the pipeline, not in)
  - Bash `ls` / `wc` / `file` operations (metadata, not content)

Usage:
    python3 literature_total_dedup.py
"""

from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))
from info_flow_extract import CANONICAL  # noqa: E402

# ---------------------------------------------------------------------------
# Canonicalization helpers
# ---------------------------------------------------------------------------

ARXIV_ID = re.compile(r"\b(\d{4}\.\d{4,5})(?:v\d+)?\b")
DOI = re.compile(r"\b10\.\d{4,9}/[-._;()/:A-Za-z0-9]+\b")


def canonicalize_url(url: str) -> tuple[str, str]:
    """Map a URL to (source_label, item_id)."""
    if not url:
        return ("web_fetch_unknown", "")
    u = url.strip()
    m = re.search(r"arxiv\.org/(?:abs|html|pdf)/(\d{4}\.\d{4,5})", u)
    if m:
        return ("web_fetch_arxiv", m.group(1))
    m = re.search(r"arxiv\.org/api/query.*?id_list=(\d{4}\.\d{4,5})", u)
    if m:
        return ("web_fetch_arxiv", m.group(1))
    m = re.search(r"journals\.aps\.org/[^/]+/abstract/(10\.\d{4,9}/[-._;()/:A-Za-z0-9]+)", u)
    if m:
        return ("web_fetch_aps", m.group(1))
    m = re.search(r"link\.aps\.org/doi/(10\.\d{4,9}/[-._;()/:A-Za-z0-9]+)", u)
    if m:
        return ("web_fetch_aps", m.group(1))
    m = re.search(r"nature\.com/articles/([A-Za-z0-9-]+)", u)
    if m:
        return ("web_fetch_nature", m.group(1))
    m = DOI.search(u)
    if m:
        host = re.search(r"https?://([^/]+)", u)
        host_label = (host.group(1) if host else "url").lower().replace("www.", "")
        return (f"web_fetch_{host_label.split('.')[-2]}", m.group(0))
    m = re.search(r"https?://([^/]+)(/[^?#\s]*)", u)
    if m:
        host = m.group(1).lower().replace("www.", "")
        path = m.group(2)
        return (f"web_fetch_{host.split('.')[-2]}", host + path)
    return ("web_fetch_unknown", u)


def normalize_query(q: str) -> str:
    if not q:
        return ""
    return " ".join(q.lower().split())


def extract_paper_id_from_path(path: str) -> Optional[str]:
    if not path:
        return None
    bn = os.path.basename(path)
    m = ARXIV_ID.search(bn)
    if m:
        return m.group(1)
    name = re.sub(r"\.(md|pdf|tar\.gz|tex|html)$", "", bn)
    return name or bn


def classify_local_path(path: str) -> Optional[tuple[str, str]]:
    """Map a literature-bearing local path to (source, item). Used uniformly
    for Read tool and Bash content-access on the same file."""
    if not path:
        return None
    pid = extract_paper_id_from_path(path)
    if "/corpus/markdown/" in path:
        return ("local_corpus_md", pid or path)
    if "/corpus/pdfs/" in path or "/corpus/pdf/" in path:
        return ("local_corpus_pdf", pid or path)
    if "/corpus/latex/" in path:
        return ("local_corpus_latex", pid or path)
    if "prior_work/markdown/" in path:
        return ("local_prior_work_md", pid or path)
    if "prior_work/pdfs/" in path or "prior_work/pdf/" in path:
        return ("local_prior_work_pdf", pid or path)
    if "reference_papers/" in path or "reference_paper/" in path:
        return ("local_reference_paper", pid or path)
    if "literature_access" in path:
        return ("read_lit_access", "literature_access.md")
    return None


# ---------------------------------------------------------------------------
# Bash command parsing — extract API queries, SQL queries, and content-reads
# ---------------------------------------------------------------------------

API_BASH_INTRO = re.compile(
    r"(arxiv\.org/api|api\.semanticscholar|api\.openalex|api\.crossref|api\.elsevier)",
    re.IGNORECASE,
)
ARXIV_QUERY_PATTERN = re.compile(
    r"(?:'|\")(all:[^'\"]+|ti:[^'\"]+|au:[^'\"]+|search_query=[^&'\"]+)(?:'|\")",
    re.IGNORECASE,
)
ARXIV_IDLIST_PATTERN = re.compile(r"id_list=(\d{4}\.\d{4,5})", re.IGNORECASE)
SEMSCH_QUERY = re.compile(r"semanticscholar.*?(?:'query'|\"query\")\s*:\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.DOTALL)
OPENALEX_SEARCH = re.compile(r"openalex.*?'search'\s*:\s*['\"]([^'\"]+)['\"]", re.IGNORECASE | re.DOTALL)

SQLITE_ABSTRACT = re.compile(
    r"sqlite3.+?(corpus\.db|papers).+?(abstract|title|full_text)",
    re.IGNORECASE | re.DOTALL,
)
SELECT_ARXIV_ID = re.compile(r"WHERE\s+arxiv_id\s*[=in]+\s*['\"]?(\d{4}\.\d{4,5})", re.IGNORECASE)
LIKE_KEYWORD = re.compile(r"LIKE\s+'%([^%]+)%'", re.IGNORECASE)

LIT_PATH_PATTERN = re.compile(
    r"(/corpus/(?:markdown|pdfs|latex)/|prior_work/(?:markdown|pdfs)/|/reference_papers?/)",
    re.IGNORECASE,
)
PATH_EXTRACT = re.compile(
    r"(/corpus/(?:markdown|pdfs|latex)/[^\s'\"]+|"
    r"prior_work/(?:markdown|pdfs)/[^\s'\"]+|"
    r"/reference_papers?/[^\s'\"]+)",
    re.IGNORECASE,
)

# Content-access verbs (read file content, not metadata)
CONTENT_VERBS = ("cat", "head", "tail", "sed", "awk", "less", "more", "grep", "rg", "fgrep", "egrep")
# Strip leading shell prelude for first-word inspection
PRELUDE_STRIP = re.compile(r"^(?:source\s+\S+\s*&&\s*)?(?:cd\s+\S+\s*&&\s*)?", re.IGNORECASE)


def is_content_access(cmd: str) -> bool:
    """True if the Bash cmd's effective first word is a content-access verb."""
    stripped = PRELUDE_STRIP.sub("", cmd.strip(), count=1)
    if not stripped:
        return False
    fw = stripped.split()[0]
    # Strip leading paths (e.g., /usr/bin/cat)
    fw = os.path.basename(fw)
    return fw in CONTENT_VERBS


def parse_bash_for_lit_items(cmd: str) -> list[tuple[str, str]]:
    """Return list of (source, item) tuples for a Bash command. Covers:
       - Structured API calls (arxiv, S2, OpenAlex, Crossref, Elsevier)
       - SQL queries on corpus.db
       - Bash content-access (cat/head/grep) on literature local files
    """
    items: list[tuple[str, str]] = []
    if not cmd:
        return items

    # API calls
    if API_BASH_INTRO.search(cmd):
        for m in ARXIV_IDLIST_PATTERN.finditer(cmd):
            items.append(("api_arxiv", m.group(1)))
        for m in ARXIV_QUERY_PATTERN.finditer(cmd):
            q = normalize_query(m.group(1))
            if q:
                items.append(("api_arxiv", q))
        if "api.semanticscholar.org" in cmd.lower():
            mm = SEMSCH_QUERY.search(cmd)
            q = normalize_query(mm.group(1)) if mm else "s2_call"
            items.append(("api_semanticscholar", q))
        if "api.openalex.org" in cmd.lower():
            mm = OPENALEX_SEARCH.search(cmd)
            q = normalize_query(mm.group(1)) if mm else "oa_call"
            items.append(("api_openalex", q))
        if "api.crossref.org" in cmd.lower():
            items.append(("api_crossref", "crossref_call"))
        if "api.elsevier" in cmd.lower():
            items.append(("api_elsevier", "elsevier_call"))

    # SQL pulls from corpus.db
    if SQLITE_ABSTRACT.search(cmd):
        ids = SELECT_ARXIV_ID.findall(cmd)
        kws = LIKE_KEYWORD.findall(cmd)
        if ids:
            for i in ids:
                items.append(("sqlite_corpus_paper", i))
        elif kws:
            for kw in kws:
                items.append(("sqlite_corpus_keyword", normalize_query(kw)))
        else:
            sig = re.sub(r"\s+", " ", cmd)[:140].lower()
            items.append(("sqlite_corpus_query", sig))

    # Bash content-access on literature files (cat/head/grep/etc.)
    # Same source labels as Read tool — they collapse on dedup.
    if LIT_PATH_PATTERN.search(cmd) and is_content_access(cmd):
        for path_match in PATH_EXTRACT.findall(cmd):
            classified = classify_local_path(path_match)
            if classified:
                items.append(classified)

    return items


# ---------------------------------------------------------------------------
# Walker
# ---------------------------------------------------------------------------

INHERIT_SUBSTRINGS = (
    "/literature_notes.md",
    "/bibliography.bib",
    "/data_inventory.md",
    "/data_analysis.md",
    "/detailed_outline.md",
    "/figure_disposition.md",
    "/figure_captions.md",
    "/manuscript.tex",
    "/supplementary.tex",
)


def is_inheritance(path: str) -> bool:
    return any(p in path for p in INHERIT_SUBSTRINGS)


def walk_session_jsonl(jsonl_path: str) -> set[tuple[str, str]]:
    """Walk one .jsonl (parent or sub-agent) and return deduplicated set of
    (source, item) literature-consultation tuples for that session."""
    items: set[tuple[str, str]] = set()
    if not os.path.exists(jsonl_path):
        return items

    with open(jsonl_path, "r", errors="replace") as f:
        for line in f:
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("type") != "assistant":
                continue
            msg = obj.get("message", {})
            content = msg.get("content", [])
            if not isinstance(content, list):
                continue
            for c in content:
                if not isinstance(c, dict) or c.get("type") != "tool_use":
                    continue
                nm = c.get("name", "")
                inp = c.get("input", {}) or {}

                if nm == "WebFetch":
                    src, item = canonicalize_url(inp.get("url", ""))
                    if item:
                        items.add((src, item))
                elif nm == "WebSearch":
                    q = normalize_query(inp.get("query", ""))
                    if q:
                        items.add(("web_search", q))
                elif nm == "Bash":
                    cmd = inp.get("command", "") or ""
                    for src, item in parse_bash_for_lit_items(cmd):
                        items.add((src, item))
                elif nm == "Read":
                    path = inp.get("file_path") or inp.get("path") or ""
                    if not path or is_inheritance(path):
                        continue
                    classified = classify_local_path(path)
                    if classified:
                        items.add(classified)

    return items


def collect_subagent_jsonls(jsonl_path: str) -> list[str]:
    sess_dir = jsonl_path.rsplit(".jsonl", 1)[0]
    sub_dir = os.path.join(sess_dir, "subagents")
    if not os.path.isdir(sub_dir):
        return []
    return sorted([
        os.path.join(sub_dir, f) for f in os.listdir(sub_dir)
        if f.startswith("agent-") and f.endswith(".jsonl")
    ])


def verify_subagent_attribution(parent_jsonl: str) -> dict:
    """For attribution audit: verify (a) subagent dir exists, (b) sub-agent
    count matches parent Task/Agent count, (c) sub-agent's sessionId field
    matches parent UUID."""
    parent_uuid = os.path.basename(parent_jsonl).rsplit(".jsonl", 1)[0]
    n_task_calls = 0
    with open(parent_jsonl, errors="replace") as f:
        for line in f:
            try:
                obj = json.loads(line)
            except: continue
            if obj.get("type") != "assistant": continue
            for c in obj.get("message", {}).get("content", []):
                if isinstance(c, dict) and c.get("type") == "tool_use" \
                        and c.get("name") in ("Task", "Agent"):
                    n_task_calls += 1
    sub_paths = collect_subagent_jsonls(parent_jsonl)
    n_sub_files = len(sub_paths)
    matches_uuid = []
    for sp in sub_paths:
        sub_session_id = None
        with open(sp, errors="replace") as f:
            for line in f:
                try:
                    obj = json.loads(line)
                except: continue
                if obj.get("sessionId"):
                    sub_session_id = obj["sessionId"]
                    break
        matches_uuid.append(sub_session_id == parent_uuid)
    return {
        "parent_uuid": parent_uuid,
        "parent_task_calls": n_task_calls,
        "subagent_files": n_sub_files,
        "count_match": n_task_calls == n_sub_files,
        "all_uuid_match": all(matches_uuid) if matches_uuid else None,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    out_dir = Path("<PROJECT>/runs/run_002/analysis/info_flow_data")
    out_dir.mkdir(parents=True, exist_ok=True)

    grand_total = 0
    parent_total = 0
    subagent_total = 0
    by_source_global: dict[str, int] = {}

    rows = []
    attribution_log = []

    for stage, label, jsonl in CANONICAL:
        if not os.path.exists(jsonl):
            print(f"  MISSING: {label}", file=sys.stderr)
            continue

        attribution = verify_subagent_attribution(jsonl)
        attribution["session"] = label
        attribution["stage"] = stage
        attribution_log.append(attribution)

        parent_items = walk_session_jsonl(jsonl)
        parent_total += len(parent_items)

        sub_paths = collect_subagent_jsonls(jsonl)
        sub_items_per_agent = []
        for sp in sub_paths:
            ag = walk_session_jsonl(sp)
            if ag:
                sub_items_per_agent.append(ag)
        sub_total = sum(len(x) for x in sub_items_per_agent)
        subagent_total += sub_total

        session_total = len(parent_items) + sub_total
        grand_total += session_total

        per_src: dict[str, int] = {}
        for src, _ in parent_items:
            per_src[src] = per_src.get(src, 0) + 1
        for ag in sub_items_per_agent:
            for src, _ in ag:
                per_src[src] = per_src.get(src, 0) + 1
        for src, n in per_src.items():
            by_source_global[src] = by_source_global.get(src, 0) + n

        rows.append({
            "stage": stage,
            "session": label,
            "parent_unique": len(parent_items),
            "n_subagents": len(sub_items_per_agent),
            "subagent_unique_total": sub_total,
            "session_total": session_total,
            "by_source": per_src,
        })
        sub_str = f"{len(sub_items_per_agent)}/{attribution['subagent_files']}" if attribution["subagent_files"] else "0"
        print(f"  {stage:18s} {label:30s}  parent={len(parent_items):3d}  "
              f"sub_dirs={sub_str}  sub_unique={sub_total:3d}  total={session_total:4d}",
              file=sys.stderr)

    # Audit summary
    sub_attr_problems = [a for a in attribution_log if a["subagent_files"] > 0
                         and (not a["count_match"] or a["all_uuid_match"] is False)]

    print(f"\n{'='*72}", file=sys.stderr)
    print(f"PARENT-AGENT TOTAL UNIQUE EVENTS:    {parent_total}", file=sys.stderr)
    print(f"SUB-AGENT TOTAL UNIQUE EVENTS:       {subagent_total}", file=sys.stderr)
    print(f"GRAND TOTAL UNIQUE EVENTS:           {grand_total}", file=sys.stderr)
    print(f"{'='*72}", file=sys.stderr)
    print(f"\nBy source channel:", file=sys.stderr)
    for src, n in sorted(by_source_global.items(), key=lambda x: -x[1]):
        print(f"  {src:35s} {n}", file=sys.stderr)

    print(f"\nSub-agent attribution audit:", file=sys.stderr)
    print(f"  Sessions with sub-agent dirs: {sum(1 for a in attribution_log if a['subagent_files']>0)}", file=sys.stderr)
    print(f"  Attribution failures: {len(sub_attr_problems)}", file=sys.stderr)
    if sub_attr_problems:
        for p in sub_attr_problems:
            print(f"    {p['session']}: parent_task_calls={p['parent_task_calls']} sub_files={p['subagent_files']} count_match={p['count_match']} uuid_match={p['all_uuid_match']}", file=sys.stderr)
    else:
        print(f"  All sub-agent dirs verified: count == parent_task_calls AND every sub-agent's sessionId == parent UUID", file=sys.stderr)

    out_path = out_dir / "literature_total_dedup.json"
    with open(out_path, "w") as f:
        json.dump({
            "grand_total_unique_events": grand_total,
            "parent_total_unique": parent_total,
            "subagent_total_unique": subagent_total,
            "by_source_global": by_source_global,
            "per_session": rows,
            "subagent_attribution_audit": attribution_log,
            "counting_rule": (
                "For each session (parent or sub-agent), unique (source, item) "
                "tuples count once. Source = semantic delivery+storage channel "
                "(NOT tool used): same source applies whether file accessed via "
                "Read tool or Bash cat/head/grep. Sub-agents are own sessions; "
                "their attribution is verified by sessionId field matching "
                "parent UUID + sub-agent file count == parent Task/Agent count. "
                "Inheritance reads (literature_notes, bibliography.bib, etc.) "
                "and user-download asks excluded."
            ),
        }, f, indent=2)
    print(f"\nWritten: {out_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
