#!/usr/bin/env python3
"""
literature_event_context.py — extract per-event literature-consultation
context from canonical run_002 sessions.

For every WebFetch, WebSearch, and Read of literature_access.md across all
canonical sessions, emits a JSON record containing:
  - tool: WebFetch | WebSearch | Read_literature_access
  - target: URL | query | file path
  - tool_prompt: WebFetch's `prompt` arg (the agent's question to the page)
  - pre_context: assistant text immediately preceding the tool call
  - post_context: assistant text immediately following (the agent's
    interpretation/use of the result)
  - surrounding_bash: any Bash commands within ±5 tool-use events
  - event_index: ordinal of this literature event in the session (0-based)

Outputs go to:
  runs/run_002/analysis/info_flow_data/literature_events/<stage>__<session>__<NN>.json

Imports the canonical session list from info_flow_extract.py to avoid drift.

Idempotent: safe to rerun. Output files are overwritten.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any

# Re-use the canonical table from sibling module
SCRIPT_DIR = Path(__file__).parent
sys.path.insert(0, str(SCRIPT_DIR))
from info_flow_extract import CANONICAL  # noqa: E402

PRE_POST_CHAR_LIMIT = 600   # how much surrounding text to keep
SURROUND_BASH_RANGE = 5     # ± events for Bash context


def is_literature_event(tool_use_item: dict) -> tuple[bool, str]:
    """Return (yes/no, label) — label is the event-class for output naming."""
    name = tool_use_item.get("name", "")
    inp = tool_use_item.get("input", {}) or {}
    if name == "WebFetch":
        return True, "WebFetch"
    if name == "WebSearch":
        return True, "WebSearch"
    if name == "Read":
        path = inp.get("file_path") or inp.get("path") or ""
        if "literature_access" in path:
            return True, "Read_literature_access"
    return False, ""


def extract_session_events(stage: str, label: str, jsonl_path: str) -> list[dict[str, Any]]:
    """Walk a session's jsonl and return list of literature-event records."""
    if not os.path.exists(jsonl_path):
        return []

    # First pass: build a flat ordered list of "items" — each item is either
    #   {kind: "text", text, line, ts}
    # or {kind: "tool_use", name, input, line, ts, tool_use_id}
    items: list[dict[str, Any]] = []
    with open(jsonl_path, "r", errors="replace") as f:
        for ln_idx, line in enumerate(f, start=1):
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("type") != "assistant":
                continue
            ts = obj.get("timestamp")
            msg = obj.get("message", {})
            content = msg.get("content", [])
            if not isinstance(content, list):
                continue
            for c in content:
                if not isinstance(c, dict):
                    continue
                ctype = c.get("type")
                if ctype == "text":
                    txt = c.get("text", "")
                    if isinstance(txt, str) and txt.strip():
                        items.append({
                            "kind": "text",
                            "text": txt,
                            "line": ln_idx,
                            "ts": ts,
                        })
                elif ctype == "tool_use":
                    items.append({
                        "kind": "tool_use",
                        "name": c.get("name", ""),
                        "input": c.get("input", {}) or {},
                        "line": ln_idx,
                        "ts": ts,
                        "tool_use_id": c.get("id", ""),
                    })

    # Second pass: locate literature events; emit per-event records with context.
    records: list[dict[str, Any]] = []
    event_index = 0
    for i, it in enumerate(items):
        if it["kind"] != "tool_use":
            continue
        is_lit, label_evt = is_literature_event(it)
        if not is_lit:
            continue

        inp = it["input"]
        # target + tool_prompt
        if it["name"] == "WebFetch":
            target = inp.get("url", "")
            tool_prompt = (inp.get("prompt") or "")
        elif it["name"] == "WebSearch":
            target = inp.get("query", "")
            tool_prompt = ""
        else:  # Read literature_access
            target = inp.get("file_path") or inp.get("path") or ""
            tool_prompt = ""

        # pre_context — most recent text item before this tool_use (window 6 items back)
        pre_chunks: list[str] = []
        for j in range(i - 1, max(-1, i - 8), -1):
            if items[j]["kind"] == "text":
                pre_chunks.insert(0, items[j]["text"])
                if sum(len(c) for c in pre_chunks) >= PRE_POST_CHAR_LIMIT:
                    break
            elif items[j]["kind"] == "tool_use":
                # Stop walking back — different tool indicates a different sub-action
                # (still keep the text we collected so far)
                break
        pre_context = "\n---\n".join(pre_chunks)
        if len(pre_context) > PRE_POST_CHAR_LIMIT:
            pre_context = pre_context[-PRE_POST_CHAR_LIMIT:]

        # post_context — next text item after this tool_use
        post_chunks: list[str] = []
        for j in range(i + 1, min(len(items), i + 8)):
            if items[j]["kind"] == "text":
                post_chunks.append(items[j]["text"])
                if sum(len(c) for c in post_chunks) >= PRE_POST_CHAR_LIMIT:
                    break
            elif items[j]["kind"] == "tool_use":
                # Allow chained literature events to flow into post but stop at
                # an unrelated computational tool (Bash etc.)
                if items[j]["name"] in ("WebFetch", "WebSearch"):
                    continue
                break
        post_context = "\n---\n".join(post_chunks)
        if len(post_context) > PRE_POST_CHAR_LIMIT:
            post_context = post_context[:PRE_POST_CHAR_LIMIT]

        # surrounding bash — any Bash commands within ±SURROUND_BASH_RANGE tool-use items
        surr_bash: list[dict[str, str]] = []
        tu_count = 0
        # Walk back
        for j in range(i - 1, -1, -1):
            if items[j]["kind"] == "tool_use":
                tu_count += 1
                if items[j]["name"] == "Bash":
                    surr_bash.append({
                        "direction": "before",
                        "cmd": (items[j]["input"].get("command") or "")[:200],
                        "desc": (items[j]["input"].get("description") or "")[:80],
                        "line": items[j]["line"],
                    })
                if tu_count >= SURROUND_BASH_RANGE:
                    break
        tu_count = 0
        for j in range(i + 1, len(items)):
            if items[j]["kind"] == "tool_use":
                tu_count += 1
                if items[j]["name"] == "Bash":
                    surr_bash.append({
                        "direction": "after",
                        "cmd": (items[j]["input"].get("command") or "")[:200],
                        "desc": (items[j]["input"].get("description") or "")[:80],
                        "line": items[j]["line"],
                    })
                if tu_count >= SURROUND_BASH_RANGE:
                    break

        records.append({
            "stage": stage,
            "session": label,
            "event_index": event_index,
            "tool": label_evt,
            "target": target,
            "tool_prompt": tool_prompt,
            "line": it["line"],
            "ts": it["ts"],
            "pre_context": pre_context,
            "post_context": post_context,
            "surrounding_bash": surr_bash,
        })
        event_index += 1

    return records


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out-dir", default="<PROJECT>/runs/run_002/analysis/info_flow_data/literature_events")
    p.add_argument("--validate", help="Only run a single session by label", default=None)
    args = p.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    total_events = 0
    sessions_with_events = 0

    for stage, label, jsonl in CANONICAL:
        if args.validate and label != args.validate:
            continue
        events = extract_session_events(stage, label, jsonl)
        if events:
            sessions_with_events += 1
        for ev in events:
            fname = f"{stage}__{label}__{ev['event_index']:03d}.json"
            with open(out_dir / fname, "w") as f:
                json.dump(ev, f, indent=2, default=str)
        total_events += len(events)
        print(f"  {stage:20s} {label:30s}  {len(events):3d} literature events", file=sys.stderr)

    # Index file: list of all events, ordered by (stage, session, event_index)
    if not args.validate:
        index = []
        for fp in sorted(out_dir.glob("*.json")):
            with open(fp) as f:
                ev = json.load(f)
            index.append({
                "stage": ev["stage"],
                "session": ev["session"],
                "event_index": ev["event_index"],
                "tool": ev["tool"],
                "target": ev["target"][:120],
                "file": fp.name,
            })
        with open(out_dir / "_index.json", "w") as f:
            json.dump(index, f, indent=2)
        print(f"\nTotal literature events: {total_events}", file=sys.stderr)
        print(f"Sessions with at least one literature event: {sessions_with_events}/47", file=sys.stderr)
        print(f"Index written to {out_dir / '_index.json'}", file=sys.stderr)


if __name__ == "__main__":
    main()
