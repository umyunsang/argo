# Audit report — categorization of 11,083 corpus papers into 12 themes

This document records the hard cases, residual ambiguity, and coverage validation for the categorization defined in `categories.md` and implemented in `categorize.py`. The four output artefacts (this file, `categories.md`, `paper_categorization.json`, `paper_count_per_category.csv`) are mutually self‑consistent — running `categorize.py` on `corpus.db` reproduces the JSON and the CSV byte‑for‑byte.

---

## A. Quantitative summary

| Category | n_papers | % | n_breadth_touched | n_depth_cited |
|---|---:|---:|---:|---:|
| altermagnetism             | 344  | 3.1 %  | 111 | 34 |
| chiral_phonon              | 84   | 0.8 %  | 33  | 4  |
| moire_flatband             | 353  | 3.2 %  | 86  | 0  |
| unconventional_SC          | 678  | 6.1 %  | 147 | 1  |
| correlated_electrons       | 1307 | 11.8 % | 127 | 1  |
| topology_quantum_geometry  | 1375 | 12.4 % | 123 | 5  |
| 2D_magnets_spintronics     | 402  | 3.6 %  | 31  | 0  |
| ferroelectric_multiferroic | 293  | 2.6 %  | 20  | 0  |
| ultrafast_Floquet_cavity   | 437  | 3.9 %  | 22  | 0  |
| MLIP_methods               | 988  | 8.9 %  | 109 | 0  |
| energy_devices             | 1090 | 9.8 %  | 42  | 0  |
| defects_color_centers      | 221  | 2.0 %  | 12  | 0  |
| **other**                  | 3511 | 31.7 % | 8   | 0  |
| **total**                  | 11083 | 100 % | 871 | 45 |

(Breadth: 877 union IDs of which 871 are in‑corpus; 6 web‑only breadth IDs are not counted here. Depth: 53 union IDs of which 45 are in‑corpus; 8 web‑only depth IDs are not counted here.)

**Coverage of breadth IDs.** 863 of 871 in‑corpus breadth IDs land in a non‑other category — 99.1 % overall, well above the 90 % requirement. Per agent: breadth_01 327/332 = 98.5 %; breadth_02 421/425 = 99.1 %; breadth_03 316/317 = 99.7 %.

**Coverage of depth IDs.** All 45 in‑corpus depth‑cited IDs land in a non‑other category — 100 %.

**Spread of category sizes.** All categories sit between 0.8 % and 12.4 %. The advisory floor was 2 %; only `chiral_phonon` falls below at 0.8 % — see §C.1 for justification. The advisory ceiling was 40 %; the top three (`topology_quantum_geometry` 12.4 %, `correlated_electrons` 11.8 %, `energy_devices` 9.8 %) are well below.

---

## B. Breadth‑cited IDs that fell into "other" (n = 8)

These are the only breadth‑cited papers I could not place in one of the 12 themed categories. After re‑reading the abstracts, all eight are genuinely off‑theme relative to the agents' research focus and the depth program search space:

| arXiv ID | Title (truncated) | Why "other" is correct |
|---|---|---|
| 2602.12335 | Symmetric Gapped States and Symmetry‑Enforced Gaplessness in 3‑dimension | Lattice gauge theory / quantum field theory framework — not a condensed‑matter materials category. |
| 2603.12326 | All‑electron dark matter–electron scattering with RPA dielectric screening | Direct dark‑matter detection in solids; uses cond‑mat methods but the research thread is astroparticle, not the agents' depth space. |
| 2603.21290 | Non‑invertible symmetries and boundary conditions for the transverse‑field Ising model | Categorical / generalized symmetries; high‑energy formal physics. Methods are field‑theoretic, not first‑principles. |
| 2510.19891 | A unified picture of phonon anomalies in crystals and glasses | Genuine phonon‑physics review crossing crystal–glass dichotomy; the breadth_03 report flagged it under §1.7 (phonons) but it doesn't match my chiral‑phonon pattern (no chirality / Hall / angular‑momentum / topology vocabulary). |
| 2512.16819 | Thermodynamical study of N₂ clathrate hydrate from DFT calculations | Physical chemistry / planetary science; uses DFT but the molecule is N₂ clathrate. |
| 2604.10163 | Hall transports from Taub‑NUT AdS black holes | hep‑th holographic transport; "Hall" word in title is a high‑energy‑theory abstraction, not condensed matter. |
| 2603.03557 | A Pathway Selection Process for Dynamically Self‑Organizing Systems | Mathematical / nonlinear physics generic framework. |
| 2604.02856 | Type‑IV 't Hooft Anomalies on the Lattice: LSM Systems | Lattice gauge / categorical anomalies; high‑energy formal. |

**Decision.** I did not extend my regexes to capture these because every plausible extension (e.g. adding `\bHall\b` alone) would balloon the topology category by hundreds of false positives. Living with 8 misses keeps the regex precision high.

**Note on additional improvements.** I found that introducing LaTeX normalization (stripping `$...$`, `_2`, `^{...}`) increased breadth coverage from 96.8 % to 99.1 %, mainly by catching papers with formulas like `RuO$_2$` that the plain‑ASCII patterns missed. The normalization is implemented in `categorize.normalize_text()`; the categorizer matches against both the original and the normalized text, so a paper is in the category if *either* form matches a pattern.

---

## C. Hard category decisions and what I would change with more time

### C.1 Why `chiral_phonon` is below the 2 % floor (84 papers, 0.8 %)

The advisory in the prompt was "no category < 2 %". `chiral_phonon` violates this, and I considered four alternatives:

1. **Merge into `2D_magnets_spintronics`.** This dilutes depth_03's signal — the chiral‑phonon thread is the single bottom‑up reason depth_03 exists, and the breadth report explicitly calls out PAMHE / phonon‑angular‑momentum as an emerging field. Merging would erase the only category that lets the figure x‑axis show "depth_03 picks the chiral‑phonon thread".
2. **Merge into `topology_quantum_geometry`.** Topology is already the largest category; chiral phonons are conceptually distinct (they're about phonon angular momentum / mechanical chirality, not electronic band topology) and would be invisible inside it.
3. **Drop chiral_phonon, drop depth_03 from the figure.** Doesn't satisfy the requirement that all 5 depth programs map to a category.
4. **Broaden chiral_phonon to "phonon engineering & spin‑lattice coupling"** — pulled in too many off‑theme papers (NMR, type‑II multiferroic) that don't share the chiral‑phonon community.

I chose to keep chiral_phonon at 0.8 % with a clear rationale in `categories.md §2`. **The advisory "no category < 2 %" should be relaxed in this case** because chiral_phonon is the unambiguous home of one of the five depth programs. If the figure absolutely needs every category ≥ 2 %, the only honest move is to merge chiral_phonon with `2D_magnets_spintronics` and footnote the depth_03 chiral‑phonon thread separately.

### C.2 RuO₂ in `altermagnetism`

The 2024–2026 RuO₂ literature is *about* whether RuO₂ is altermagnetic (the dominant late‑2025 / early‑2026 view: it is *not*). Of the ~38 RuO₂ papers in the corpus, 19 land in `altermagnetism` because the abstract explicitly engages with the altermagnet question; the other ~19 (those discussing RuO₂'s ruthenate cousins like Sr₂RuO₄, SrRuO₃, double perovskite ruthenates) drop into `correlated_electrons` or `unconventional_SC`. This was a deliberate call: the depth_05 program literature reviewing RuO₂ as a *negative* benchmark for altermagnet NMR (e.g. 2511.00399, 2603.16125, 2603.28355, 2604.10659) requires that RuO₂‑altermagnet papers stay in the altermagnet bucket.

### C.3 Heavy‑fermion SC vs altermagnet SC vs strongly‑correlated kagome

CeRu₃Si₂ (2603.27408), the first heavy‑fermion kagome SC, is interesting because it matches `unconventional_SC` (kagome SC pattern), `correlated_electrons` (heavy fermion / kagome), and is breadth‑cited by all three agents. With the precedence rule, it primary‑categorizes as `unconventional_SC` and lists `correlated_electrons` as secondary. This seems right for the figure, but I want to flag that ~30 papers like this sit at the boundary.

### C.4 The depth_04 program is hard

Out of 4 cited IDs, 1 (2511.16422 "Dissipation‑Shaped Quantum Geometry in Nonlinear Transport") is the only one that lands cleanly in `topology_quantum_geometry`. The other 3:
- **2603.27505** (review on unconventional magnetism, depth_04 cites it) — primary `altermagnetism` (it's the SSG framework review)
- **2604.03183** (anomalous thermal Hall in altermagnets) — primary `altermagnetism`
- **2504.04424** (TensorSymmetry) — outside the corpus window (web‑only)

This is correct: depth_04's research direction (SOC‑resilience nonlinear Hall in non‑coplanar AFM) draws on quantum‑geometry literature (the in‑corpus citation), uses the SSG framework from altermagnetism (the review), and cites the AM thermal‑Hall observation (also altermagnetism). The figure should show depth_04 connecting to **both** `topology_quantum_geometry` and `altermagnetism`.

### C.5 `MLIP_methods` boundary

I tightened MLIP_methods after an initial draft included a too‑broad "machine learning" clause that pulled in 1,649 papers (14.9 %), much larger than the actual methodology community. The final version requires either (a) named MLIP packages, (b) explicit "machine‑learning interatomic potential" / "graph neural network potential", (c) named LLM/AI‑agent stacks, (d) named methodology packages (DMFT, GW+BSE, CCSD(T), DMRG, QEDFT, …), or (e) explicit method headers ("hybrid functional", "meta‑GGA"). 988 papers (8.9 %) is consistent with breadth_02's "MLIP 240" + breadth_01's "MACE/Equiformer/etc. 255+" + LLM agents (~50) + neural quantum states (~21) + advanced DFT methods (~150) = ~700+ in the dominant tally; my number adds a ~300 long tail of less‑prominent method papers I'd not have caught at the breadth review level.

### C.6 The 50 most‑ambiguous papers (those with primary + 2 or 3 secondary)

There are 869 papers with ≥ 2 secondary categories (7.8 % of the corpus). Of these, 21 are depth‑cited and 195 are breadth‑cited. Below are the 50 I considered most ambiguous, prioritized by depth → breadth → other. For each, I list the chosen primary, the secondaries, and a one‑line note on the call.

The full top‑50 list lives in `paper_categorization.json` (look for entries where `len(secondary) >= 2`). In summary, the precedence rule "altermagnetism first" decides almost all the depth‑cited cases (e.g. 2603.11483 Floquet altermagnet orbital Hall — primary AM, secondary topology + 2D magnets + ultrafast — chosen because the paper is fundamentally about altermagnetism with Floquet driving, not the other way around). The ambiguities are not bugs in the categorization; they reflect the genuinely cross‑pollinated 2025–2026 cond‑mat landscape.

| arXiv ID | Primary | Secondaries (≥2) | One‑line judgement |
|---|---|---|---|
| 2512.15859 (D)| altermagnetism | chiral_phonon, moire_flatband, correlated_electrons | AM quasiparticle lifetimes — AM is the central object |
| 2603.27505 (D)| altermagnetism | moire_flatband, topology_quantum_geometry, 2D_magnets_spintronics | The SSG review for altermagnets |
| 2604.01899 (D)| chiral_phonon | correlated_electrons, topology_quantum_geometry, energy_devices | PAMHE atomistic theory — chiral phonons is the topic |
| 2604.04719 (D)| unconventional_SC | correlated_electrons, topology_quantum_geometry, energy_devices | Two‑Channel Allen‑Dynes — SC framework, not AM |
| 2603.11483 (D)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics, ultrafast_Floquet_cavity | Floquet‑driven AM orbital Hall — AM is the system |
| 2511.16421 (D)| altermagnetism | correlated_electrons, topology_quantum_geometry | Linear magneto‑birefringence as AM probe |
| 2601.19343 (D)| altermagnetism | topology_quantum_geometry, ferroelectric_multiferroic | Multipolar order in AM MnF₂ via elastocaloric |
| 2602.05894 (D)| altermagnetism | moire_flatband, topology_quantum_geometry | Topological piezomagnetic effect in 2D Dirac quadrupole AM |
| 2602.09465 (D)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics | Tight‑binding model for V₂Se₂O AM |
| 2603.00622 (D)| altermagnetism | 2D_magnets_spintronics, ferroelectric_multiferroic | Sliding‑FE AM in vdW heterostructure |
| 2603.10907 (D)| altermagnetism | 2D_magnets_spintronics, ferroelectric_multiferroic | Sliding‑FE AM multilayer spin‑layertronics |
| 2603.21969 (D)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics | Spin‑selective tunneling in AM KV₂Se₂O |
| 2603.25820 (D)| altermagnetism | topology_quantum_geometry, energy_devices | Magnetotransport in AM CrSb |
| 2604.00838 (D)| altermagnetism | unconventional_SC, topology_quantum_geometry | SC at 16.3 K in AM Na₂V₂Se₂O — the headline paper |
| 2604.03183 (D)| altermagnetism | chiral_phonon, topology_quantum_geometry | AM thermal Hall observation |
| 2604.06114 (D)| altermagnetism | correlated_electrons, 2D_magnets_spintronics | Fe₂PO₅ room‑T AM with charge disproportionation |
| 2604.06959 (D)| topology_quantum_geometry | 2D_magnets_spintronics, ferroelectric_multiferroic | Spin‑driven multiferroic NiI₂ + topological textures |
| 2604.10612 (D)| altermagnetism | 2D_magnets_spintronics, ferroelectric_multiferroic | 2D spin‑antiferroelectric AM |
| 2604.11361 (D)| altermagnetism | topology_quantum_geometry, ultrafast_Floquet_cavity | Ultrafast ghost Hall states in 2D AM |
| 2602.04245 (D)| correlated_electrons | topology_quantum_geometry, 2D_magnets_spintronics | Piezomag in non‑coplanar AFMs (CoNb₃S₆/CoTa₃S₆) |
| 2603.00442 (D)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics | Altermagnetic XMCD in hematite |
| 2510.12748 (B)| altermagnetism | chiral_phonon, topology_quantum_geometry, 2D_magnets_spintronics | 2D AM iron oxyhalides with Chern topology |
| 2511.01370 (B)| unconventional_SC | topology_quantum_geometry, 2D_magnets_spintronics, ferroelectric_multiferroic | Hyperferroelectric + topological + Rashba in wurtzite LiZnAs — SC keyword wins precedence over FE in this case (the paper is about giant Rashba SC potential) |
| 2512.01253 (B)| topology_quantum_geometry | ferroelectric_multiferroic, ultrafast_Floquet_cavity, energy_devices | THz‑induced FE in SrTiO₃ — primary by topological/multipole framework |
| 2512.17596 (B)| correlated_electrons | topology_quantum_geometry, 2D_magnets_spintronics, MLIP_methods | Kitaev‑Heisenberg ladder topology |
| 2512.20424 (B)| unconventional_SC | ferroelectric_multiferroic, MLIP_methods, energy_devices | Iterative learning for crystal‑structure SC prediction |
| 2601.01843 (B)| unconventional_SC | correlated_electrons, topology_quantum_geometry, energy_devices | Multiple nodal SC phases in pressurized UTe₂ |
| 2602.10641 (B)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics, ferroelectric_multiferroic | Antiferroaxial altermagnetism |
| 2602.19713 (B)| altermagnetism | moire_flatband, 2D_magnets_spintronics, energy_devices | Strain/Field‑tunable spin splitting in twisted bilayer AM |
| 2603.00242 (B)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics, defects_color_centers | AHE conductivity scaling in α‑MnTe |
| 2603.01329 (B)| altermagnetism | correlated_electrons, topology_quantum_geometry, 2D_magnets_spintronics | Non‑collinear AM phases in Mott NiS₂ |
| 2603.06486 (B)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics, ultrafast_Floquet_cavity | Light‑induced AHE + topological transitions in AM TI |
| 2603.20849 (B)| moire_flatband | correlated_electrons, topology_quantum_geometry, energy_devices | Twist‑induced QG reconfiguration in moiré flat bands |
| 2603.25317 (B)| altermagnetism | chiral_phonon, moire_flatband, correlated_electrons | Flat‑band charge/spin instabilities in AM CrSb |
| 2603.25516 (B)| altermagnetism | topology_quantum_geometry, 2D_magnets_spintronics, ferroelectric_multiferroic | Photogalvanic effects in p‑wave magnet NiI₂ |
| 2604.03644 (B)| chiral_phonon | correlated_electrons, topology_quantum_geometry, energy_devices | Interaction‑driven transverse thermal resistivity in phonon gas |
| 2604.10019 (B)| correlated_electrons | topology_quantum_geometry, 2D_magnets_spintronics, ferroelectric_multiferroic | Exchange frustration + topological magnetism in doped SrRuO₃ |
| 2512.07947 (B)| moire_flatband | unconventional_SC, topology_quantum_geometry, MLIP_methods | NQS study of QG‑driven crystallization |
| 2512.18217 (B)| moire_flatband | correlated_electrons, topology_quantum_geometry, 2D_magnets_spintronics | Electronic phonons in moiré electron crystal |
| 2512.23084 (B)| moire_flatband | correlated_electrons, topology_quantum_geometry, energy_devices | Topological electron crystals in bilayer graphene–Mott heterostructures |
| 2601.03366 (B)| altermagnetism | unconventional_SC, correlated_electrons, 2D_magnets_spintronics | AM SC diode in Mn₃Pt/Nb |
| 2601.13283 (B)| chiral_phonon | correlated_electrons, topology_quantum_geometry, 2D_magnets_spintronics | Surface phonon Hall viscosity in magnetic TI films |
| 2604.05311 (B)| altermagnetism | moire_flatband, correlated_electrons, topology_quantum_geometry | Spin‑biased QSH in altermagnetic Lieb lattice |
| 2510.19943 (B)| altermagnetism | moire_flatband, unconventional_SC, topology_quantum_geometry | QG/impurity sensitivity of TRS‑broken SC; applied to RG and AMs |
| 2603.10552 (B)| unconventional_SC | correlated_electrons, topology_quantum_geometry, energy_devices | Kondo hybridization wave in UTe₂ |
| 2603.13604 (B)| unconventional_SC | correlated_electrons, topology_quantum_geometry, MLIP_methods | Hybridization‑induced SC correlations in bilayer nickelates |
| 2604.01596 (B)| altermagnetism | unconventional_SC, topology_quantum_geometry, ultrafast_Floquet_cavity | Chiral SC in periodically driven AM/SC heterostructures |
| 2511.19567 (B)| moire_flatband | unconventional_SC, correlated_electrons, topology_quantum_geometry | PDW in FQH at even denominator |
| 2602.15020 (B)| unconventional_SC | correlated_electrons, 2D_magnets_spintronics, defects_color_centers | Majorana signatures in tunneling through a Kitaev spin liquid |
| 2603.18537 (B)| unconventional_SC | correlated_electrons, topology_quantum_geometry, MLIP_methods | Resonance of kagome flat band doublet |

Three judgement calls flagged for reviewers:

1. **2511.01370 "Intertwined Hyperferroelectricity, Tunable Multiple Topological Phases and Giant Rashba Effect in Wurtzite LiZnAs"** (B) — chosen primary `unconventional_SC` because the abstract focuses on Rashba effect → potential for non‑centrosymmetric SC. A defensible alternative is `ferroelectric_multiferroic` (the paper is centrally about hyperferroelectricity). I'd accept either.
2. **2602.04245 "Piezomagnetic transport in van der Waals noncoplanar Antiferromagnets"** (D, depth_02 cited) — chosen primary `correlated_electrons` because the materials are CoNb₃S₆ / CoTa₃S₆, archetypal vdW non‑coplanar AFMs. The paper *uses* piezomagnetism, but it's about non‑coplanar AFM transport, which is closer to depth_04's territory than depth_02's altermagnetic piezomagnetism. The right‑most call on this is "this paper bridges depth_02 and depth_04, primary by material", which I'll accept.
3. **2604.06959 "Microscopic evidence of spin‑driven multiferroicity and topological spin textures in monolayer NiI₂"** (D, depth_03 cited) — chosen primary `topology_quantum_geometry` because the abstract leads with "topological spin textures" and the paper is fundamentally about a 2D *multiferroic*‑topology combination, not chiral phonons. depth_03 cites it as motivation for including NiI₂ in the chiral‑phonon material set, but the paper itself is about topology/multiferroicity. A reviewer who insisted depth_03's NiI₂ thread should land in `chiral_phonon` could move this one record; the figure structure would not change.

---

## D. Pairwise overlap structure (residual cross‑category)

The largest primary→secondary co‑occurrences (ordered):

| Primary → Secondary | Count |
|---|---:|
| correlated_electrons → topology_quantum_geometry | 295 |
| unconventional_SC → correlated_electrons | 249 |
| topology_quantum_geometry → 2D_magnets_spintronics | 226 |
| correlated_electrons → energy_devices | 226 |
| MLIP_methods → energy_devices | 220 |
| moire_flatband → topology_quantum_geometry | 183 |
| correlated_electrons → MLIP_methods | 179 |
| unconventional_SC → topology_quantum_geometry | 176 |
| correlated_electrons → 2D_magnets_spintronics | 159 |
| topology_quantum_geometry → energy_devices | 145 |
| altermagnetism → 2D_magnets_spintronics | 142 |
| correlated_electrons → ultrafast_Floquet_cavity | 134 |
| altermagnetism → topology_quantum_geometry | 133 |
| topology_quantum_geometry → ultrafast_Floquet_cavity | 122 |
| moire_flatband → correlated_electrons | 112 |

Reading these:
- The **correlated_electrons ↔ topology_quantum_geometry** edge (295) reflects the genuine cross‑cutting structure of 2025–2026 cond‑mat: kagome materials (correlated) host topological flat bands (topology); Hubbard models on triangular lattices give Chern insulators; Kitaev fractionalization gives anyons. This is reality, not a categorization defect.
- The **unconventional_SC → correlated_electrons** edge (249) is similarly real: cuprate / nickelate / heavy‑fermion SC sits inside the strongly correlated landscape.
- The **MLIP_methods → energy_devices** edge (220) reflects the dominant 2026 application of foundation MLIPs: thermoelectric / battery / catalyst screening.
- The **altermagnetism → 2D_magnets_spintronics** edge (142) and **altermagnetism → topology_quantum_geometry** (133) show that altermagnetism is methodologically a 2D‑magnet / topology phenomenon, but the precedence rule lets the figure column show "altermagnet" cleanly without diluting into the bigger buckets.

**Symmetry note.** I did NOT compute the reverse direction systematically (e.g. how many `topology_quantum_geometry` papers have `altermagnetism` as a secondary?). By construction this is small — by precedence, anything that matches both AM and topology lands primary in AM. This means the "altermagnetism" category absorbs the AM‑topology cross set and the secondaries column lists which other themes it touches; the reverse (a topology paper touching altermagnetism) only happens for papers where the AM regex doesn't match (e.g. a generic Berry‑curvature paper that happens to apply to AMs — those are rare).

---

## E. The "other" pool (3,511 papers, 31.7 %)

Distribution by arXiv primary submission category:

| arXiv primary | n | Predominant content |
|---|---:|---|
| cond-mat.mtrl-sci | 886 | Specific applied materials / heterostructures / dislocations / dopants / alloys / 2D semiconductors not on AM/moiré/SC themes |
| cond-mat.mes-hall | 408 | Quantum dots, transistors, nanostructures, nanoelectronics not under topology/2D‑mag/spintronics |
| physics.chem-ph | 329 | Molecular chemistry, organometallics, electronic excited states of small molecules |
| quant-ph | 240 | Quantum information / quantum computing / open systems / atomic physics not coupled to a cond‑mat material category |
| physics.comp-ph | 216 | Generic computational methods (numerical PDE, solver algorithms, GPU codes) without a clear MLIP/MD framing |
| cond-mat.str-el | 192 | Strongly correlated theory papers without specific keyword anchors (e.g. lattice‑gauge theories of fractionalization) |
| cond-mat.supr-con | 158 | SC papers that don't mention specific families (cuprate, nickelate, hydride, kagome, topological, FFLO, …) |
| cond-mat.soft | 126 | Polymers, colloids, active matter — entirely different community |
| physics.optics | 119 | Photonics / waveguides / metasurfaces — applied optics |
| physics.flu-dyn | 94 | Fluid dynamics |
| cond-mat.stat-mech | 79 | Lattice gases, Ising / Potts, equilibrium / nonequilibrium statistical mechanics not coupled to a quantum‑material category |
| cs.LG | 63 | Generic ML papers cross‑listed but not about MLIP for atomistic systems |
| hep-th | 59 | Holography, string theory, anomalies, lattice QCD |
| math.NA | 57 | Numerical analysis |
| physics.plasm-ph | 38 | Plasma physics |

**Decision.** This is the right "other" composition: ~75 % is non‑theme cond‑mat / chem / comp / soft / optics / fluid / statmech / hep‑th, and ~25 % is generic mtrl‑sci / mes‑hall papers without specific physics keywords. Splitting "other" further (e.g. into "soft & fluid", "chemistry", "high‑energy & lattice", "applied materials") would not help the figure: the agents did not search these, and the depth programs do not target them.

---

## F. Reproducibility checklist

- **Input data.** `<PROJECT>/corpus/corpus.db` — 11,083 rows, all with non‑empty abstracts.
- **Categorizer.** `categorize.py` in this directory — pure Python 3 stdlib; no external dependencies; defines `CATEGORIES` (12 patterns + precedence), `normalize_text`, `categorize`, `categorize_all`.
- **Run command.**
  ```python
  import sqlite3
  from categorize import categorize_all
  conn = sqlite3.connect('corpus.db')
  cur = conn.cursor()
  cur.execute("SELECT arxiv_id, title, COALESCE(abstract,'') FROM papers")
  papers = cur.fetchall()
  result = categorize_all(papers)  # returns {arxiv_id: (primary, secondary_list)}
  ```
- **Verification.** Running this on a fresh checkout of `corpus.db` reproduces `paper_categorization.json` byte‑for‑byte (modulo ordering — the JSON is keyed by arxiv_id, so insertion order is determined by SQL row order).
- **Coverage check.** The script prints non‑other coverage for breadth (99.1 %) and depth (100.0 %).
- **Stability across LaTeX variants.** Both `RuO2` and `RuO$_2$` match the pattern `\bRuO2\b` after normalization. Tests for `MnBi$_2$Te$_4$`, `Bi$_2$Sr$_2$CaCu$_2$O$_{8+x}$`, `MnTe`, `KV$_2$Se$_2$O`, `CrPS$_4$` all pass.

---

## G. Recommended changes to the existing `_fig2_data2.py` THEMES list

The existing 11‑theme list in `_fig2_data2.py` is:

  altermag, moiré, kagome, nickelate, cuprate, topo./QG, 2D mag, ML pot., chiral phon, ferro/piezo, ultrafast

I recommend replacing it with the 12‑category list from `categories.md`, with these explicit changes:

| Current theme | Recommended replacement | Why |
|---|---|---|
| altermag | altermagnetism | identical; use the longer form for clarity |
| moiré | moire_flatband | broader, includes rhombohedral graphene + FQAH which are both prominent |
| kagome | (merged into) correlated_electrons | kagome alone is too narrow; the corpus's "kagome" thread overlaps heavily with frustrated magnetism, heavy fermion, Mott insulator |
| nickelate | (merged into) unconventional_SC | nickelate is one material family; the unconventional_SC bucket includes nickelate + cuprate + hydride + Majorana + kagome SC + UTe₂ |
| cuprate | (merged into) unconventional_SC | as above |
| topo./QG | topology_quantum_geometry | broader; includes nonlinear Hall, axion, non‑Hermitian, HOTI, multipole order |
| 2D mag | 2D_magnets_spintronics | identical name |
| ML pot. | MLIP_methods | broader; includes MLIPs + foundation models + LLM agents + neural quantum states + advanced DFT methods |
| chiral phon | chiral_phonon | identical; broaden to include magnon‑phonon coupling + nonlinear phononics + magnetoacoustic |
| ferro/piezo | ferroelectric_multiferroic | broader; includes ferroaxial, electrocaloric, magnetocaloric |
| ultrafast | ultrafast_Floquet_cavity | broader; includes cavity QED, polaritons, excitonic insulators, open systems |
| (none) | correlated_electrons | NEW; absorbs kagome + heavy fermion + Hubbard + Kitaev + spin liquids + CDW + strange metal + iridates |
| (none) | energy_devices | NEW; the 9.8 % corpus thread on batteries / thermoelectrics / catalysis / hydrogen / HEAs / halide PVs |
| (none) | defects_color_centers | NEW; the 2.1 % corpus thread on NV centers / single‑photon emitters / qubit materials / point defects |

Net change: +3 categories (correlated_electrons, energy_devices, defects_color_centers), −2 categories (kagome → correlated_electrons; nickelate+cuprate → unconventional_SC). The 12‑category set is more balanced (no category < 0.8 % or > 12.4 %) and gives all five depth programs an unambiguous primary home.
