# Categories — definitive list

**Scope:** 11,083 arXiv papers, 2025‑10‑14 → 2026‑04‑13, drawn from cond‑mat.{mtrl‑sci, mes‑hall, supr‑con, str‑el}, physics.{chem‑ph, comp‑ph} plus cross‑listed neighbours.

**Method.** Each paper's `title + " " + abstract` is matched (case‑insensitive Python regex) against an ordered list of 12 inclusion patterns. The first match assigns the **primary** category; the next 0–3 matches are recorded as **secondary** (informational only — the figure uses primary). LaTeX formatting (`$_2$`, `\\mathrm{...}`) is stripped before matching so chemical formulas like `RuO$_2$` and `MnBi$_2$Te$_4$` match plain‑ASCII patterns. Reproducible reference implementation: `categorize.py` in this directory.

**Precedence design.** The 3 narrowest, most concentrated topical bursts come first (altermagnetism, chiral phonons, moiré). They are followed by material‑family categories (unconventional SC, 2D magnets, ferroelectric, defects) and broad‑physics categories (correlated electrons, topology + quantum geometry, ultrafast/Floquet/cavity), with methods and energy materials at the back. This ensures that, e.g., a paper on **piezomagnetism in altermagnets** lands in `altermagnetism`, not in `2D_magnets_spintronics` or `topology_quantum_geometry`, even though all three patterns match.

**Sanity bands.** Every category is between 0.8 % and 12.5 % of the corpus. Total non‑other coverage of breadth‑cited IDs = 99.1 % (863 of 871 in‑corpus). Total non‑other coverage of depth‑cited IDs = 100 % (45 of 45 in‑corpus). Detailed audit in `audit_report.md`.

---

## 1. `altermagnetism` — 344 papers (3.1 %)

**Definition.** Collinear magnets with non‑relativistic momentum‑dependent spin splitting (the `d/g/i`‑wave even‑parity family) and their odd‑parity siblings (`p/f/h/j`‑wave magnets). Includes the disputed RuO₂ literature, vanadium oxychalcogenides (KV₂Se₂O, Na₂V₂Se₂O, CsV₂Se₂O, RbCr₂Se₂O), MnTe, CrSb, Fe₂PO₅, MnF₂, the spin‑space‑group framework, and "alterelectricity / alterferroicity" siblings. Piezomagnetism, NMR, multipole, sliding‑FE‑coupled, and SC‑proximate variants of altermagnets all live here too — these are the depth_02, _03 (spin‑lattice subset), _04 (anomalous‑thermal‑Hall subset), and _05 sub‑threads.

**Inclusion regex.** `altermagnet|alterelectric|alterferr|alter[\- ]magn | RuO2|RuO_2 | d-wave magnet|g-wave magnet|i-wave magnet|p-wave magnet|f-wave magnet|h-wave magnet|j-wave magnet | KV2Se2O|Na2V2Se2O|RbCr2Se2O|CsV2Se2O|CsCr2S2O | hidden magnet|nonrelativistic spin splitting|non-relativistic spin splitting|spin-space group|spin space group|NRSS | WFeB.altermagnet|Fe2PO5.altermagnet|V_2Se_2O.altermagnet|V2Se2O.altermagnet`

**Exclusion.** None — the pattern is narrow enough that false positives are <1 % (almost entirely RuO₂‑related papers from the 2024 controversy that don't *say* "altermagnet" but live in the AM‑debate literature).

**Rationale.** Three of the five depth programs (depth_01 Tc, depth_02 piezomagnetism, depth_05 NMR) are altermagnet sub‑threads, and depth_04's central paper (2604.03183 thermal Hall in altermagnets) also lands here. The category absorbs 322 papers that the breadth_01 theme scan flagged as the single most concentrated burst in the corpus. Splitting AM into AM‑bulk / AM‑SC / AM‑phonon would have made the figure x‑axis crowded; the secondary‑category column (142 → `2D_magnets_spintronics`, 133 → `topology_quantum_geometry`, 52 → `correlated_electrons`) tells the same sub‑structure story without splitting the primary axis.

**Depth coverage.** 34/45 depth‑cited IDs (76 %) — d1: 9/9 in‑corpus, d2: 13/14 in‑corpus, d4: 2/3 in‑corpus, d5: 22/23 in‑corpus.

---

## 2. `chiral_phonon` — 84 papers (0.8 %)

**Definition.** Chiral phonons (carrying angular momentum), phonon Hall effect, phonon thermal Hall, phonon angular‑momentum Hall (PAMHE), topological phonons, magnon‑phonon coupling, spin‑phonon coupling, nonlinear phononics, and magnetoacoustic resonance. The depth_03 program (chiral phonons in 2D vdW magnets) lives almost entirely here.

**Inclusion regex.** `chiral phonon|phonon angular momentum|phonon chirality|phonon magnetic moment | phonon Hall effect|phonon thermal Hall|phonon Hall|phonon Hall conductivity | phonon[ \-]induced[ \-]magnet | thermal Hall.{0,40}phonon|phonon[ \-]rotat|phonon[ \-]circular | phonon[ \-]Berry|phonon[ \-]topology|topological phonon|topological phonons | PAMHE|phonon Lz|phonon L^z|phonon[ \-]Weyl|phonon[ \-]Dirac | magnon[ \-]phonon|phonon[ \-]magnon|spin[ \-]phonon coupling|spin[ \-]phonon hybridi | spin[\- ]lattice coupling | nonlinear phononic | magnetoacoustic resonance|magnetoacoustic wave|magnetoelastic mode|magneto[\- ]elastic mode`

**Exclusion.** None.

**Rationale.** depth_03 is the only depth program that lives outside altermagnetism, and its central observable (chiral phonons / phonon angular momentum) has formed a coherent emerging field around three 2026 papers (2604.01899 PAMHE theory, 2604.10231 chirality measure, 2603.03635 INS observation). Without this category, depth_03 would land in either `2D_magnets_spintronics` (where the chiral‑phonon thread would dilute) or `topology_quantum_geometry` (where it would mix with band topology). At 0.8 % of the corpus this category is below the 2 % advisory floor — see audit_report §C.1 for justification.

**Depth coverage.** 4/45 depth‑cited IDs — d3: 4/7 in‑corpus (the other 3 d3 IDs are 2D vdW magnetic insulator papers that fall in `topology_quantum_geometry` (NiI₂ multiferroic, CrI₃ topological magnon) or `altermagnetism` (the route‑to‑AM‑via‑light paper)).

---

## 3. `moire_flatband` — 353 papers (3.2 %)

**Definition.** Moiré superlattices (twisted bilayer/trilayer/multilayer; magic‑angle), rhombohedral graphene multilayers (N = 3…13), helical trilayer graphene, fractional quantum anomalous Hall (FQAH), fractional Chern insulators, composite‑fermion / composite‑Fermi‑liquid / composite‑boson theory, anomalous‑Hall crystals, metallic Wigner crystals, electron crystals, and non‑graphene flat‑band materials (Lieb, Sierpinski, dice).

**Inclusion regex.** `\bmoir|twisted bilayer|twisted trilayer|twisted multilayer|magic[\- ]angle | tBLG|MATBG|tMoTe|tWSe | rhombohedral graphene|rhombohedral multilayer|rhombohedral trilayer | helical trilayer graphene|helical multilayer graphene | fractional quantum anomalous Hall|FQAH|fractional Chern|composite fermion|composite Fermi liquid|composite boson | AHC crystal|anomalous Hall crystal|metallic Wigner crystal|electron crystal phase|Hall crystal | flat band material|flat[ \-]band physics | flat bands.{0,15}graphene|flat bands.{0,15}TMD | Lieb lattice|Sierpinski`

**Exclusion.** None — kagome flat bands are caught by the `correlated_electrons` `\bkagome` pattern instead, by design.

**Rationale.** breadth_02 §1.3 and breadth_03 §1.4 both flag this as the second‑largest dominant theme (~540 papers combined when counting kagome+moiré). I keep the moiré thread separate from the kagome thread because (a) kagome materials are a distinct correlated‑electron sub‑community with separate experimental tools (CsV₃Sb₅, CeRu₃Si₂, Ni₃In₂S₂, …), and (b) breadth report §1.4 (moiré) and §1.5 (kagome) are explicitly disjoint sections.

**Depth coverage.** 0 (no depth program selected this thread; breadth_02 §6.7 explicitly flagged "exceeded competition — many theory groups racing here" as the reason).

---

## 4. `unconventional_SC` — 678 papers (6.1 %)

**Definition.** Bilayer and trilayer Ruddlesden‑Popper nickelates (La₃Ni₂O₇, La₄Ni₃O₁₀, infinite‑layer NdNiO₂, Nd/Pr/Sm‑substituted RP), cuprates (LSCO, YBCO, Bi‑2212, HgBaCa…), hydride superconductors (H₃S, MH₄, LaH₁₀, YH₉, BaSiH₈, YSbH₆, LaSc₂H₂₄, Mg‑Ti‑H ternaries, hydrogen‑rich SC), topological superconductivity & Majorana modes, finite‑momentum SC / FFLO, Josephson diodes, pair‑density‑wave (PDW), kagome SC (CsV₃Sb₅, CeRu₃Si₂, CsCr₃Sb₅, CsCr₆Sb₆), superfluid stiffness, electron‑phonon‑coupling Eliashberg / Allen‑Dynes Tc machinery, UTe₂ spin‑triplet, "high‑Tc" papers.

**Inclusion regex.** `nickelate|La3Ni2O7|La_3Ni_2O_7|La4Ni3O10|La_4Ni_3O_{10}|La_7Ni_5 | infinite[\- ]layer.nickelate|NdNiO|PrNiO|SmNiO|RNiO|R_3Ni_2O_7 | cuprate|YBaCuO|YBa_2Cu|Bi.{1,4}Sr.{1,4}Ca.{1,4}Cu|LSCO|HgBaCa|HgBa_2Ca|YBCO|Bi-2212|Bi-2201|Bi-2223 | hydride.superconduct|hydrogen.rich.{1,15}superconduct|H3S|H_3S|MH4|LaH10|YH9|BaSiH8|YSbH6|LaSc2H24|LaScH|hydrogen.based superconduct|Mg.Ti.H.ternary|hydrogen ternary | topological superconduct|Majorana fermion|Majorana mode|MZM|Majorana bound state | finite[\- ]momentum.{0,20}superconduct|FFLO|Fulde[\- ]Ferrell|Larkin[\- ]Ovchinnikov | Josephson diode|superconducting diode|nonreciprocal superconductivity | unconventional superconduct|d.wave superconduct|s\\pm.superconduct|chiral superconduct | pair density wave|PDW | CsV3Sb5|CsV_3Sb_5|RV3Sb5|kagome superconductor|CeRu3Si2|CsCr3Sb5|CsCr_3Sb_5|CsCr6Sb6 | superfluid stiffness|Eliashberg|Allen.Dynes|electron[\- ]phonon coupling.{0,30}superconduct | UTe2|UTe_2|spin[\- ]triplet.{0,20}superconduct | high-Tc superconduct|high.temperature superconduct | s\+id|s\+d|gap structure.{0,15}superconduct | superconductor[ \-]ferromagnet|superconductor[ \-]semiconductor | room.temperature superconductor`

**Exclusion.** None. (Note that the depth_01 program lands in `altermagnetism` because the candidate material Na₂V₂Se₂O is altermagnetic; the corresponding "altermagnet SC" papers like 2604.00838 land in `altermagnetism` but list `unconventional_SC` as secondary.)

**Rationale.** breadth_01 §1.3, breadth_02 §1.2, breadth_03 §1.3+§1.7 each treat unconventional SC as a top‑3 dominant theme. I unified nickelate / cuprate / hydride / topological‑SC into a single `unconventional_SC` rather than splitting them because (a) the union still fits inside one figure column at 6.1 %, (b) the secondary‑category column shows the natural sub‑structure (249 secondary→ correlated_electrons, 176 → topology), and (c) the 5 depth programs do not target any one SC sub‑family directly — depth_01's NaV₂Se₂O candidate is *altermagnetic*‑SC, which sits in `altermagnetism`.

**Depth coverage.** 1/45 (d1's two‑channel Allen‑Dynes paper 2604.04719 lands here because the title doesn't mention altermagnets). The other depth_01 papers all land in `altermagnetism`.

---

## 5. `correlated_electrons` — 1,307 papers (11.8 %)

**Definition.** Strongly correlated electron physics excluding superconductivity: Hubbard model (one‑band, multi‑band, Bose, Fermi, extended), t‑J model, quantum spin liquids, Kitaev models and Kitaev materials (α‑RuCl₃, NiIrO₃, RuBr₃), heavy‑fermion materials (UTe₂, CeCoIn₅, CeRu₃Si₂, YbRh₂Si₂, CeRh₂As₂), kagome materials (frustrated, magnetic, metallic), Mott insulators / Mott transitions, Anderson lattice / impurity, f‑electron systems, strange metals / Planckian transport / non‑Fermi liquids, SYK models, charge density waves (CDW), AKLT / Haldane / valence‑bond physics, hyperbolic Dirac liquids, Hund's metals (Kanamori), spin supersolids, polarons, perovskite iridates (SrIrO₃, Sr₂IrO₄), triangular‑lattice antiferromagnets.

**Inclusion regex.** `Hubbard model|Hubbard lattice|t.J model|extended Hubbard|Bose.Hubbard|Fermi.Hubbard | quantum spin liquid|spin liquid|Kitaev model|Kitaev material|Kitaev coupl|Kitaev chain | alpha.RuCl3|RuCl_3|α-RuCl | heavy fermion|Kondo lattice|Kondo insulator|Kondo screening|Kondo coupling|hidden order | UTe|CeCoIn5|CeRu|YbRh2Si2|CeRh2As2 | kagome|frustrat|geometric frustration | strongly correlated|Mott insulator|Mott transition|orbital.selective.Mott | Anderson lattice|Anderson impurity | f[\- ]electron|4f electron|5f electron | strange metal|Planckian|non[\- ]Fermi liquid | SYK|Sachdev.Ye.Kitaev | charge density wave|CDW | AKLT|Haldane phase|valence bond | hyperbolic.{0,5}Dirac|hyperbolic lattice | Hund.{0,4}metal|Hund.{0,4}coupling|Kanamori model | spin supersolid|metallic spin | correlated metal|correlated insulator | polaron|bipolaron | iridate|SrIrO|Sr_2IrO|IrO_2 oxide|perovskite iridate | triangular.lattice antiferromagnet | Pomeranchuk`

**Exclusion.** None (kagome SC, heavy‑fermion SC, etc. land in `unconventional_SC` because that comes earlier in precedence).

**Rationale.** breadth_01 §1.7 and breadth_03 §1.5 + §2.5 jointly map kagome (~185), heavy fermion (~100+), Hubbard (456), CDW (201), spin liquid (~270 with Kitaev), strange metal, SYK as one organic correlated‑electron landscape. At 11.8 % this is the second‑largest category, but the alternatives (splitting into kagome / heavy‑fermion / Hubbard / Kitaev) would have produced 4 categories of 200–400 each, eating my 12‑category budget without adding interpretive leverage to the depth axis.

**Depth coverage.** 1/45 (d2's 2602.04245 piezomagnetism in non‑coplanar AFM lands here because it's about CoNb₃S₆/CoTa₃S₆, not altermagnets; depth_04's broader d4 programmatic context — non‑coplanar AFMs — also overlaps here).

---

## 6. `topology_quantum_geometry` — 1,375 papers (12.4 %)

**Definition.** Topological materials and quantum geometry: Chern insulators / Chern numbers, Berry curvature / quantum metric / Berry dipole, Weyl & Dirac semimetals (and their nodal lines / nodal points / Fermi arcs / chiral anomaly), axion insulators, non‑Hermitian topology / skin effect / exceptional points / PT symmetry, higher‑order topology (HOTI, corner / hinge states), nonlinear Hall effect / Berry curvature dipole / second‑harmonic generation / nonlinear photogalvanic / circular photogalvanic, anomalous Hall / spin Hall / valley Hall / orbital Hall / orbital current, symmetry indicators, topological invariants, magnetic / electric / toroidal multipole order parameters, hidden Berry curvature, fragile topology, crystalline topological materials, quantum Hall effect, photogalvanic effect.

**Inclusion regex.** `\btopolog|Chern.{0,5}insulator|Chern.{0,5}number | Berry curvature|quantum geometr|quantum metric|Berry phase|Berry connection|Berry dipole | Weyl semimetal|Dirac semimetal|nodal.line|Weyl point|Dirac point|nodal point|Fermi arc|chiral anomaly | axion insulator|axion electrodynamics | non[\- ]Hermitian|skin effect|exceptional point|PT.symmetric | higher[\- ]order topolog|HOTI|corner state|hinge state | nonlinear Hall|second.order Hall|nonlinear transport|second.harmonic generation|second-harmonic generation|SHG|nonlinear photogalvanic | anomalous Hall|spin Hall | valley Hall|valleytronics | orbital Hall|orbital current|orbital magnet | Berry curvature dipole|dissipation.shaped quantum geometry | edge state|symmetry indicator|topological invariant|topological band | Z_2 invariant|Z2 invariant|topological charge | magnetic multipole|electric multipole|toroidal multipole|electric toroidal|thermodynamic multipole|spin multipole | multipole order|multipole moment | hidden Berry|fragile topology|crystalline topological | quantum Hall|Hall effect|Hall conductivity | circular photocurrent|circular photogalvanic|CPGE | photogalvanic effect|photocurrent.{0,15}symmetry`

**Exclusion.** None (altermagnet topology, moiré topology, kagome topology all land in their respective specific categories first).

**Rationale.** breadth_01 §1.6 estimated this at "~1000+" combined; the precedence rule keeps the AM/moiré/kagome subsets out, leaving the broad anomalous‑Hall / Berry‑curvature / quantum‑geometry / Weyl / Dirac / Chern landscape. This is the **single largest category at 12.4 %**, which is intentional: it captures depth_04's main thread (nonlinear Hall in non‑coplanar AFMs, embodied in the in‑corpus paper 2511.16422 "Dissipation‑Shaped Quantum Geometry in Nonlinear Transport") and supplies cross‑pollination to several other depth programs (depth_02 piezomagnetic tensor topology, depth_05 multipole order parameters).

**Depth coverage.** 5/45 (d4: 2/3 in‑corpus including 2511.16422 and the secondary‑cited 2604.03183 thermal Hall as well as the multipole paper 2603.27505 which lands as `altermagnetism` but appears in d4; d3: 2 of 7 — the NiI₂ multiferroic and CrI₃ topological‑magnon papers; d5: the Weyl‑transition orbital‑Hall paper 2603.08851 and the spin‑magnetic‑multipole paper 2604.03578).

---

## 7. `2D_magnets_spintronics` — 402 papers (3.6 %)

**Definition.** 2D / van der Waals magnets (CrI₃, CrSBr, NiPS₃, NiI₂, MnPS₃, FePS₃, CrPS₄, MnBi₂Te₄, CrTe₂, Fe₃GeTe₂, Fe₅GeTe₂, CrGeTe₃, CoTiO₃, Cr₂Ge₂Te₆, Fe₂Mo₃O₈), monolayer ferro‑/antiferro‑magnets, magnonics and spin‑wave physics, magnetic skyrmions / merons / antimerons / hopfions / bimerons / magnetic vortices / bubbles, spin‑orbit / spin‑Hall / spin‑transfer torque, charge‑to‑spin conversion, DMI / Dzyaloshinskii‑Moriya, ferromagnetic / antiferromagnetic resonance, spin pumping, chirality‑induced spin selectivity (CISS), generic spintronics, orbitronics / orbital pumping / orbital injection, layer‑breathing modes.

**Inclusion regex.** Material list (CrI₃, CrSBr, NiPS₃, NiI₂, MnPS₃, FePS₃, CrPS₄, MnBi₂Te₄, CrTe₂, Fe₃GeTe₂, Fe₅GeTe₂, CrGeTe₃, CoTiO₃, FeI₂, Cr₂Ge₂Te, Fe.Mo.O.) + `2D magnet|monolayer magnet|monolayer.{0,8}ferromagnet|monolayer.{0,8}antiferromagnet | van der Waals magnet|vdW.{0,8}magnet | magnon|magnonics|spin wave|magnon[ \-]phonon|magnon transport|magnon Hall | skyrmion|meron|antimeron|hopfion|bimeron|magnetic vortex|magnetic bubble | spin[\- ]orbit torque|spin Hall torque|spin[\- ]transfer torque|charge.{0,8}spin conversion | DMI|Dzyaloshinskii.Moriya | ferromagnetic resonance|antiferromagnetic resonance|spin pump | chirality[\- ]induced spin selectivity|CISS | spintronic|spin diode|spin valve | orbitronics|orbital pump|orbital injection | spin transfer.{0,10}electron|spin.correlat | layer.breathing.{0,10}vibration|layer breathing`

**Rationale.** A natural "everything 2D‑magnet / spintronics that isn't altermagnet" bucket. Bridges to `altermagnetism` (the AM material families overlap with vdW magnets), to `chiral_phonon` (magnon‑phonon coupling), and to `topology_quantum_geometry` (orbital Hall, magnonic topology). 32 breadth IDs land here.

**Depth coverage.** 0 (depth_03's NiI₂ paper 2604.06959 lands in `topology_quantum_geometry` because of "topological spin textures"; the CrI₃ paper 2604.11323 lands in `topology_quantum_geometry` because of "topological magnon").

---

## 8. `ferroelectric_multiferroic` — 293 papers (2.6 %)

**Definition.** Ferroelectricity (sliding, conventional, polar metal, antiferroelectric), piezoelectric, pyroelectric, multiferroic and magnetoelectric coupling, perovskite ferroelectrics (BaTiO₃, SrTiO₃, PbTiO₃, BiFeO₃, AgNbO₃, RMnO₃ hexagonal manganites), polar order / mode / phonon / topology / texture / skyrmion / vortex, shift current / bulk photovoltaic effect (BPVE), flexoelectric, electrostriction, electrocaloric, magnetocaloric, ferroaxial / ferrotoroidic order, spontaneous / electric polarization.

**Inclusion regex.** `ferroelectric|polar metal|piezoelectric|pyroelectric | sliding ferroelectric|ferroelectric switching|antiferroelectric | multiferroic|magnetoelectric|magnetoelectric coupling | BaTiO3|SrTiO3|PbTiO3|BiFeO3|Ba\dTi\dO\d|Sr\dTi\dO\d | polar order|polar mode|polar phonon|polar topology|polar texture|polar skyrmion|polar vortex | shift current|bulk photovoltaic effect|BPVE | flexoelectric|electrostriction|electrocaloric|magnetocaloric | ferroaxial|ferrotoroidic|ferroaxial order | hexagonal manganite|RMnO3|R_3MnO_3 | spontaneous polarization|electric polarization | AgNbO3|AgNbO_3`

**Rationale.** breadth_01 §1.9 and breadth_03 §1.10 both call out ferroelectric / multiferroic as a substantive cluster (~328 ferroelectric + ~144 multiferroic mentions). Sliding ferroelectricity, alterelectricity, and FE‑switched altermagnetism are the active 2026 thread. Excluded from `altermagnetism` to avoid bloating the AM bucket; excluded from `topology_quantum_geometry` despite the "polar topology" overlap.

**Depth coverage.** 0 directly, but depth_05 (sliding‑FE altermagnet 2603.00622 / 2603.10907) cites material that's `altermagnetism` primary, `ferroelectric_multiferroic` secondary.

---

## 9. `ultrafast_Floquet_cavity` — 437 papers (3.9 %)

**Definition.** Floquet engineering, non‑equilibrium superconductivity, pump‑probe / ultrafast / HHG / tr‑ARPES / attosecond / THz spectroscopy, light‑induced or laser‑driven phenomena, cavity QED / cavity magnonic / polariton / exciton‑polariton / magnon‑polariton / phonon‑polariton / plasmon‑polariton, microcavity / cavity engineering / cavity quantum material, fluctuation engineering / QEDFT, nonlinear phononics‑adjacent (when not in `chiral_phonon`), open quantum systems / Lindbladian / dissipative dynamics, Higgs mode amplitude spectroscopy, Kapitza‑Dirac interference, excitonic insulator / exciton condensation / Ta₂NiSe₅, coherent phonons (acoustic / optical), trion ARPES.

**Inclusion regex.** `Floquet | non[\- ]equilibrium superconduct|out of equilibrium|nonequilibrium dynamics | pump[\- ]probe|ultrafast|HHG|high harmonic generation|tr.ARPES|tr ARPES|time[\- ]resolved ARPES | attosecond|terahertz spectro|THz spectro|THz pump|THz drive|THz field | light[\- ]induced superconduct|light[\- ]driven|laser[\- ]driven | cavity[\- ]QED|cavity magnonic|polariton|exciton[\- ]polariton|magnon[\- ]polariton | microcavity|cavity[\- ]coupled|cavity[\- ]modified|cavity engineering|cavity quantum material | fluctuation engineering|photon[\- ]matter|QEDFT|QED.DFT | phonon polariton|plasmon polariton | nonlinear phononic | open quantum system|Lindblad|dissipative dynamics|dissipative quantum | Higgs mode|Higgs amplitude|Kapitza.Dirac | excitonic insulator|exciton condensation|excitonic instability | Ta2NiSe5|Ta_2NiSe_5 | coherent phonon|coherent acoustic phonon | ARPES.{0,15}exciton|ARPES.{0,15}trion|excitonic correlation | trion|trion ARPES`

**Rationale.** breadth_01 §1.8 and breadth_03 §2.3 + §1.12 cover ultrafast/Floquet (~800 combined) and cavity‑QED‑materials (35) as one expanding "light‑driven matter" thread. Open quantum systems (223) shares its methodology vocabulary (Lindblad, dissipative). Excitonic insulators (Ta₂NiSe₅) belong here because the leading 2026 work is ultrafast‑probed.

**Depth coverage.** 0 (no depth program directly chose this thread).

---

## 10. `MLIP_methods` — 988 papers (8.9 %)

**Definition.** Machine‑learning interatomic potentials (MLIP / MLFF) and foundation / universal models (MACE, NequIP, Allegro, MatterSim, CHGNet, EquiformerV3/V2, SevenNet/7net, PFP, PaiNN, Orb, NEP/Neuroevolution Potential, ORION, DeePAW), graph neural network potentials, equivariant networks, message passing potentials, neural quantum states (NQS, VMC, deep VMC, backflow), beyond‑PBE DFT (hybrid functional, meta‑GGA, r²SCAN, SCAN), GW / GW+BSE, coupled‑cluster (CCSD(T)), MP2, DMRG / tensor networks / matrix product states, DMFT / DMET / quantum embedding, QED‑DFT / nuclear‑electronic orbital, path‑integral MD / PIMD, transcorrelated wavefunctions, large‑language‑model agents / autonomous labs / AI agents (MatClaw, HTC‑Claw, Materealize, TritonDFT, FermiLink, PolyJarvis, AutoMOOSE, MatterGen, PackFlow, OpenClaw), generative models for materials (diffusion / flow‑matching / generative inversion), GPU‑accelerated DFT, all‑electron RPA, Krylov subspace methods, MLIP bias / benchmarking / fine‑tuning, descriptor‑based screening (SHAP, XGBoost), Kohn‑Sham inversion, ensemble DFT, organic force fields, multipole‑screening DFT, plasmon‑enhanced Raman as an analytical method.

**Inclusion regex.** ~80 patterns; full list in `categorize.py`. Anchored on (a) named MLIP packages (MACE, NequIP, etc.), (b) explicit ML/AI vocabulary ("machine‑learning interatomic potential", "graph neural network potential", "foundation model", "diffusion model", "active learning"), (c) named LLM/agent stacks (MatClaw, HTC‑Claw, …), (d) named methodology packages (DMFT, DMET, QEDFT, transcorrelated, GW+BSE, CCSD(T), DMRG, PIMD), (e) explicit method headers ("hybrid functional", "meta‑GGA", "r²SCAN", "Krylov subspace", "Kohn‑Sham inversion", "descriptor model").

**Exclusion.** Generic "DFT calculation" / "first‑principles" / "machine learning" without method‑development context is **not** sufficient — those words alone match too broadly. The pattern requires either a named package, a named method, or an explicit "ML model / Hamiltonian / surrogate / benchmark" framing.

**Rationale.** breadth_01 §1.4 (MLIP+FM 255+106+50), breadth_02 §1.4 (MLIP 240), and breadth_03 §1.2 + §2.2 (uMLIP usability crisis) all foreground methodology as a top‑3 theme distinct from any specific physics. Captured 109 of 871 breadth IDs.

**Depth coverage.** 0 (no depth program is a method‑development program in the modern sense; depth_05 explicitly *uses* QE‑GIPAW and `multipyles` but its central observable is altermagnet NMR).

---

## 11. `energy_devices` — 1,090 papers (9.8 %)

**Definition.** Batteries (lithium‑ion, sodium‑ion, magnesium‑ion, argyrodite, solid‑state, all‑solid‑state, SEI), thermoelectrics (Seebeck, ZT, figure of merit), electrocatalysis / photocatalysis (OER, HER, ORR, CO₂RR, N₂RR, hydrogen / oxygen evolution, water splitting), hydrogen storage / hydrogen embrittlement, halide perovskites (MAPbI, FAPbI, CsPbBr/I, hybrid), photovoltaics / solar cells, high‑entropy alloys / oxides / materials (HEA), single‑atom catalysts, MOFs / COFs, superionic / fast‑ion conductors / ionic conductivity.

**Inclusion regex.** `battery|electrolyte|cathode material|anode material|lithium.ion|sodium.ion|magnesium.ion | argyrodite|solid.state battery|solid electrolyte|all.solid.state|SEI | thermoelectric|Seebeck coefficient|figure of merit|ZT | electrocataly|photocataly|catalyst|catalysis | OER|HER|ORR|CO2 reduction|N2 reduction|nitrogen reduction|hydrogen evolution|oxygen evolution|water splitting | hydrogen storage|hydrogen embrittl | halide perovskite|metal halide perovskite|MAPbI|FAPbI|CsPbBr|CsPbI|hybrid perovskite | photovoltaic|solar cell | high.entropy alloy|high.entropy oxide|high entropy material|HEA | single.atom catalyst|MOF|metal organic framework|covalent organic framework | superionic|fast ion conductor|ionic conductivity`

**Rationale.** breadth_01 §1.10 covers thermoelectrics + batteries + catalysis + hydrogen storage + halide PVs + HEAs as a coherent "energy / device" landscape (~700 combined). breadth_02 §1.4 noted MLIP as the dominant *method* underneath these device papers; the precedence rule keeps method‑driven device papers in `MLIP_methods` and physics‑driven device papers here. Captured 41 of 871 breadth IDs (relatively low because the agents had sparser coverage of energy materials than of cond‑mat physics, by design).

**Depth coverage.** 0 (no depth program targets energy materials).

---

## 12. `defects_color_centers` — 221 papers (2.0 %)

**Definition.** Color centers / spin defects / single‑photon emitters (NV center, silicon vacancy, hBN single photon emitters, DX / G / F / T centers, VOV, ST1 color center), point defects / vacancies / interstitials / dopants and their formation / migration / engineering, defect chemistry, oxygen vacancy and Raman‑defect signatures, defect qubits, superconducting qubit materials (transmon, fluxonium, Josephson junction qubit, tantalum‑encapsulated resonators, JJ qubit), spin sensing / magnetometry / nanoscale sensing, ultrawide‑bandgap nitride defects, deep level defects, dopant screening, borane chemistry.

**Inclusion regex.** `NV center|NV.{0,3}centre|nitrogen.vacancy|color center|color centre | silicon vacancy|VSi|hBN single photon|hBN.{0,8}emit|hBN/|hBN heterostruct | point defect|defect formation|defect[ \-]induced|defect engineering|defect chemistry | vacancy.{0,8}formation|vacancy.{0,8}migrat|interstitial defect | single photon emit|spin defect|defect qubit|NV.{0,3}qubit|SPE | DX center|G center|F center|T center|VOV|ST1 color center | superconducting qubit|transmon|fluxonium|JJ.qubit|Josephson junction qubit | superconducting resonator|tantalum.{0,8}encapsul|cavity material|qubit.material | dopant.{0,8}screening|doping[\- ]induced|substitutional defect | oxygen vacancy|Raman.{0,8}defect|O.{0,3}vacancy | semiconducting defect|spin sensing|magnetometry|nanoscale sensing | ultrawide.bandgap|ultra.wide.bandgap|deep level | borane|B18H22`

**Rationale.** breadth_01 §1.9 covers ~364 defect papers + 86 NV / color center + 68 spin defect papers as a coherent quantum‑materials‑defects landscape. The category absorbs the "qubit material" thread (Ta‑Nb resonators, Ta₂O₅) that breadth reports flagged as growing. Sets a clear floor of ~2 % corresponding to the well‑defined NV / color center community.

**Depth coverage.** 0 (no depth program selected defects/qubit materials, though depth_05's NMR thread shares some methodology with defect spin physics).

---

## Other (uncategorised) — 3,511 papers (31.7 %)

**Composition.** Predominantly non‑theme cond‑mat.mtrl‑sci (886), cond‑mat.mes‑hall (408), physics.chem‑ph (329), quant‑ph (240), physics.comp‑ph (216), cond‑mat.str‑el (192), cond‑mat.supr‑con (158), cond‑mat.soft (126), physics.optics (119), physics.flu‑dyn (94), cond‑mat.stat‑mech (79), cs.LG (63), hep‑th (59), math.NA (57), physics.plasm‑ph (38). The bulk is **specific applied‑materials / chemistry / soft / fluid / statistical / lattice‑gauge / cosmology / mathematical‑physics work** that the three breadth agents legitimately did not cover, plus a long tail of (~40) genuinely interesting but unique physics that doesn't fit any of the 12 themes.

**Coverage of breadth IDs.** 8 of 871 (0.9 %) breadth‑cited IDs land here — see `audit_report.md §B` for the list and explanation.

**Coverage of depth IDs.** 0 of 45 (0.0 %).

---

## Quick reference — depth → category map

| Depth program | Topic | Primary category | Secondary touches |
|---|---|---|---|
| depth_01 | NaV₂Se₂O Tc, phonon‑mediated SC | `altermagnetism` (9), `unconventional_SC` (1) | unconventional_SC, topology_quantum_geometry |
| depth_02 | Piezomagnetism tensor in altermagnets | `altermagnetism` (13), `correlated_electrons` (1) | 2D_magnets, ferroelectric, topology |
| depth_03 | Chiral phonons in 2D vdW magnets | `chiral_phonon` (4), `topology_quantum_geometry` (2), `altermagnetism` (1) | 2D_magnets, ferroelectric |
| depth_04 | SOC‑resilience nonlinear Hall in non‑coplanar AFM | `topology_quantum_geometry` (1), `altermagnetism` (2) | correlated_electrons |
| depth_05 | NMR/NQR fingerprint of altermagnetism | `altermagnetism` (22), `topology_quantum_geometry` (2) | ferroelectric, 2D_magnets, defects_color_centers |
