"""Categorization rules for the run_002 corpus (11,083 papers).

Each category has:
  - name: short slug
  - pattern: case-insensitive regex; matched against title + " " + abstract
  - exclude_pattern: optional secondary regex; if matched, paper is NOT in this cat

Precedence: a paper's primary category is the FIRST in the list whose pattern
matches and whose exclude_pattern does NOT match. Secondary categories are
the next 0-3 matching patterns (for cross-cutting work).
"""
from __future__ import annotations
import re
from collections import defaultdict, Counter

CATEGORIES = [
    # 1. Altermagnetism (consolidates all the new "altermagnet" research thread)
    # depth_01, depth_02, depth_05 land here
    ("altermagnetism",
     r"altermagnet|alterelectric|alterferr|alter[\- ]magn|"
     r"\bRuO2\b|RuO_2|RuO\$_2\$|"
     r"d-wave magnet|g-wave magnet|i-wave magnet|p-wave magnet|f-wave magnet|h-wave magnet|j-wave magnet|"
     r"\bKV2Se2O\b|KV_2Se_2O|Na2V2Se2O|Na_2V_2Se_2O|RbCr2Se2O|CsV2Se2O|CsV_2Se_2O|CsCr2S2O|CsCr_2S_2O|"
     r"hidden magnet|nonrelativistic spin splitting|non-relativistic spin splitting|"
     r"spin-space group|spin space group|NRSS|"
     r"WFeB.altermagnet|Fe2PO5.altermagnet|Fe_2PO_5.altermagnet|"
     r"V_2Se_2O.altermagnet|V2Se2O.altermagnet"),

    # 2. Chiral phonons, phonon angular momentum, phonon Hall, magnon-phonon coupling (depth_03)
    ("chiral_phonon",
     r"chiral phonon|phonon angular momentum|phonon chirality|phonon magnetic moment|"
     r"phonon Hall effect|phonon thermal Hall|\bphonon Hall\b|phonon Hall conductivity|"
     r"phonon[ \-]induced[ \-]magnet|"
     r"thermal Hall.{0,40}phonon|phonon[ \-]rotat|phonon[ \-]circular|"
     r"phonon[ \-]Berry|phonon[ \-]topology|topological phonon|topological phonons|"
     r"PAMHE|phonon Lz|phonon L\^z|phonon[ \-]Weyl|phonon[ \-]Dirac|"
     # Magnon-phonon coupling and spin-phonon as extension of chiral-phonon physics
     r"magnon[ \-]phonon|phonon[ \-]magnon|spin[ \-]phonon coupling|spin[ \-]phonon hybridi|"
     r"spin[\- ]lattice coupling|"
     # Nonlinear phononics is the "phonon engineering" complementary thread
     r"nonlinear phononic|"
     # Magnetoacoustic/magnetoelastic for phonon-driven magnetism (specific phrases only)
     r"magnetoacoustic resonance|magnetoacoustic wave|magnetoelastic mode|magneto[\- ]elastic mode"),

    # 3. Moiré & flat-band physics
    ("moire_flatband",
     r"\bmoir|twisted bilayer|twisted trilayer|twisted multilayer|magic[\- ]angle|"
     r"\btBLG\b|\bMATBG\b|\btMoTe|\btWSe|"
     r"rhombohedral graphene|rhombohedral multilayer|rhombohedral trilayer|"
     r"helical trilayer graphene|helical multilayer graphene|"
     r"fractional quantum anomalous Hall|FQAH|fractional Chern|composite fermion|composite Fermi liquid|composite boson|"
     r"\bAHC crystal|anomalous Hall crystal|metallic Wigner crystal|electron crystal phase|Hall crystal|"
     r"flat band material|flat[ \-]band physics|"
     r"flat bands.{0,15}graphene|flat bands.{0,15}TMD|"
     r"Lieb lattice|Sierpinski"),

    # 4. Unconventional superconductors
    # depth_01 (NaV2Se2O Tc) lands HERE via the AM precedence (caught earlier).
    # But cuprate/nickelate/hydride/topological-SC are in this category.
    ("unconventional_SC",
     r"nickelate|La3Ni2O7|La_3Ni_2O_7|La4Ni3O10|La_4Ni_3O_\{10\}|La_7Ni_5|"
     r"infinite[\- ]layer.nickelate|NdNiO|PrNiO|SmNiO|RNiO|R_3Ni_2O_7|"
     r"\bcuprate|YBaCuO|YBa_2Cu|Bi.{1,4}Sr.{1,4}Ca.{1,4}Cu|LSCO|HgBaCa|HgBa_2Ca|YBCO|Bi-2212|Bi-2201|Bi-2223|"
     r"hydride.superconduct|hydrogen.rich.{1,15}superconduct|"
     r"\bH3S\b|H_3S\b|MH4|LaH10|YH9|BaSiH8|YSbH6|LaSc2H24|LaScH|hydrogen.based superconduct|"
     r"Mg.Ti.H.ternary|hydrogen ternary|"
     r"topological superconduct|Majorana fermion|Majorana mode|MZM|Majorana bound state|"
     r"finite[\- ]momentum.{0,20}superconduct|FFLO|Fulde[\- ]Ferrell|Larkin[\- ]Ovchinnikov|"
     r"Josephson diode|superconducting diode|nonreciprocal superconductivity|"
     r"unconventional superconduct|d.wave superconduct|s\\pm.superconduct|chiral superconduct|"
     r"pair density wave|\bPDW\b|"
     r"\bCsV3Sb5\b|CsV_3Sb_5|RV3Sb5|kagome superconductor|CeRu3Si2|CsCr3Sb5|CsCr_3Sb_5|CsCr6Sb6|"
     r"superfluid stiffness|\bEliashberg\b|Allen.Dynes|electron[\- ]phonon coupling.{0,30}superconduct|"
     r"\bUTe2\b|UTe_2|spin[\- ]triplet.{0,20}superconduct|"
     r"high-Tc superconduct|high.temperature superconduct|"
     r"\bs\+id\b|\bs\+d\b|gap structure.{0,15}superconduct|"
     r"superconductor[ \-]ferromagnet|superconductor[ \-]semiconductor|"
     r"room.temperature superconductor"),

    # 5. Strongly correlated electrons (kagome, heavy fermion, Hubbard, spin liquids, Kitaev, CDW)
    ("correlated_electrons",
     r"Hubbard model|Hubbard lattice|t.J model|extended Hubbard|Bose.Hubbard|Fermi.Hubbard|"
     r"quantum spin liquid|spin liquid|Kitaev model|Kitaev material|Kitaev coupl|Kitaev chain|"
     r"\balpha.RuCl3|RuCl_3|\bα-RuCl|"
     r"heavy fermion|Kondo lattice|Kondo insulator|Kondo screening|Kondo coupling|hidden order|"
     r"\bUTe|CeCoIn5|CeRu|YbRh2Si2|CeRh2As2|"
     r"\bkagome|frustrat|geometric frustration|"
     r"strongly correlated|Mott insulator|Mott transition|orbital.selective.Mott|"
     r"Anderson lattice|Anderson impurity|"
     r"f[\- ]electron|4f electron|5f electron|"
     r"strange metal|Planckian|non[\- ]Fermi liquid|"
     r"\bSYK\b|Sachdev.Ye.Kitaev|"
     r"charge density wave|\bCDW\b|"
     r"AKLT|Haldane phase|valence bond|"
     r"hyperbolic.{0,5}Dirac|hyperbolic lattice|"
     r"Hund.{0,4}metal|Hund.{0,4}coupling|Kanamori model|"
     r"spin supersolid|metallic spin|"
     r"correlated metal|correlated insulator|"
     r"polaron|bipolaron|"
     r"iridate|SrIrO|Sr_2IrO|IrO_2 oxide|perovskite iridate|"
     r"triangular.lattice antiferromagnet|"
     r"Pomeranchuk"),

    # 6. Topology, quantum geometry & nonlinear transport (depth_04 lands here)
    ("topology_quantum_geometry",
     r"\btopolog|Chern.{0,5}insulator|Chern.{0,5}number|"
     r"Berry curvature|quantum geometr|quantum metric|Berry phase|Berry connection|Berry dipole|"
     r"Weyl semimetal|Dirac semimetal|nodal.line|Weyl point|Dirac point|nodal point|Fermi arc|chiral anomaly|"
     r"axion insulator|axion electrodynamics|"
     r"non[\- ]Hermitian|skin effect|exceptional point|PT.symmetric|"
     r"higher[\- ]order topolog|HOTI|corner state|hinge state|"
     r"nonlinear Hall|second.order Hall|nonlinear transport|second.harmonic generation|second-harmonic generation|\bSHG\b|nonlinear photogalvanic|"
     r"anomalous Hall|spin Hall|"
     r"valley Hall|valleytronics|"
     r"orbital Hall|orbital current|orbital magnet|"
     r"Berry curvature dipole|dissipation.shaped quantum geometry|"
     r"\bedge state\b|symmetry indicator|topological invariant|topological band|"
     r"Z_2 invariant|Z2 invariant|topological charge|"
     r"magnetic multipole|electric multipole|toroidal multipole|electric toroidal|thermodynamic multipole|spin multipole|"
     r"multipole order|multipole moment|"
     r"hidden Berry|fragile topology|crystalline topological|"
     r"quantum Hall|Hall effect|Hall conductivity|"
     r"circular photocurrent|circular photogalvanic|CPGE|"
     r"photogalvanic effect|photocurrent.{0,15}symmetry"),

    # 7. 2D vdW magnets, magnons, spintronics (non-altermagnet)
    ("2D_magnets_spintronics",
     r"\bCrI3\b|CrI_3|\bCrSBr\b|\bNiPS3\b|NiPS_3|\bNiI2\b|NiI_2|MnPS3|MnPS_3|FePS3|FePS_3|CrPS4|CrPS_4|"
     r"MnBi2Te4|MnBi_2Te_4|CrTe2|CrTe_2|Fe3GeTe2|Fe_3GeTe_2|Fe5GeTe2|Fe_5GeTe_2|CrGeTe3|CrGeTe_3|CoTiO3|\bFeI2\b|"
     r"Cr2Ge2Te6|Cr_2Ge_2Te_6|"
     # Fe-Mo-O materials require explicit digit pattern (not letters in between)
     r"Fe[0-9]+\.?[0-9]*Mo[0-9]+\.?[0-9]*O[0-9]+|Fe[0-9]\.?[0-9]*Zn[0-9]\.?[0-9]*Mo[0-9]+O[0-9]+|"
     r"2D magnet|monolayer magnet|monolayer.{0,8}ferromagnet|monolayer.{0,8}antiferromagnet|"
     r"van der Waals magnet|van.der.Waals.{0,8}ferromagnet|2D vdW magnet|vdW.{0,8}magnet|"
     r"\bmagnon\b|magnonics|spin wave|magnon[ \-]phonon|magnon transport|magnon Hall|"
     r"skyrmion|meron|antimeron|hopfion|bimeron|magnetic vortex|magnetic bubble|"
     r"spin[\- ]orbit torque|spin Hall torque|spin[\- ]transfer torque|charge.{0,8}spin conversion|"
     r"\bDMI\b|Dzyaloshinskii.Moriya|"
     r"ferromagnetic resonance|antiferromagnetic resonance|spin pump|"
     r"chirality[\- ]induced spin selectivity|\bCISS\b|"
     r"\bspintronic|spin diode|spin valve|"
     r"orbitronics|orbital pump|orbital injection|"
     r"spin transfer.{0,10}electron|spin.correlat|"
     r"layer.breathing.{0,10}vibration|layer breathing"),

    # 8. Ferroelectrics, multiferroics, polar materials, ferroaxial
    ("ferroelectric_multiferroic",
     r"\bferroelectric|polar metal|piezoelectric|pyroelectric|"
     r"sliding ferroelectric|ferroelectric switching|antiferroelectric|"
     r"multiferroic|magnetoelectric|magnetoelectric coupling|"
     r"BaTiO3|SrTiO3|PbTiO3|BiFeO3|Ba\dTi\dO\d|Sr\dTi\dO\d|"
     r"polar order|polar mode|polar phonon|polar topology|polar texture|polar skyrmion|polar vortex|"
     r"shift current|bulk photovoltaic effect|BPVE|"
     r"flexoelectric|electrostriction|electrocaloric|magnetocaloric|"
     r"ferroaxial|ferrotoroidic|ferroaxial order|"
     r"hexagonal manganite|RMnO3|R_3MnO_3|"
     r"spontaneous polarization|electric polarization|"
     r"AgNbO3|AgNbO_3"),

    # 9. Ultrafast / Floquet / cavity-QED / nonequilibrium / excitonic insulators
    ("ultrafast_Floquet_cavity",
     r"Floquet|"
     r"non[\- ]equilibrium superconduct|out of equilibrium|nonequilibrium dynamics|"
     r"pump[\- ]probe|ultrafast|HHG|high harmonic generation|tr.ARPES|tr ARPES|time[\- ]resolved ARPES|"
     r"attosecond|terahertz spectro|THz spectro|THz pump|THz drive|THz field|"
     r"light[\- ]induced superconduct|light[\- ]driven|laser[\- ]driven|"
     r"cavity[\- ]QED|cavity magnonic|polariton|exciton[\- ]polariton|magnon[\- ]polariton|"
     r"microcavity|cavity[\- ]coupled|cavity[\- ]modified|cavity engineering|cavity quantum material|"
     r"fluctuation engineering|photon[\- ]matter|QEDFT|QED.DFT|"
     r"phonon polariton|plasmon polariton|"
     r"nonlinear phononic|"
     r"open quantum system|Lindblad|dissipative dynamics|dissipative quantum|"
     r"Higgs mode|Higgs amplitude|Kapitza.Dirac|"
     r"excitonic insulator|exciton condensation|excitonic instability|"
     r"Ta2NiSe5|Ta_2NiSe_5|"
     r"coherent phonon|coherent acoustic phonon|"
     r"ARPES.{0,15}exciton|ARPES.{0,15}trion|excitonic correlation|"
     r"\btrion\b|trion ARPES"),

    # 10. ML potentials, foundation models, ab initio methods
    ("MLIP_methods",
     r"machine[\- ]learning interatomic potential|machine[\- ]learning potential|"
     r"\bMLIP\b|\bMLFF\b|graph neural network potential|"
     r"equivariant graph|equivariant neural|message passing potential|GNN potential|"
     r"foundation model|universal potential|universal interatomic|universal MLIP|"
     r"\bMACE\b|NequIP|Allegro|MatterSim|CHGNet|EquiformerV3|EquiformerV2|SevenNet|7net|PFP|PaiNN|"
     r"Orb potential|Orb model|Neuroevolution Potential|\bNEP\b framework|"
     r"neural network quantum state|neural quantum state|VMC wavefunction|deep VMC|backflow|"
     r"hybrid functional|meta.GGA|r2SCAN|r²SCAN|SCAN functional|"
     r"GW.{0,5}BSE|GW approximation|G_0W_0|coupled[\- ]cluster|CCSD\(T\)|MP2|"
     r"\bDMRG\b|tensor network|matrix product state|\bMPS\b|"
     r"\bLLM\b|large language model|AI agent|autonomous (lab|laboratory)|self.driving lab|agentic|"
     r"high.throughput.{0,15}DFT|generative model|diffusion model|"
     r"GPU.accelerated DFT|GPU DFT|GPU acceleration|"
     r"\bbias\b.{0,15}universal|\bbias\b.{0,20}MLIP|bias.{0,10}interatomic|fine.tuning.{0,20}potential|"
     r"machine[\- ]learning Hamiltonian|machine[\- ]learning model|"
     r"graph neural network|active learning|all-electron RPA|"
     r"DeePAW|ORION.{0,15}force field|Suiren|MatClaw|HTC.Claw|Materealize|TritonDFT|FermiLink|"
     r"PolyJarvis|AutoMOOSE|MatterGen|PackFlow|OpenClaw|reactive deep learning|"
     r"flow.matching|flow matching|PRBench|"
     r"coupled cluster.{0,15}calculation|coupled cluster.{0,15}theory|coupled cluster method|"
     r"MRSF|CASPT2|CASSCF|"
     r"\bDMFT\b|dynamical mean.field|quantum embedding|DMET|"
     r"QEDFT|QED.{0,3}DFT|nuclear electronic orbital|"
     r"path integral.{0,15}molecular|PIMD|"
     r"neural[ \-]network surrogate|surrogate model|ChargeFlow|"
     r"\bNQS\b|"
     r"variational Monte Carlo|VMC method|"
     r"interpretable descriptor|descriptor.{0,5}model|\bSHAP\b|XGBoost|"
     r"sum.of.gaussian|tensor neural network|JAX.{0,3}CUDA|JAX.{0,5}plus.{0,5}CUDA|"
     r"Krylov.subspace|quantum Krylov|"
     r"generative inversion|generative.{0,5}structure|inverse design|generative.{0,5}material|"
     r"diffusion-based generative|"
     r"transcorrelated|orbital-free.{0,5}DFT|orbital free.{0,5}DFT|orbital.free ab initio|"
     r"Hund-projected|Hund.projected|"
     r"organic force field|empirical force field|interatomic force field|"
     r"AI accelerator|ML accelerated|"
     r"crystal structure prediction|"
     r"operator growth|Lanczos coefficient|"
     r"benchmark.{0,8}MLIP|benchmark.{0,8}force field|benchmark.{0,8}potential|"
     r"\bRPA\b correlation|"
     r"plasmon enhanced Raman|plasmon-enhanced Raman|nanocavity-enabled.{0,5}detection|"
     # Specific method papers we want to capture
     r"Kohn[\- ]Sham inversion|Kohn-Sham theory|"
     r"ensemble variational hierarchies|exact density.functional theory|exact DFT|"
     r"constrained Schrödinger dynamics|"
     # Multipole-screening as method (specific to the multipole-DFT methodology)
     r"multipole screening"),

    # 11. Energy materials & devices: batteries, thermoelectrics, catalysis, perovskite PVs, HEAs
    ("energy_devices",
     r"\bbattery\b|electrolyte|cathode material|anode material|lithium.ion|sodium.ion|magnesium.ion|"
     r"argyrodite|solid.state battery|solid electrolyte|all.solid.state|\bSEI\b|"
     r"thermoelectric|Seebeck coefficient|figure of merit|\bZT\b|"
     r"electrocataly|photocataly|catalyst|catalysis|"
     r"\bOER\b|\bHER\b|\bORR\b|CO2 reduction|N2 reduction|nitrogen reduction|hydrogen evolution|oxygen evolution|water splitting|"
     r"hydrogen storage|hydrogen embrittl|"
     r"halide perovskite|metal halide perovskite|MAPbI|FAPbI|CsPbBr|CsPbI|hybrid perovskite|"
     r"photovoltaic|solar cell|"
     r"high.entropy alloy|high.entropy oxide|high entropy material|HEA|"
     r"single.atom catalyst|MOF|metal organic framework|covalent organic framework|"
     r"superionic|fast ion conductor|ionic conductivity"),

    # 12. Defects, color centers, quantum sensing materials
    ("defects_color_centers",
     r"NV center|NV.{0,3}centre|nitrogen.vacancy|color center|color centre|"
     r"silicon vacancy|VSi|hBN single photon|hBN.{0,8}emit|hBN/|hBN heterostruct|"
     r"point defect|defect formation|defect[ \-]induced|defect engineering|defect chemistry|"
     r"vacancy.{0,8}formation|vacancy.{0,8}migrat|interstitial defect|"
     r"single photon emit|spin defect|defect qubit|NV.{0,3}qubit|\bSPE\b|"
     r"\bDX center|\bG center|\bF center|\bT center|\bVOV\b|\bST1 color center|"
     r"superconducting qubit|transmon|fluxonium|JJ.qubit|Josephson junction qubit|"
     r"superconducting resonator|tantalum.{0,8}encapsul|cavity material|qubit.material|"
     r"dopant.{0,8}screening|doping[\- ]induced|substitutional defect|"
     r"oxygen vacancy|Raman.{0,8}defect|O.{0,3}vacancy|"
     r"semiconducting defect|spin sensing|magnetometry|nanoscale sensing|"
     r"ultrawide.bandgap|ultra.wide.bandgap|deep level|"
     r"borane|B18H22"),
]


def normalize_text(text: str) -> str:
    r"""Strip LaTeX formatting so that 'RuO$_2$' becomes 'RuO2', 'MnBi$_2$Te$_4$' becomes 'MnBi2Te4', etc.

    Rules applied:
      - $...$ removed (delimiter only); inner content kept verbatim with formatting symbols stripped
      - subscript/superscript delimiters removed: _{...} -> ..., _N -> N, ^{...} -> ..., ^N -> N
      - LaTeX backslash commands (\bf, \mathrm, etc.) replaced with spaces
      - { and } removed
      - Keep ALL alphanumerics, spaces, hyphens, slashes; preserve case otherwise.
    """
    # Remove LaTeX commands like \mathrm, \boldsymbol, \bf, \it, \alpha, \beta, etc.
    text = re.sub(r"\\[a-zA-Z]+\s*", " ", text)
    # Remove $ delimiters
    text = text.replace("$", "")
    # Remove subscript/superscript markers but keep content
    text = text.replace("_{", "").replace("^{", "")
    text = text.replace("_", "").replace("^", "")
    # Remove braces
    text = text.replace("{", "").replace("}", "")
    return text


def _compile():
    return [(name, re.compile(pat, re.IGNORECASE)) for name, pat in CATEGORIES]


def categorize(text: str, compiled=None, normalized: str | None = None):
    """Return (primary, secondary_list) for a paper.

    Tries the patterns against the *original* text first, then against the
    LaTeX-normalized text (so 'RuO$_2$' is also caught by the 'RuO2' pattern).
    """
    if compiled is None:
        compiled = _compile()
    if normalized is None:
        normalized = normalize_text(text)
    combined = text + " " + normalized
    primary = "other"
    secondary: list[str] = []
    for name, rgx in compiled:
        if rgx.search(combined):
            if primary == "other":
                primary = name
            else:
                secondary.append(name)
    return primary, secondary[:3]


def categorize_all(papers):
    """Categorize a list of (arxiv_id, title, abstract). Return dict."""
    compiled = _compile()
    result = {}
    for aid, title, ab in papers:
        text = title + " " + ab
        normalized = normalize_text(text)
        prim, sec = categorize(text, compiled, normalized=normalized)
        result[aid] = (prim, sec)
    return result
