from __future__ import annotations

import csv
import json
from collections import defaultdict
from pathlib import Path
from textwrap import fill

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Patch, Polygon


FIG_DIR = Path(__file__).resolve().parent
NEURIPS_DIR = FIG_DIR.parent
RUN_ROOT = NEURIPS_DIR.parent

COLORS = {
    "blue": "#0072B2",
    "sky": "#56B4E9",
    "green": "#009E73",
    "orange": "#E69F00",
    "vermillion": "#D55E00",
    "purple": "#CC79A7",
    "yellow": "#F0E442",
    "text": "#30343B",
    "muted": "#68717A",
    "grid": "#D9DEE3",
    "light": "#F5F7FA",
    "white": "#FFFFFF",
}

GROUP_COLORS = {
    "Local corpus/files": COLORS["blue"],
    "Local downloaded": COLORS["sky"],
    "External APIs": COLORS["green"],
    "External web": COLORS["orange"],
}

PHASE_COLORS = {
    "Breadth": COLORS["blue"],
    "Depth": COLORS["green"],
    "Pilot": COLORS["orange"],
    "Pre-prod": COLORS["purple"],
    "Production": COLORS["vermillion"],
    "Writing": "#6F6F6F",
}

MECHANISM_COLORS = {
    "Distributed grounding": COLORS["blue"],
    "Adversarial review": COLORS["vermillion"],
    "Within-session debug": COLORS["green"],
    "Falsification": COLORS["purple"],
}

PHASES = [
    ("Breadth", 3),
    ("Depth", 5),
    ("Pilot", 24),
    ("Pre-prod", 1),
    ("Production", 4),
    ("Writing", 10),
]

PHASE_TOTALS = [
    ("breadth", 1249),
    ("depth", 140),
    ("pilot", 377),
    ("pre-prod", 41),
    ("prod", 4),
    ("writing", 351),
]

CHANNELS_14 = [
    ("sqlite keyword", 1234, "Local corpus/files"),
    ("WebFetch arXiv", 254, "External web"),
    ("WebSearch", 219, "External web"),
    ("corpus markdown", 99, "Local corpus/files"),
    ("arXiv API", 90, "External APIs"),
    ("other WebFetch", 70, "External web"),
    ("reference papers", 50, "Local downloaded"),
    ("prior_work md", 46, "Local downloaded"),
    ("WebFetch APS", 28, "External web"),
    ("WebFetch Nature", 22, "External web"),
    ("sqlite queries", 20, "Local corpus/files"),
    ("other APIs", 16, "External APIs"),
    ("local PDF/SQL atom", 8, "Local downloaded"),
    ("lit_access read", 6, "External APIs"),
]

PHASE_GROUPS = {
    "breadth": {
        "Local corpus/files": 1248,
        "Local downloaded": 0,
        "External APIs": 1,
        "External web": 0,
    },
    "depth": {
        "Local corpus/files": 45,
        "Local downloaded": 0,
        "External APIs": 65,
        "External web": 30,
    },
    "pilot": {
        "Local corpus/files": 61,
        "Local downloaded": 80,
        "External APIs": 46,
        "External web": 190,
    },
    "pre-prod": {
        "Local corpus/files": 0,
        "Local downloaded": 0,
        "External APIs": 0,
        "External web": 41,
    },
    "prod": {
        "Local corpus/files": 1,
        "Local downloaded": 0,
        "External APIs": 0,
        "External web": 3,
    },
    "writing": {
        "Local corpus/files": 0,
        "Local downloaded": 22,
        "External APIs": 0,
        "External web": 329,
    },
}

IDEA_CARDS = [
    {
        "name": "NaV2Se2O Tc",
        "session": "depth_01",
        "quote": "phonon-mediated electron-phonon coupling and Tc analysis of NaV2Se2O",
        "status": "Dropped: strong but risky",
    },
    {
        "name": "Piezomagnetism",
        "session": "depth_02",
        "quote": "strain-induced net magnetization as a mechanical probe and control of Neel order",
        "status": "SELECTED: best composite",
    },
    {
        "name": "Chiral phonons",
        "session": "depth_03",
        "quote": "magnetic-order-induced chiral phonons and phonon magnetic moments",
        "status": "Dropped: noise-floor risk",
    },
    {
        "name": "Noncoplanar NLH",
        "session": "depth_04",
        "quote": "SOC-resilience of the magnetic-geometry channel of intrinsic nonlinear Hall",
        "status": "Dropped: safe but incremental",
    },
    {
        "name": "AM NMR",
        "session": "depth_05",
        "quote": "sublattice-resolved Knight shift tensors and NMR/NQR fingerprints",
        "status": "Dropped: visionary but risky",
    },
]

THEMES = [
    "altermagnetism",
    "topological",
    "superconductivity",
    "ML potentials",
    "2D magnets",
    "ferroelectrics",
    "correlated",
    "ultrafast",
    "energy",
    "quantum metrics",
]

XMAP = {
    "S1": 0.0,
    "S2": 1.0,
    "S3-01": 2.0,
    "S3-02": 3.0,
    "S3-03": 4.0,
    "S3-04": 5.0,
    "S3-05": 6.0,
    "pg01": 7.15,
    "pg02": 8.05,
    "pg03": 8.95,
    "pg04": 9.85,
    "reflect_01": 10.45,
    "pg05": 11.15,
    "pg06": 12.05,
    "pg07": 12.95,
    "pg08": 13.85,
    "reflect_II_02": 14.45,
    "pg09": 15.15,
    "pg10": 16.05,
    "pg11": 16.95,
    "pg12": 17.85,
    "pg13": 18.75,
    "pg14": 19.65,
    "pg15": 20.55,
}

TICKS = [
    ("S1", "S1"),
    ("S2", "S2"),
    ("S3-01", "S3-01"),
    ("S3-02", "S3-02"),
    ("S3-03", "S3-03"),
    ("S3-04", "S3-04"),
    ("S3-05", "S3-05"),
    ("pg01", "pg01"),
    ("pg04", "pg04"),
    ("reflect_01", "ref01"),
    ("pg05", "pg05"),
    ("pg07", "pg07"),
    ("pg08", "pg08"),
    ("reflect_II_02", "ref-II"),
    ("pg09", "pg09"),
    ("pg11", "pg11"),
    ("pg12", "pg12"),
    ("pg13", "pg13"),
    ("pg15", "pg15"),
]

CATCHES = [
    ("m_orb HIGH->LOW", "pg04", "reflect_01", "Distributed grounding", "short", False),
    ("no plateau", "pg06", "pg07", "Adversarial review", "short", False),
    ("KV2Se2O AM", "S1", "pg09", "Distributed grounding", "long", False),
    ("CrSb antiunitary", "pg12", "pg12", "Within-session debug", "within", False),
    ("basis extension", "pg07", "pg08", "Falsification", "short", True),
    ("PAW SCF", "pg08", "pg08", "Falsification", "within", True),
    ("T1g/T2g", "S3-04", "S3-04", "Distributed grounding", "within", False),
    ("LDA+U patch", "pg04", "pg04", "Within-session debug", "within", False),
    ("3 retractions", "S3-04", "reflect_01", "Distributed grounding", "medium", False),
    ("ref-II cap", "pg08", "reflect_II_02", "Adversarial review", "short", False),
    ("CrSb sigma sign", "pg12", "pg12", "Adversarial review", "within", False),
]


def apply_style():
    mpl.rcParams.update(
        {
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
            "axes.linewidth": 0.7,
            "font.size": 8,
            "axes.labelsize": 8,
            "xtick.labelsize": 7,
            "ytick.labelsize": 7,
            "legend.fontsize": 7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "savefig.facecolor": "white",
            "figure.facecolor": "white",
        }
    )


def save_png_pdf(fig, stem: str, out_dir: Path = FIG_DIR, dpi: int = 300):
    out_dir.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf"):
        fig.savefig(out_dir / f"{stem}.{suffix}", dpi=dpi, bbox_inches="tight", pad_inches=0.035, transparent=False)


def save_png(fig, stem: str, out_dir: Path, dpi: int = 260):
    out_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_dir / f"{stem}.png", dpi=dpi, bbox_inches="tight", pad_inches=0.035, transparent=False)


def panel_title(ax, text, loc="left", pad=4):
    ax.set_title(text, loc=loc, fontsize=8.2, fontweight="semibold", color=COLORS["text"], pad=pad)


def rounded_box(ax, xy, w, h, label, fc, ec=None, lw=0.8, fontsize=7, radius=0.035, alpha=1.0, text_color=None):
    ec = ec or fc
    patch = FancyBboxPatch(
        xy,
        w,
        h,
        boxstyle=f"round,pad=0.012,rounding_size={radius}",
        facecolor=fc,
        edgecolor=ec,
        linewidth=lw,
        alpha=alpha,
    )
    ax.add_patch(patch)
    if text_color is None:
        dark_fills = {
            COLORS["blue"],
            COLORS["sky"],
            COLORS["green"],
            COLORS["orange"],
            COLORS["vermillion"],
            COLORS["purple"],
            "#6F6F6F",
        }
        text_color = "white" if fc in dark_fills else COLORS["text"]
    ax.text(
        xy[0] + w / 2,
        xy[1] + h / 2,
        label,
        ha="center",
        va="center",
        fontsize=fontsize,
        color=text_color,
        fontweight="semibold",
        linespacing=1.0,
    )
    return patch


def arrow(ax, xy1, xy2, color=None, lw=0.8, rad=0.0, ms=8, alpha=1.0):
    color = color or COLORS["muted"]
    patch = FancyArrowPatch(
        xy1,
        xy2,
        arrowstyle="-|>",
        mutation_scale=ms,
        linewidth=lw,
        color=color,
        connectionstyle=f"arc3,rad={rad}",
        alpha=alpha,
    )
    ax.add_patch(patch)
    return patch


def clean_axis(ax, axis="x"):
    ax.tick_params(length=2.5, color=COLORS["muted"], labelcolor=COLORS["text"])
    ax.grid(True, axis=axis, color=COLORS["grid"], linewidth=0.45, alpha=0.7)
    ax.set_axisbelow(True)


def draw_idea_cards(ax):
    ax.set_axis_off()
    card_h = 0.183
    gap = 0.016
    y = 0.98 - card_h
    for card in IDEA_CARDS:
        selected = card["status"].startswith("SELECTED")
        fc = "#FFF8E6" if selected else COLORS["white"]
        ec = COLORS["orange"] if selected else COLORS["grid"]
        ax.add_patch(
            FancyBboxPatch(
                (0.02, y),
                0.96,
                card_h,
                boxstyle="round,pad=0.012,rounding_size=0.02",
                facecolor=fc,
                edgecolor=ec,
                linewidth=0.9 if selected else 0.6,
            )
        )
        ax.text(0.05, y + card_h - 0.032, card["name"], fontsize=6.25, fontweight="bold", color=COLORS["text"])
        ax.text(0.95, y + card_h - 0.032, card["session"], fontsize=5.55, ha="right", color=COLORS["muted"])
        ax.text(0.05, y + card_h - 0.069, fill(card["quote"], 36), fontsize=5.05, color=COLORS["text"], va="top", linespacing=1.03)
        ax.text(
            0.05,
            y + 0.017,
            card["status"],
            fontsize=5.45,
            color=COLORS["orange"] if selected else COLORS["muted"],
            fontweight="bold" if selected else "normal",
        )
        y -= card_h + gap
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)


def draw_session_ticks(ax, include_xlabel=True):
    ax.set_xlim(-0.35, max(XMAP[k] for k, _ in TICKS) + 0.62)
    ax.set_xticks([XMAP[k] for k, _ in TICKS], [label for _, label in TICKS])
    ax.tick_params(axis="x", labelsize=5.2, pad=1.0, rotation=35)
    for label in ax.get_xticklabels():
        label.set_ha("right")
    if include_xlabel:
        ax.set_xlabel("pilot session chronology", fontsize=7.2, labelpad=3)


def load_anchor_csv(path: Path | None = None):
    path = path or FIG_DIR / "data" / "pilot_anchor_data.csv"
    rows = []
    if not path.exists():
        return rows
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            row = dict(row)
            for key in ("published_value", "pipeline_value", "ratio"):
                try:
                    row[key] = float(row[key])
                except (TypeError, ValueError):
                    row[key] = np.nan
            rows.append(row)
    return rows
