from pathlib import Path
import textwrap

import matplotlib as mpl


ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = ROOT.parent
FIG_DIR = Path(__file__).resolve().parent

COLORS = {
    "blue": "#0072B2",
    "green": "#009E73",
    "orange": "#E69F00",
    "vermillion": "#D55E00",
    "sky": "#56B4E9",
    "purple": "#CC79A7",
    "neutral": "#4D4D4D",
    "mid": "#8A8F98",
    "grid": "#D7DEE8",
    "pale": "#F7F8FA",
    "white": "#FFFFFF",
}

CATEGORY_COLORS = {
    "database": COLORS["blue"],
    "web": COLORS["orange"],
    "API": COLORS["green"],
    "local files": COLORS["sky"],
}


def apply_style():
    mpl.rcParams.update(
        {
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
            "font.size": 7.2,
            "axes.labelsize": 7.6,
            "axes.titlesize": 8.0,
            "xtick.labelsize": 6.4,
            "ytick.labelsize": 6.4,
            "legend.fontsize": 6.4,
            "axes.linewidth": 0.7,
            "axes.edgecolor": COLORS["neutral"],
            "xtick.color": COLORS["neutral"],
            "ytick.color": COLORS["neutral"],
            "text.color": COLORS["neutral"],
            "axes.labelcolor": COLORS["neutral"],
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "savefig.edgecolor": "white",
        }
    )


def save_dual(fig, stem):
    png = FIG_DIR / f"{stem}.png"
    pdf = FIG_DIR / f"{stem}.pdf"
    fig.savefig(png, dpi=300, bbox_inches="tight", pad_inches=0.02, transparent=False)
    fig.savefig(pdf, bbox_inches="tight", pad_inches=0.02, transparent=False)
    return png, pdf


def wrap_label(text, width):
    return "\n".join(textwrap.wrap(text, width=width, break_long_words=False))
