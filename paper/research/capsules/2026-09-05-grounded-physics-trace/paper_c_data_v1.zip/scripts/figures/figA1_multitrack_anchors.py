from __future__ import annotations

import math
import sys
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D


FIG_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FIG_DIR))

from _paper_c_style import COLORS, XMAP, apply_style, draw_session_ticks, save_png_pdf  # noqa: E402


APPENDIX_DIR = FIG_DIR / "appendix"

TRACKS = [
    ("Ye $M_z^{orb}$", 6),
    ("Fe $m_{orb}$", 5),
    ("V$_2$Te$_2$O $M$", 4),
    ("Mn$_3$NiN $Q$", 3),
    ("KV$_2$Se$_2$O $\\Delta E$", 2),
    ("CrSb AHC", 1),
    ("KMM spin $\\Lambda$", 0),
]

POINTS = [
    ("Ye $M_z^{orb}$", "pg04", "0.4286/0.176", 2.4297, "fail"),
    ("Ye $M_z^{orb}$", "pg05", "0.2377/0.176", 1.3475, "caveat"),
    ("Ye $M_z^{orb}$", "pg07", "0.1923/0.176", 1.0901, "pass"),
    ("Ye $M_z^{orb}$", "pg08", "0.0024/0.176", 0.0136, "falsification"),
    ("Ye $M_z^{orb}$", "pg11", "0.1924/0.176", 1.0905, "caveat"),
    ("Fe $m_{orb}$", "pg01", "0.0719/0.0760", 0.9461, "pass"),
    ("V$_2$Te$_2$O $M$", "S3-03", "0.08/0.10", 0.8000, "pass"),
    ("Mn$_3$NiN $Q$", "S3-04", "0.0029/0.051", 0.0573, "fail"),
    ("Mn$_3$NiN $Q$", "pg03", "0.0114/0.024", 0.4742, "caveat"),
    ("KV$_2$Se$_2$O $\\Delta E$", "pg09", "3.745/4.43", 0.8454, "pass"),
    ("CrSb AHC", "pg12", "52.9/72", 0.7343, "pass"),
    ("KMM spin $\\Lambda$", "pg13", "0.40/0.76", 0.5263, "caveat"),
]

STYLE = {
    "pass": (COLORS["green"], "o", COLORS["green"]),
    "caveat": (COLORS["orange"], "s", "white"),
    "fail": (COLORS["vermillion"], "o", COLORS["vermillion"]),
    "falsification": (COLORS["purple"], "v", "white"),
}

LABEL_ADJUST = {
    "pg04": (0.0, 0.11, "center", "bottom"),
    "pg05": (0.04, -0.12, "left", "top"),
    "pg07": (0.04, 0.08, "left", "bottom"),
    "pg08": (-0.08, -0.09, "right", "top"),
    "pg11": (0.03, 0.08, "left", "bottom"),
}


def draw_point(ax, track: str, session: str, label: str, ratio: float, status: str):
    base = dict(TRACKS)[track]
    offset = max(-0.34, min(0.34, math.log(ratio, 2) / 4.0))
    x = XMAP[session]
    y = base + offset
    color, marker, face = STYLE[status]
    ax.vlines(x, base, y, color=color, linewidth=0.7, alpha=0.72, zorder=2)
    ax.scatter(x, y, s=34, marker=marker, facecolor=face, edgecolor=color, linewidth=0.9, zorder=4)
    dx = 0.0
    dy = 0.075 if offset >= 0 else -0.075
    va = "bottom" if offset >= 0 else "top"
    ha = "center"
    if session in LABEL_ADJUST:
        dx, dy, ha, va = LABEL_ADJUST[session]
    ax.text(x + dx, y + dy, label, fontsize=5.15, ha=ha, va=va, color=COLORS["text"])


def main():
    apply_style()
    fig, ax = plt.subplots(figsize=(5.5, 2.78))
    ax.set_title("A1. Pilot anchors in raw units", loc="left", fontsize=8.2, fontweight="semibold", color=COLORS["text"], pad=8)

    for name, y in TRACKS:
        ax.hlines(y, -0.25, max(XMAP[k] for k in XMAP) + 0.55, color=COLORS["grid"], linewidth=0.6, zorder=0)

    for point in POINTS:
        draw_point(ax, *point)

    ax.set_ylim(-0.58, 6.88)
    ax.set_yticks([y for _, y in TRACKS], [name for name, _ in TRACKS])
    ax.tick_params(axis="y", length=0, labelsize=7.2)
    draw_session_ticks(ax, include_xlabel=True)
    ax.grid(True, axis="x", color=COLORS["grid"], linewidth=0.38, alpha=0.58)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.set_ylabel("")

    handles = [
        Line2D([0], [0], marker="o", color=COLORS["green"], markerfacecolor=COLORS["green"], linewidth=0, markersize=4.8, label="T4/pass"),
        Line2D([0], [0], marker="s", color=COLORS["orange"], markerfacecolor="white", linewidth=0, markersize=4.8, label="caveat / T3"),
        Line2D([0], [0], marker="o", color=COLORS["vermillion"], markerfacecolor=COLORS["vermillion"], linewidth=0, markersize=4.8, label="fail"),
        Line2D([0], [0], marker="v", color=COLORS["purple"], markerfacecolor="white", linewidth=0, markersize=4.8, label="falsification"),
    ]
    ax.legend(handles=handles, loc="upper right", bbox_to_anchor=(1.0, 1.09), frameon=False, ncol=4, fontsize=5.75, handletextpad=0.3, columnspacing=0.65)
    ax.text(0.01, 0.015, "Offset = log2 ratio; labels show raw values.", transform=ax.transAxes, fontsize=5.0, color=COLORS["muted"])

    save_png_pdf(fig, "figA1_multitrack_anchors", APPENDIX_DIR)


if __name__ == "__main__":
    main()
