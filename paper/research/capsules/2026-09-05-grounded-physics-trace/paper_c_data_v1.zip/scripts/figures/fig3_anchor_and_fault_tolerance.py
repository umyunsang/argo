from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from _paper_c_style import (
    COLORS,
    FIG_DIR,
    MECHANISM_COLORS,
    XMAP,
    apply_style,
    draw_session_ticks,
    load_anchor_csv,
    panel_title,
    save_png_pdf,
)


PANEL_B_INCIDENTS = [
    # label, start, end, lane, caveat, adversarial flavor, y-jitter
    ("KV2Se2O AM", "S1", "pg09", "Distributed grounding", False, None, 0.00),
    ("Ye 2.4x", "pg04", "reflect_01", "Adversarial review", False, "lit", 0.10),
    ("lit retractions x3", "S3-04", "reflect_01", "Adversarial review", False, "lit", 0.30),
    ("$\\Lambda^{orb}$\n-2.82->-0.019", "pg04", "pg11", "Adversarial review", False, "internal", 0.48),
    ("no plateau", "pg06", "pg07", "Adversarial review", False, "internal", -0.03),
    ("ref-II cap", "pg08", "reflect_II_02", "Adversarial review", False, "internal", -0.22),
    ("KMM 40x unit error", "pg11", "pg13", "Adversarial review", False, "internal", 0.13),
    ("CrSb sigma sign", "pg12", "pg12", "Adversarial review", True, "lit", -0.23),
    ("T1g/T2g", "S3-04", "S3-04", "Within-session debug", False, None, 0.00),
    ("pw2wan wfcU", "pg04", "pg04", "Within-session debug", False, None, 0.00),
    ("CrSb antiunitary", "pg12", "pg12", "Within-session debug", False, None, 0.00),
    ("Mn3NiN 17x", "S3-04", "pg02", "Falsification", False, None, 0.00),
    ("atomic relax", "pg03", "pg03", "Falsification", False, None, 0.00),
    ("basis extension", "pg07", "pg08", "Falsification", True, None, 0.00),
    ("PAW unconverge", "pg08", "pg08", "Falsification", True, None, 0.00),
]


def ratio_rows():
    rows = []
    for row in load_anchor_csv(FIG_DIR / "data" / "pilot_anchor_data.csv"):
        if row.get("comparison_type") == "tooling":
            continue
        if np.isnan(row.get("ratio", np.nan)):
            continue
        rows.append(row)
    return rows


def x_for_session(session_id: str) -> float:
    return XMAP.get(session_id, XMAP["S1"])


def draw_reflect_line(ax, key: str, label: str, ypos: float | None = None):
    x = XMAP[key]
    ax.axvline(x, color=COLORS["purple"], linestyle=(0, (1.3, 2.0)), linewidth=0.75, alpha=0.72, zorder=1)
    if ypos is not None:
        ax.text(x + 0.06, ypos, label, fontsize=5.9, color=COLORS["purple"], va="top", ha="left", linespacing=0.9)


def top_panel(ax):
    panel_title(ax, "A. Anchor enforcement", pad=2)
    ax.axhspan(0.5, 2.0, color=COLORS["green"], alpha=0.08, linewidth=0, zorder=0)
    ax.axhspan(0.8, 1.2, color=COLORS["green"], alpha=0.17, linewidth=0, zorder=0)
    ax.axhline(1.0, color=COLORS["text"], linewidth=0.8, zorder=1)

    for row in ratio_rows():
        target = row["reproduction_target"]
        is_ye = target.startswith("Ye 2026")
        y = float(row["ratio"])
        if is_ye:
            continue
        marker = "^" if y > 2.55 else "v" if y < 0.04 else "o"
        y_plot = min(max(y, 0.04), 2.55)
        ax.scatter(
            x_for_session(row["session_id"]),
            y_plot,
            s=24,
            marker=marker,
            facecolor="white",
            edgecolor="#88929B",
            linewidth=0.7,
            alpha=0.58,
            zorder=2,
        )

    ye_points = [
        ("pg04", 2.4297, "0.4286"),
        ("pg05", 1.3475, "0.2377"),
        ("pg07", 1.0901, "0.1923"),
        ("pg11", 1.0905, "0.19237"),
    ]
    xs = [XMAP[s] for s, _, _ in ye_points]
    ys = [r for _, r, _ in ye_points]
    ax.plot(xs, ys, color=COLORS["blue"], linewidth=1.45, zorder=4)
    ax.scatter(xs, ys, s=46, facecolor=COLORS["blue"], edgecolor="white", linewidth=0.8, zorder=5)
    for sid, y, value in ye_points:
        dy = 0.10 if sid in {"pg04", "pg11"} else 0.08
        ax.text(XMAP[sid], y + dy, value, fontsize=6.0, color=COLORS["text"], ha="center", va="bottom")

    ax.scatter(XMAP["pg07"] + 0.20, 1.8396, s=40, marker="s", facecolor="white", edgecolor=COLORS["orange"], linewidth=0.9, zorder=5)
    ax.text(XMAP["pg07"] + 0.48, 1.80, "16x mesh\n1.84x", fontsize=5.8, color=COLORS["orange"], va="center", ha="left", linespacing=0.92)

    ax.scatter(XMAP["pg08"], 0.04, s=48, marker="v", facecolor="white", edgecolor=COLORS["purple"], linewidth=1.0, zorder=5)
    ax.text(XMAP["pg08"] - 0.10, 0.14, "basis\n-> 0", fontsize=5.7, color=COLORS["purple"], ha="right", va="bottom", linespacing=0.9)

    draw_reflect_line(ax, "reflect_01", "ref01:\nYe found", 2.28)
    draw_reflect_line(ax, "reflect_II_02", "ref-II:\ncap", 1.58)

    ax.text(XMAP["pg11"] + 0.30, 1.34, "prod.\nlocked", fontsize=5.55, color=COLORS["text"], va="bottom", ha="left", linespacing=0.9)
    right = max(XMAP[k] for k in XMAP) + 0.55
    ax.text(right, 1.02, "1x", ha="right", va="bottom", fontsize=6.0, color=COLORS["text"])
    ax.text(right, 1.20, "T4", ha="right", va="bottom", fontsize=5.8, color=COLORS["green"])
    ax.text(right, 2.00, "T3", ha="right", va="bottom", fontsize=5.8, color=COLORS["green"])

    ax.set_ylim(0, 2.68)
    ax.set_yticks([0, 0.5, 1, 1.5, 2, 2.5])
    ax.set_ylabel("pipeline / literature")
    ax.grid(True, axis="x", color=COLORS["grid"], linewidth=0.42, alpha=0.65)
    ax.grid(True, axis="y", color=COLORS["grid"], linewidth=0.35, alpha=0.28)
    ax.tick_params(axis="x", bottom=False, labelbottom=False)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)

    ax.text(XMAP["pg12"] + 0.15, 0.34, r"blue: MnTe $M_z^{orb}$", fontsize=5.45, color=COLORS["blue"], ha="left")
    ax.text(XMAP["pg12"] + 0.15, 0.17, "grey = context; orange = caveat", fontsize=5.35, color=COLORS["muted"], ha="left")


def bottom_panel(ax):
    panel_title(ax, "B. Corrections by primary mechanism", pad=2)
    lanes = {
        "Distributed grounding": 3,
        "Adversarial review": 2,
        "Within-session debug": 1,
        "Falsification": 0,
    }
    label_offsets = {
        "Ye 2.4x": -0.16,
        "lit retractions x3": 0.20,
        "$\\Lambda^{orb}$\n-2.82->-0.019": 0.22,
        "KMM 40x unit error": 0.20,
        "KV2Se2O AM": 0.29,
        "CrSb antiunitary": 0.16,
        "pw2wan wfcU": 0.18,
        "basis extension": 0.16,
        "PAW unconverge": -0.25,
        "ref-II cap": -0.21,
        "CrSb sigma sign": -0.18,
        "T1g/T2g": 0.18,
        "no plateau": 0.17,
        "Mn3NiN 17x": 0.20,
        "atomic relax": -0.24,
    }
    label_x_offsets = {
        "Ye 2.4x": 0.00,
        "lit retractions x3": -0.15,
        "$\\Lambda^{orb}$\n-2.82->-0.019": 0.10,
        "no plateau": -0.10,
        "ref-II cap": 0.10,
        "KMM 40x unit error": 0.00,
        "CrSb sigma sign": 0.28,
        "atomic relax": 0.05,
    }

    for key in ("reflect_01", "reflect_II_02"):
        draw_reflect_line(ax, key, "", None)

    for mech, y in lanes.items():
        ax.axhline(y, color=COLORS["grid"], lw=0.68, zorder=0)
        ax.text(-0.25, y + 0.07, mech, fontsize=5.9, color=MECHANISM_COLORS[mech], fontweight="bold", ha="left")

    for label, start_key, end_key, mech, caveat, adv_flavor, y_jitter in PANEL_B_INCIDENTS:
        start = XMAP[start_key]
        end = XMAP[end_key]
        y = lanes[mech] + y_jitter
        color = MECHANISM_COLORS[mech]
        ls = "--" if caveat else "-"
        alpha = 0.45 if caveat else 0.95
        marker = "D" if adv_flavor == "lit" else "o"
        marker_size = 28 if marker == "D" else 34
        if abs(end - start) < 0.01:
            ax.scatter([start], [y], s=marker_size, marker=marker, color=color, edgecolor="white", linewidth=0.65, alpha=alpha, zorder=3)
            ax.plot([start - 0.13, start + 0.13], [y, y], color=color, lw=1.05, ls=ls, alpha=alpha)
        else:
            lw = 1.95 if label.startswith(r"$\Lambda") else 1.55
            ax.plot([start, end], [y, y], color=color, lw=lw, ls=ls, alpha=alpha, solid_capstyle="round")
            ax.scatter([start, end], [y, y], s=17 if marker == "o" else 23, marker=marker, color=color, edgecolor="white", linewidth=0.45, alpha=alpha, zorder=3)
        label_x = (start + end) / 2 + label_x_offsets.get(label, 0.0)
        is_lambda_label = label.startswith("$\\Lambda")
        ax.text(
            label_x,
            y + label_offsets.get(label, 0.16),
            label,
            ha="center",
            va="center",
            fontsize=4.55,
            color=COLORS["text"],
            alpha=0.78 if caveat else 1.0,
            linespacing=0.86,
            bbox=dict(facecolor="white", edgecolor="none", alpha=0.72, pad=0.10) if is_lambda_label else None,
        )

    draw_session_ticks(ax, include_xlabel=True)
    ax.set_ylim(-0.48, 3.62)
    ax.set_yticks([])
    for spine in ["left", "right", "top"]:
        ax.spines[spine].set_visible(False)
    ax.grid(True, axis="x", color=COLORS["grid"], lw=0.42, alpha=0.65)
    ax.text(max(XMAP[k] for k in XMAP) + 0.50, 3.39, "adversarial: diamond=lit, circle=internal", fontsize=4.85, color=COLORS["muted"], ha="right")
    ax.text(max(XMAP[k] for k in XMAP) + 0.50, 3.19, "dashed = caveat-flagged", fontsize=4.85, color=COLORS["muted"], ha="right")


def main():
    apply_style()
    fig = plt.figure(figsize=(5.5, 3.4))
    gs = fig.add_gridspec(2, 1, height_ratios=[1.36, 1.62], hspace=0.20)
    ax_top = fig.add_subplot(gs[0, 0])
    ax_bottom = fig.add_subplot(gs[1, 0], sharex=ax_top)
    top_panel(ax_top)
    bottom_panel(ax_bottom)
    save_png_pdf(fig, "fig3_anchor_and_fault_tolerance", FIG_DIR)


if __name__ == "__main__":
    main()
