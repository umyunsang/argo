"""Data module v4 — adds per-session arxiv-ID lists for the 3 final fig2 versions.

Provides three concept of "what each dot represents":

V1 (fig1c-aligned): 593 / 120 / 536 dots per breadth session, 95 dots web.
                    Matches Fig 1c bar heights. Dots are real arxiv IDs
                    sampled from session_accessed_ids; if a session has more
                    accessed IDs than its event count (typical), we pick the
                    first N. Note that v1 is presented as a UNIQUE-ITEM count
                    that matches Fig 1c exactly per the dedup analysis.

V2 (report-cited): 332 / 431 / 317 dots per breadth session, 17 dots web.
                   Each dot is an ID *cited in the final breadth report*,
                   or a depth-cited web-only ID.

V3 (all-touched):  1102 / 2504 / 832 dots per breadth session (main traces),
                   95 dots web. Each dot is any ID the agent saw in a
                   tool result — most comprehensive but visually densest.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

THIS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(THIS_DIR))

from _fig2_data3 import *  # noqa


SESSION_IDS_PATH = THIS_DIR / "categorization" / "session_accessed_ids.json"
SESSION_IDS = json.loads(SESSION_IDS_PATH.read_text())

# Real depth-external arxiv IDs (only from WebFetch/WebSearch/external bash)
DEPTH_EXTERNAL_PATH = THIS_DIR / "categorization" / "depth_external_ids.json"
if DEPTH_EXTERNAL_PATH.exists():
    _DEPTH_EXTERNAL = json.loads(DEPTH_EXTERNAL_PATH.read_text())
    REAL_DEPTH_EXTERNAL_IDS = _DEPTH_EXTERNAL["union"]
else:
    REAL_DEPTH_EXTERNAL_IDS = []


def get_breadth_report_ids():
    """Return {b01: set, b02: set, b03: set} of arxiv IDs cited in each report."""
    ARXIV_RE = re.compile(r"\b(2[5-6]\d{2}\.\d{4,5})\b")
    out = {}
    for k in [1, 2, 3]:
        p = Path(f"<PROJECT>/runs/run_002/breadth/breadth_0{k}/breadth_report.md")
        out[f"b0{k}"] = set(ARXIV_RE.findall(p.read_text()))
    return out


CITED_BY_BREADTH = get_breadth_report_ids()


# === Web-only IDs (cited by depth, in NO breadth report) ===
def get_web_only_depth_ids():
    """Return list of arxiv IDs cited by depth that are not in any breadth report."""
    ARXIV_RE = re.compile(r"\b(2[5-6]\d{2}\.\d{4,5})\b")
    breadth_union = set()
    for s in CITED_BY_BREADTH.values():
        breadth_union |= s
    web = []
    web_set = set()
    for k in [1, 2, 3, 4, 5]:
        p = Path(f"<PROJECT>/runs/run_002/depth/depth_0{k}/research_program.md")
        for aid in ARXIV_RE.findall(p.read_text()):
            if aid not in breadth_union and aid not in web_set:
                web_set.add(aid)
                web.append(aid)
    return web


WEB_ONLY_IDS = get_web_only_depth_ids()

# Build the depth-external ID list:
# - Start with REAL_DEPTH_EXTERNAL_IDS (extracted from WebFetch/WebSearch/api bash)
# - Union with WEB_ONLY_IDS (cited by depth, not in any breadth report — these
#   came from external lookups even if my regex missed the URL)
DEPTH_EXTERNAL_IDS = []
seen = set()
for aid in WEB_ONLY_IDS + REAL_DEPTH_EXTERNAL_IDS:
    if aid not in seen:
        DEPTH_EXTERNAL_IDS.append(aid)
        seen.add(aid)


# === Per-session EVENT counts (matches Fig 1c bar heights) ===
# web count is now len(DEPTH_EXTERNAL_IDS), the actual unique external IDs
EVENT_COUNTS = {
    "b01": 593,   # 52 parent + 541 subagent
    "b02": 120,
    "b03": 536,
    "web": len(DEPTH_EXTERNAL_IDS),
}

REPORT_CITED_COUNTS = {
    "b01": 332,
    "b02": 431,
    "b03": 317,
    "web": 17,
}

ALL_TOUCHED_COUNTS = {
    "b01": 2220,  # main + subagents combined
    "b02": 2504,
    "b03": 832,
    "web": 95,
}


def sample_for_band_v1(band_key, n_target):
    """Pick n_target arxiv IDs for the given band, matching Fig 1c event count.

    For b01 we use breadth_01_with_subagents (parent + 10 Explore subagents'
    combined reach, 2,220 IDs) since breadth_01's 593 events include both
    parent (52) and subagent (541) literature events.
    """
    if band_key == "web":
        return DEPTH_EXTERNAL_IDS[:n_target]
    sess_lookup = {
        "b01": "breadth_01_with_subagents",
        "b02": "breadth_02",
        "b03": "breadth_03",
    }
    sess_key = sess_lookup[band_key]
    cited = list(CITED_BY_BREADTH[band_key])
    seen = set(cited)
    extra = []
    for aid in SESSION_IDS.get(sess_key, []):
        if aid not in seen:
            extra.append(aid); seen.add(aid)
    out = cited + extra
    return out[:n_target]


def get_v1_ids(band_key):
    return sample_for_band_v1(band_key, EVENT_COUNTS[band_key])


def get_v2_ids(band_key):
    if band_key == "web":
        return WEB_ONLY_IDS
    return sorted(CITED_BY_BREADTH[band_key])


def get_v3_ids(band_key):
    """All-touched: every ID seen in tool result for that session."""
    if band_key == "web":
        return DEPTH_EXTERNAL_IDS
    if band_key == "b01":
        return SESSION_IDS.get("breadth_01_with_subagents", SESSION_IDS["breadth_01"])
    if band_key == "b02":
        return SESSION_IDS["breadth_02"]
    if band_key == "b03":
        return SESSION_IDS["breadth_03"]
    return []


def get_v4_ids(band_key):
    """v4 = v1 (active access events) ∪ v2 (report-cited IDs), deduped.

    v1 captures active retrieval (markdown reads, SQL row selections, API
    calls). v2 captures everything that made it into the breadth report —
    which can include IDs the agent surveyed via title_list.md scanning
    (counted by the dedup as not "active" since title_list isn't a
    paper-markdown read). The union recovers BOTH the active-access events
    and the report-surfaced IDs.

    For the web band: v4 = v1 (already contains v2's 17 web-only).
    """
    s1 = set(get_v1_ids(band_key))
    s2 = set(get_v2_ids(band_key))
    return sorted(s1 | s2)


# Counts as an aid to the writing agent
V4_COUNTS = {bk: len(get_v4_ids(bk)) for bk in ("b01", "b02", "b03", "web")}


# === Per-category × per-month corpus paper counts (for histogram band) ===
CATEGORY_MONTH_PATH = THIS_DIR / "categorization" / "category_month_counts.json"
if CATEGORY_MONTH_PATH.exists():
    CATEGORY_MONTH_COUNTS = json.loads(CATEGORY_MONTH_PATH.read_text())
else:
    CATEGORY_MONTH_COUNTS = {}


def get_corpus_histogram(cat_name: str):
    """Return list of (month_index, count) for the 7-month corpus window."""
    data = CATEGORY_MONTH_COUNTS.get(cat_name, {})
    out = []
    for ym, label_m in [("2025-10", 10), ("2025-11", 11), ("2025-12", 12),
                          ("2026-01", 13), ("2026-02", 14), ("2026-03", 15),
                          ("2026-04", 16)]:
        out.append((label_m, data.get(ym, 0)))
    return out


# === Per-day corpus counts (for fine-binned histograms) ===
import calendar as _cal
from datetime import date, timedelta

CATEGORY_DAY_PATH = THIS_DIR / "categorization" / "category_day_counts.json"
if CATEGORY_DAY_PATH.exists():
    CATEGORY_DAY_COUNTS = json.loads(CATEGORY_DAY_PATH.read_text())
else:
    CATEGORY_DAY_COUNTS = {}


def get_corpus_histogram_binned(cat_name: str, n_bins: int,
                                  date_lo: str = "2025-10-14",
                                  date_hi: str = "2026-04-13"):
    """Return list of (bin_center_month_value, count) for n_bins bins between
    date_lo and date_hi.

    Bin_center is in continuous month space: 2025-Oct-1 = 10.0, 2026-Apr-30 = 16.97.
    """
    d0 = date.fromisoformat(date_lo)
    d1 = date.fromisoformat(date_hi)
    total_days = (d1 - d0).days + 1
    bin_days = total_days / n_bins

    counts = [0] * n_bins
    centers_m = []

    cat_data = CATEGORY_DAY_COUNTS.get(cat_name, {})
    for day_str, n in cat_data.items():
        d = date.fromisoformat(day_str)
        days_from_start = (d - d0).days
        bin_idx = int(days_from_start / bin_days)
        bin_idx = max(0, min(n_bins - 1, bin_idx))
        counts[bin_idx] += n

    # Compute bin centers in continuous-month space
    for i in range(n_bins):
        center_day = d0 + timedelta(days=int((i + 0.5) * bin_days))
        days_in_month = _cal.monthrange(center_day.year, center_day.month)[1]
        if center_day.year == 2025:
            base = center_day.month
        elif center_day.year == 2026:
            base = 12 + center_day.month
        else:
            base = (center_day.year - 2025) * 12 + center_day.month
        m_val = float(base) + (center_day.day - 1) / days_in_month
        centers_m.append(m_val)

    return list(zip(centers_m, counts))


# Helpers for cited-vs-accessed distinction in v4
def is_cited(arxiv_id: str, band_key: str) -> bool:
    """True if this ID is cited in the breadth report for that band, OR is
    a web-only depth-cited ID for the web band."""
    if band_key == "web":
        return arxiv_id in WEB_ONLY_IDS
    return arxiv_id in CITED_BY_BREADTH.get(band_key, set())

