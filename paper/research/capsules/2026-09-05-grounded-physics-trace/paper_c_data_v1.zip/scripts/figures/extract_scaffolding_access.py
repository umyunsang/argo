from __future__ import annotations

import csv
import json
import re
from pathlib import Path


FIG_DATA = Path(__file__).resolve().parent
RUN_ROOT = FIG_DATA.parents[2]
PER_SESSION = RUN_ROOT / "analysis" / "info_flow_data" / "per_session"
PER_STAGE = RUN_ROOT / "analysis" / "info_flow_data" / "per_stage_summary.csv"

FIGURE_SESSION_ORDER = [
    "breadth_01",
    "breadth_02",
    "breadth_03",
    "depth_01",
    "depth_02",
    "depth_03",
    "depth_04",
    "depth_05",
    "session_1_prior_work",
    "session_2_tooling",
    "session_3_reproduce_01",
    "session_3_reproduce_02",
    "session_3_reproduce_03",
    "session_3_reproduce_04",
    "session_3_reproduce_05",
    "pilot_gate_01",
    "pilot_gate_02",
    "pilot_gate_03",
    "pilot_gate_04",
    "pilot_reflect_01",
    "pilot_gate_05",
    "pilot_gate_06",
    "pilot_gate_07",
    "pilot_gate_08",
    "pilot_reflect_II_02",
    "pilot_gate_09",
    "pilot_gate_10",
    "pilot_gate_11",
    "pilot_gate_12",
    "pilot_gate_13",
    "pilot_gate_14",
    "pilot_gate_15",
    "pre_production",
    "production_initial",
    "production_continue_01",
    "production_continue_02",
    "production_continue_03",
    "run_1_1A",
    "run_2_1A",
    "run_3_1A",
    "run_1_1B",
    "run_2_1B",
    "run_3_1B",
    "run_1_full",
    "run_2_full",
    "run_3_full",
    "polish",
]


def broad_phase(stage: str) -> str:
    if stage in {"breadth", "depth"}:
        return stage
    if stage.startswith("pilot"):
        return "pilot"
    if stage == "pre_production":
        return "pre-prod"
    if stage.startswith("production"):
        return "production"
    return "writing"


def has_any(reads: list[str], needles: tuple[str, ...]) -> bool:
    return any(any(needle in path for needle in needles) for path in reads)


def shell_access(commands: list, patterns: tuple[str, ...]) -> bool:
    joined = []
    for command in commands:
        if isinstance(command, dict):
            joined.append(command.get("cmd", ""))
        else:
            joined.append(str(command))
    pattern = re.compile(r"(cat|grep|rg|sed|awk|head|tail).*(%s)" % "|".join(patterns), re.IGNORECASE)
    return any(pattern.search(command) for command in joined)


def prompt_mandates(prompt: str, needles: tuple[str, ...]) -> bool:
    return any(needle in prompt for needle in needles)


def status(direct: bool, shell: bool, mandated: bool) -> str:
    if direct:
        return "direct_read"
    if shell:
        return "shell_partial"
    if mandated:
        return "mandated_unread"
    return "not_read"


def evidence(stage: str, session_id: str, knowledge_status: str, house_status: str) -> str:
    if stage == "breadth":
        return "per_session read_paths; audit 7 §1.1: INDEX/HOUSE_RULES deliberately omitted for pre-computational breadth"
    if stage == "depth":
        return "per_session read_paths; audit 7 §1.2: INDEX/HOUSE_RULES deliberately omitted for pre-computational depth"
    if stage == "pilot_S1":
        return "per_session read_paths; audit 7 §1.4: S1 prior-work/program selection omits INDEX/HOUSE_RULES"
    if stage == "pilot_S2":
        return "per_session read_paths show INDEX/PSEUDOPOTENTIALS and PILOT_HOUSE_RULES"
    if stage == "pilot_S3" and session_id == "session_3_reproduce_05":
        return "prompt mandates INDEX/PSEUDOPOTENTIALS; no Read-tool access, but Bash cats PSEUDOPOTENTIALS head -150 and INDEX head -100; HOUSE_RULES read directly"
    if stage == "pilot_S3":
        return "per_session read_paths show curated knowledge files plus PILOT_HOUSE_RULES"
    if stage == "pilot_gate":
        return "per_session read_paths; audit 7 §1.6: pilot gates read INDEX 15/15 and HOUSE_RULES 15/15"
    if stage == "pilot_reflect":
        return "per_session read_paths; audit 7 §1.7: reflect_01 read HOUSE_RULES only, reflect_II read neither"
    if stage == "pre_production":
        return "prompt does not mandate INDEX/PSEUDO/HOUSE; actual trace reads/greps INDEX only and does not access HOUSE_RULES"
    if stage == "production_init":
        return "per_session read_paths show INDEX and PILOT_HOUSE_RULES"
    if stage == "production_continue":
        return "per_session read_paths; audit 7 §1.10: continues read INDEX and HOUSE_RULES"
    if stage.startswith("write") or stage == "polish":
        return "per_session read_paths; audit 7 §§1.11-1.14: writing/polish prompts omit INDEX/HOUSE_RULES"
    return "per_session read_paths"


def main() -> None:
    rows: list[dict[str, str]] = []
    with PER_STAGE.open(newline="") as f:
        for record in csv.DictReader(f):
            session_id = record["session_label"]
            stage = record["stage"]
            json_path = PER_SESSION / f"{stage}__{session_id}.json"
            data = json.loads(json_path.read_text())
            reads = data["read_paths"]
            prompt = data["first_user_prompt"]
            commands = data["bash_commands"]
            knowledge_direct = has_any(
                reads,
                (
                    "/knowledge/INDEX.md",
                    "/knowledge/PSEUDOPOTENTIALS.md",
                ),
            )
            house_rules_direct = has_any(reads, ("PILOT_HOUSE_RULES.md",))
            knowledge_shell = shell_access(commands, ("INDEX\\.md", "PSEUDOPOTENTIALS\\.md"))
            house_rules_shell = shell_access(commands, ("PILOT_HOUSE_RULES", "HOUSE_RULES"))
            knowledge_mandated = prompt_mandates(prompt, ("INDEX.md", "PSEUDOPOTENTIALS.md"))
            house_rules_mandated = prompt_mandates(prompt, ("PILOT_HOUSE_RULES.md", "HOUSE_RULES"))
            knowledge_status = status(knowledge_direct, knowledge_shell, knowledge_mandated)
            house_rules_status = status(house_rules_direct, house_rules_shell, house_rules_mandated)
            rows.append(
                {
                    "session_id": session_id,
                    "phase": broad_phase(stage),
                    "knowledge_loaded": str(knowledge_status in {"direct_read", "shell_partial"}),
                    "house_rules_loaded": str(house_rules_status in {"direct_read", "shell_partial"}),
                    "knowledge_status": knowledge_status,
                    "house_rules_status": house_rules_status,
                    "knowledge_prompt_mandated": str(knowledge_mandated),
                    "house_rules_prompt_mandated": str(house_rules_mandated),
                    "source_evidence": evidence(stage, session_id, knowledge_status, house_rules_status),
                }
            )
    order = {session_id: idx for idx, session_id in enumerate(FIGURE_SESSION_ORDER)}
    if set(order) != {row["session_id"] for row in rows}:
        missing = set(order) - {row["session_id"] for row in rows}
        extra = {row["session_id"] for row in rows} - set(order)
        raise RuntimeError(f"Session-order mismatch; missing={sorted(missing)} extra={sorted(extra)}")
    rows.sort(key=lambda row: order[row["session_id"]])

    out_csv = FIG_DATA / "scaffolding_access_per_session.csv"
    with out_csv.open("w", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "session_id",
                "phase",
                "knowledge_loaded",
                "house_rules_loaded",
                "knowledge_status",
                "house_rules_status",
                "knowledge_prompt_mandated",
                "house_rules_prompt_mandated",
                "source_evidence",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    counts = {
        "knowledge": sum(row["knowledge_loaded"] == "True" for row in rows),
        "house": sum(row["house_rules_loaded"] == "True" for row in rows),
        "knowledge_direct": sum(row["knowledge_status"] == "direct_read" for row in rows),
        "knowledge_partial": sum(row["knowledge_status"] == "shell_partial" for row in rows),
        "knowledge_mandated_unread": sum(row["knowledge_status"] == "mandated_unread" for row in rows),
        "house_direct": sum(row["house_rules_status"] == "direct_read" for row in rows),
        "house_partial": sum(row["house_rules_status"] == "shell_partial" for row in rows),
        "house_mandated_unread": sum(row["house_rules_status"] == "mandated_unread" for row in rows),
        "total": len(rows),
    }
    out_md = FIG_DATA / "SCAFFOLDING_INVESTIGATION.md"
    out_md.write_text(
        "\n".join(
            [
                "# Scaffolding Access Investigation",
                "",
                "Source of truth: `analysis/info_flow_data/per_session/*.json`, generated from the",
                "canonical trace inventory by `analysis/scripts/info_flow_extract.py` and summarized",
                "in `analysis/07_info_flow_audit.md`. I used explicit `Read` paths, not prompt",
                "intent alone.",
                "",
                "## Definitions",
                "",
                "- `knowledge_loaded=True` when the trace-extracted behavior includes external",
                "  human-curated methodology/tool scaffolding: global `INDEX.md` or global",
                "  `PSEUDOPOTENTIALS.md`. `direct_read` means a tool Read. `shell_partial`",
                "  means only shell content access such as `cat ... | head` or `grep`.",
                "- `house_rules_loaded=True` when the trace-extracted behavior includes",
                "  `PILOT_HOUSE_RULES.md`.",
                "- `literature_access.md` is excluded because Fig. 1 panels B/C already count",
                "  literature consultation and because audit 7 classifies it as a literature",
                "  routing/tool-access file rather than the compute-methodology scaffold.",
                "- `pre_production/lessons_learned.md` is excluded: it is a downstream",
                "  distillation/handoff artifact, not curated knowledge.",
                "- S2-built `TOOL_REPORT.md` and per-tool docs are excluded: they are local",
                "  agent-generated tooling handoff artifacts, not the external curated",
                "  knowledge base controlled by this figure.",
                "",
                "## Results",
                "",
                f"- Curated knowledge loaded in {counts['knowledge']}/{counts['total']} canonical sessions",
                f"  ({counts['knowledge_direct']} direct Read, {counts['knowledge_partial']} shell-partial).",
                f"- House rules loaded in {counts['house']}/{counts['total']} canonical sessions",
                f"  ({counts['house_direct']} direct Read, {counts['house_partial']} shell-partial).",
                f"- Mandated-but-unread cells: knowledge {counts['knowledge_mandated_unread']},",
                f"  house rules {counts['house_mandated_unread']}.",
                "- Breadth, depth, and pilot S1 have both bands empty: the omission is deliberate",
                "  in the prompts and matches the design goal of keeping conception open.",
                "- Pilot S2, S3 reproductions 01-04, and all pilot gates direct-read external",
                "  curated knowledge. S3-05 is the outlier: its prompt mandates both files,",
                "  but the trace shows shell-partial access only (`PSEUDOPOTENTIALS.md | head -150`,",
                "  `INDEX.md | head -100`) rather than a direct full Read.",
                "- Reflects are not compute sessions: `reflect_01` directly reads house rules but",
                "  no curated knowledge files; `reflect_II_02` reads neither directly.",
                "- The CSV is ordered for Fig. 1's pilot chronology: pg01-04, reflect_01,",
                "  pg05-08, reflect_II_02, pg09-15. This avoids the stage-summary artifact",
                "  that appends reflect sessions after pg15.",
                "- Pre-production prompt does not mandate INDEX/PSEUDO/HOUSE. The trace reads",
                "  and greps `INDEX.md` by agent choice, does not read `PSEUDOPOTENTIALS.md`,",
                "  and does not access house rules.",
                "- Production sessions read house rules and at least one curated knowledge source;",
                "  direct `lessons_learned.md` reads vary by continue session but are not counted",
                "  in the curated-knowledge band.",
                "- Writing/polish sessions do not directly load curated knowledge or house rules;",
                "  `run_2_1A` reads `lessons_learned.md`, but that handoff document is excluded",
                "  from the band by definition.",
                "",
                "## Caveat",
                "",
                "Round 13 §1.3 contains a broader prose line saying `INDEX.md` was read by",
                "`writing×9`, `polish`, and `reflect_II_02`. The direct per-session read-path",
                "JSON and audit 7 stage tables do not support that: writing/polish prompts omit",
                "INDEX/HOUSE_RULES and the direct read-path data only shows `run_2_1A` reading",
                "`lessons_learned.md`, which is not counted here as curated knowledge. For",
                "Fig. 1, I use the direct trace-extracted read paths.",
                "",
                f"CSV written to `{out_csv}`.",
                "",
            ]
        )
    )


if __name__ == "__main__":
    main()
