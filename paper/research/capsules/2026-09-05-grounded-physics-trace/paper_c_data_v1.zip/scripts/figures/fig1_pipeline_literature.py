import csv

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

from _paper_c_style import (
    CHANNELS_14,
    COLORS,
    FIG_DIR,
    GROUP_COLORS,
    PHASE_COLORS,
    PHASE_GROUPS,
    PHASES,
    PHASE_TOTALS,
    apply_style,
    clean_axis,
)


apply_style()

PANEL_TITLE_FS = 6.55
AXIS_LABEL_FS = 6.45


def fig1_panel_title(ax, text, loc="left", pad=3):
    ax.set_title(text, loc=loc, fontsize=PANEL_TITLE_FS, fontweight="semibold", color=COLORS["text"], pad=pad)


def load_scaffolding_rows():
    path = FIG_DIR / "data" / "scaffolding_access_per_session.csv"
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


scaffolding_rows = load_scaffolding_rows()

fig = plt.figure(figsize=(5.5, 3.12))
gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.30], hspace=0.32, wspace=0.36)

ax = fig.add_subplot(gs[0, :])
ax.set_axis_off()
ax.set_xlim(0, 47)
ax.set_ylim(0, 1)
fig1_panel_title(ax, "A. Structured pipeline with pilot iteration cap", loc="left")

cursor = 0
phase_label_fs = 5.65
for phase, count in PHASES:
    ax.add_patch(plt.Rectangle((cursor, 0.49), count, 0.18, color=PHASE_COLORS[phase], alpha=0.94))
    if phase == "Pre-prod":
        ax.text(cursor + count / 2 - 0.08, 0.77, "pre-prod\n1", ha="center", va="center", color=COLORS["text"], fontsize=5.0, fontweight="bold", linespacing=0.9)
    elif phase == "Production":
        ax.text(cursor + count / 2 + 0.10, 0.77, "prod\n4", ha="center", va="center", color=COLORS["text"], fontsize=5.35, fontweight="bold", linespacing=0.9)
    elif phase == "Breadth":
        ax.text(cursor + count / 2, 0.58, "Breadth\n3", ha="center", va="center", color="white", fontsize=phase_label_fs, fontweight="bold", linespacing=0.96)
    elif phase == "Depth":
        ax.text(cursor + count / 2, 0.58, "Depth\n5", ha="center", va="center", color="white", fontsize=phase_label_fs, fontweight="bold", linespacing=0.96)
    else:
        ax.text(cursor + count / 2, 0.58, f"{phase}\n{count}", ha="center", va="center", color="white", fontsize=phase_label_fs, fontweight="bold", linespacing=0.96)
    for tick in range(count):
        ax.plot([cursor + tick + 0.5, cursor + tick + 0.5], [0.45, 0.49], color=COLORS["text"], lw=0.32, alpha=0.42)
    cursor += count

pilot_start = 8
coarse_segments = [
    (0, 7, "setup"),
    (7, 12, "cycle 1"),
    (12, 17, "cycle 2"),
    (17, 24, "directed exec"),
]
for off0, off1, label in coarse_segments:
    x0 = pilot_start + off0
    w = off1 - off0
    ax.add_patch(plt.Rectangle((x0, 0.342), w, 0.065, color=COLORS["orange"], alpha=0.20, ec=COLORS["orange"], lw=0.45))
    ax.text(x0 + w / 2, 0.375, label, ha="center", va="center", fontsize=5.25, color=COLORS["text"])

detail_segments = [
    (0, 1, "S1", COLORS["orange"]),
    (1, 2, "S2", COLORS["orange"]),
    (2, 7, "S3 reproduce x5", COLORS["orange"]),
    (7, 11, "pg01-04", COLORS["orange"]),
    (11, 12, "ref01", COLORS["vermillion"]),
    (12, 16, "pg05-08", COLORS["orange"]),
    (16, 17, "ref-II", COLORS["vermillion"]),
    (17, 24, "pg09-15", COLORS["orange"]),
]
for off0, off1, label, color in detail_segments:
    x0 = pilot_start + off0
    w = off1 - off0
    is_reflect = color == COLORS["vermillion"]
    ax.add_patch(plt.Rectangle((x0, 0.255), w, 0.073, color=color, alpha=0.21 if is_reflect else 0.12, ec=color, lw=0.36))
    ax.text(
        x0 + w / 2,
        0.292,
        label,
        ha="center",
        va="center",
        fontsize=3.65 if w <= 1.1 else 4.05,
        color=color if is_reflect else COLORS["text"],
        fontweight="bold" if is_reflect else "normal",
    )
cap_x = pilot_start + 16.5
ax.annotate(
    "",
    xy=(cap_x, 0.255),
    xytext=(cap_x, 0.222),
    arrowprops=dict(arrowstyle="-|>", color=COLORS["vermillion"], lw=0.7, mutation_scale=5.0),
)
ax.text(cap_x + 0.32, 0.230, "cap", ha="left", va="center", fontsize=5.0, color=COLORS["vermillion"], fontweight="bold")

band_specs = [
    ("knowledge_status", "INDEX/PSEUDO", COLORS["blue"], 0.135),
    ("house_rules_status", "HOUSE_RULES", COLORS["vermillion"], 0.075),
]
for key, label, color, y0 in band_specs:
    mandate_key = "knowledge_prompt_mandated" if key.startswith("knowledge") else "house_rules_prompt_mandated"
    for i, row in enumerate(scaffolding_rows):
        accessed = row[key] in {"direct_read", "shell_partial"}
        if accessed:
            facecolor = color
            edgecolor = color
            alpha = 0.76 if row[mandate_key] == "True" else 0.32
        else:
            facecolor = COLORS["white"]
            edgecolor = COLORS["grid"]
            alpha = 1.0
        ax.add_patch(
            plt.Rectangle(
                (i + 0.06, y0),
                0.86,
                0.045,
                facecolor=facecolor,
                edgecolor=edgecolor,
                linewidth=0.34,
                alpha=alpha,
            )
        )
    ax.text(
        46.95,
        y0 + 0.023,
        label,
        va="center",
        ha="right",
        fontsize=4.85,
        color=color,
        fontweight="bold",
        bbox=dict(facecolor="white", edgecolor="none", alpha=0.88, pad=0.2),
    )
ax.text(0.05, 0.020, "solid=mandated; light=unmandated; hollow=not read", fontsize=4.15, color=COLORS["muted"], ha="left", va="top")

callouts = [
    (2.5, "fresh-context\nisolation", COLORS["blue"]),
    (11.0, "distributed\ngrounding", COLORS["green"]),
    (21.0, "adversarial\nreview", COLORS["vermillion"]),
]
for x0, label, color in callouts:
    ax.add_patch(plt.Rectangle((x0, 0.84), 6.6, 0.10, facecolor=color, alpha=0.10, edgecolor=color, lw=0.45))
    ax.text(x0 + 3.3, 0.89, label, ha="center", va="center", fontsize=5.4, color=color, fontweight="bold", linespacing=0.9)

ax1 = fig.add_subplot(gs[1, 0])
fig1_panel_title(ax1, "B. Literature channels")
channels = sorted(CHANNELS_14, key=lambda x: x[1])
y = np.arange(len(channels))
ax1.barh(y, [c[1] for c in channels], color=[GROUP_COLORS[c[2]] for c in channels], height=0.62)
ax1.set_yticks(y, [c[0] for c in channels])
ax1.tick_params(axis="y", labelsize=5.8, pad=1)
ax1.tick_params(axis="x", labelsize=6.0)
ax1.set_xlabel("events", fontsize=AXIS_LABEL_FS)
ax1.set_xlim(0, 1320)
for yi, (_, val, _) in zip(y, channels):
    ax1.text(val + 16, yi, str(val), va="center", fontsize=5.5, color=COLORS["muted"])
clean_axis(ax1)
ax1.text(
    1280,
    0.15,
    "2162 events / 47 sessions\n= 46.0 per session",
    ha="right",
    va="bottom",
    fontsize=5.45,
    color=COLORS["muted"],
    bbox=dict(facecolor="white", edgecolor="none", alpha=0.86, pad=1.2),
    linespacing=0.9,
)

ax2 = fig.add_subplot(gs[1, 1])
fig1_panel_title(ax2, "C. Events throughout phases")
phases = [p[0] for p in PHASE_TOTALS]
x = np.arange(len(phases))
bottom = np.zeros(len(phases))
for group, color in GROUP_COLORS.items():
    vals = [PHASE_GROUPS[p].get(group, 0) for p in phases]
    ax2.bar(x, vals, bottom=bottom, color=color, width=0.68, label=group)
    bottom += vals
ax2.set_xticks(x, phases, rotation=35, ha="right")
ax2.tick_params(axis="x", labelsize=6.0)
ax2.tick_params(axis="y", labelsize=6.0)
ax2.set_ylabel("events", fontsize=AXIS_LABEL_FS)
ax2.set_ylim(0, 1320)
for xi, total in zip(x, bottom):
    ax2.text(xi, total + 28, f"{int(total)}", ha="center", fontsize=5.8, color=COLORS["muted"])
clean_axis(ax2)
handles = [Patch(color=c, label=g) for g, c in GROUP_COLORS.items()]
ax2.legend(handles=handles, loc="upper right", frameon=False, fontsize=5.5, handlelength=0.8)

FIG_DIR.mkdir(parents=True, exist_ok=True)
for suffix in ("png", "pdf"):
    fig.savefig(
        FIG_DIR / f"fig1_pipeline_literature.{suffix}",
        dpi=300,
        bbox_inches="tight",
        pad_inches=0.008,
        transparent=False,
    )
