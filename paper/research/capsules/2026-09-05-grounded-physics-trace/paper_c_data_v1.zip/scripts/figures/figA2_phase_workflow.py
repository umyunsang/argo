"""figA2 — per-phase prompt-mandated workflow (canonical run_002 pipeline).

Landscape layout, 7 columns running left to right:

  CONCEIVE | PILOT setup (S1,S2) | PILOT iterate (S3, gate, reflect, reflect_II)
  | PRE-PROD | PRODUCTION (init, continue) | WRITING (1A, 1B, full) | POLISH

  - Within each column, task cards stack vertically.
  - Within each card, prompt-mandated workflow steps stack VERTICALLY,
    one per row, with adjacent step boxes touching (no gap),
    uniform vertical height across the whole figure.
  - Cross-column progression arrows between column headers.
  - Iteration arrows (gate <-> reflect cycle 1; gate <-> reflect_II cycle 2;
    prod_init <-> continue x3) intra-column.
  - Three-fold writing parallelism (1A/1B/full each x3) merges into Polish via
    fan-in arrows between WRITING and POLISH columns.

Source content: canonical run_002 prompts; see PHASE_WORKFLOW_ANALYSIS.md.
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

FIG_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(FIG_DIR))

from _paper_c_style import COLORS, apply_style, save_png_pdf  # noqa: E402

APPENDIX_DIR = FIG_DIR / "appendix"


# Phase color: (edge / dark, light fill)
PHASE_COLOR = {
    "conceive": (COLORS["blue"],       "#E6EFF8"),
    "pilot1":   (COLORS["orange"],     "#FCF1DC"),
    "pilot2":   (COLORS["orange"],     "#FCF1DC"),
    "preprod":  (COLORS["purple"],     "#F4E5ED"),
    "prod":     (COLORS["vermillion"], "#FBE8DD"),
    "writing":  ("#6F6F6F",            "#EDEDED"),
    "polish":   ("#6F6F6F",            "#EDEDED"),
}

PHASE_LABEL = {
    "conceive": "CONCEIVE",
    "pilot1":   "PILOT setup",
    "pilot2":   "PILOT iterate",
    "preprod":  "PRE-PROD",
    "prod":     "PRODUCTION",
    "writing":  "DRAFTS",
    "polish":   "POLISH",
}

# Each task: (name, n_sessions, [step_text, ...])
TASKS = {
    "conceive": [
        ("Breadth", 3, [
            "cat 11k titles",
            "cluster themes",
            "find gaps + bursts",
            "rank candidates",
        ]),
        ("Depth", 5, [
            "read all breadth",
            "generate 2-3 cands",
            "HW + SW gate (≤3x)",
            "deep lit + novelty",
            "finalize program",
        ]),
    ],
    "pilot1": [
        ("S1: prior work", 1, [
            "select best program",
            "30-80 prior works",
            "novelty recheck",
            "full-text 15 papers",
            "pick 3 repro targets",
        ]),
        ("S2: tooling", 1, [
            "build local venv",
            "install + tutorial",
            "benchmark parallel",
            "knowledge/<tool>.md",
            "central TOOL_REPORT",
        ]),
    ],
    "pilot2": [
        ("S3: reproduce", 5, [
            "cat full paper",
            "tooling assessment",
            "single-pt validate",
            "diagnose deviations",
            "verdict T1-T4",
        ]),
        ("Pilot gate", 15, [
            "scrutinize all priors",
            "pick ONE gap",
            "publ. ver. + SI",
            "param. comparison",
            "execute + APPEND",
        ]),
        ("Pilot reflect", 1, [
            "no calculations",
            "search lit per qty",
            "diagnose disagree.",
            "PASS / NOT PASS",
            "task list next gate",
        ]),
        ("Pilot reflect II", 1, [
            "physics-logic verb.",
            "fig-by-fig inventory",
            "raw-data critical",
            "gap analysis vs lit",
            "package next-gate",
        ]),
    ],
    "preprod": [
        ("Pre-production", 1, [
            "synthesize ALL pilot",
            "fresh lit survey",
            "design storyline + figs",
            "lock recipe per mat'l",
            "ordered task list",
            "convergence protocol",
        ]),
    ],
    "prod": [
        ("Prod. init", 1, [
            "read plan + lessons",
            "execute task list",
            "verify each step",
            "produce figs + converge",
            "open_questions log",
        ]),
        ("Prod. continue", 3, [
            "adversarial review",
            "data + phys. consist.",
            "logic chain complete?",
            "plan + execute fixes",
            "append (preserve)",
        ]),
    ],
    "writing": [
        ("Write 1A", 3, [
            "scan production data",
            "verbatim abstr. (35-45)",
            "≥3 adj. papers full",
            "fig-by-fig analysis",
            "positioning",
        ]),
        ("Write 1B", 3, [
            "verify raw numbers",
            "scrutinize error bars",
            "outline + fig dispo",
            "per-fig adversarial",
            "re-read after each",
        ]),
        ("Write full", 3, [
            "fetch PRB template",
            "test compile first",
            "draft tex (no defer)",
            "self-reflect ≥2x",
            "compile + visual fix",
        ]),
    ],
    "polish": [
        ("Polish", 1, [
            "cross-draft compare",
            "verdict + transplants",
            "regenerate ALL figs",
            "self-reflect ≥2x + SI",
            "verify each cite (40+)",
            "pre-pub checklist",
        ]),
    ],
}

PHASE_ORDER = ["conceive", "pilot1", "pilot2", "preprod", "prod", "writing", "polish"]


def arrow(ax, p1, p2, color, lw=0.8, rad=0.0, ms=7, alpha=1.0):
    a = FancyArrowPatch(p1, p2,
                        arrowstyle="-|>",
                        mutation_scale=ms,
                        linewidth=lw,
                        color=color,
                        connectionstyle=f"arc3,rad={rad}",
                        alpha=alpha,
                        shrinkA=0.5, shrinkB=0.5)
    ax.add_patch(a)
    return a


def main():
    apply_style()

    # --- figure size ---
    fig_w = 12.0
    fig_h = 8.5
    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # (No title or footnote inside the figure; LaTeX caption supplies them — see
    # figA2_caption.md.)

    # --- column geometry ---
    title_bar_h = 0.030
    gap_cards = 0.011
    header_h = 0.052
    body_y_top = 0.965    # closer to top now that title is removed
    body_y_bot = 0.020    # close to bottom now that footnote is removed
    body_h = body_y_top - body_y_bot

    # H_step = uniform step box height, set so the tallest column fits
    H_step_options = []
    for phase in PHASE_ORDER:
        n_cards = len(TASKS[phase])
        total_steps = sum(len(t[2]) for t in TASKS[phase])
        col_h_const = n_cards * title_bar_h + max(0, n_cards - 1) * gap_cards
        H_step = (body_h - col_h_const) / total_steps
        H_step_options.append(H_step)
    H_step = min(H_step_options) * 0.99   # tiny safety margin

    # --- column widths (axis units) ---
    # 7 columns, slim boxes. Custom gaps; larger gaps for arrow lanes.
    n_phases = len(PHASE_ORDER)
    col_w = 0.100     # explicit thin column width
    # uniform gaps so cross-phase arrows are equal length
    uniform_gap = 0.046
    gaps = [uniform_gap] * 6
    total_used = n_phases * col_w + sum(gaps)
    margin_x = (1.0 - total_used) / 2
    col_xs = {}
    cursor = margin_x
    for i, phase in enumerate(PHASE_ORDER):
        col_xs[phase] = cursor
        cursor += col_w
        if i < n_phases - 1:
            cursor += gaps[i]

    # --- phase headers (placed at very top now that no figure title exists) ---
    header_y_top = 0.992
    header_y_bot = header_y_top - header_h
    body_y_top = header_y_bot - 0.013   # reset body top below header
    body_h = body_y_top - body_y_bot
    # recompute H_step now that body_h has changed
    H_step_options = []
    for phase in PHASE_ORDER:
        n_cards = len(TASKS[phase])
        total_steps = sum(len(t[2]) for t in TASKS[phase])
        col_h_const = n_cards * title_bar_h + max(0, n_cards - 1) * gap_cards
        H_step_options.append((body_h - col_h_const) / total_steps)
    H_step = min(H_step_options) * 0.99
    for phase in PHASE_ORDER:
        x = col_xs[phase]
        ec, light = PHASE_COLOR[phase]
        ax.add_patch(FancyBboxPatch((x, header_y_bot), col_w, header_h,
                                    boxstyle="round,pad=0.002,rounding_size=0.008",
                                    facecolor=ec, edgecolor=ec, linewidth=0))
        # If label is long, smaller font
        label = PHASE_LABEL[phase]
        fs = 8.5 if len(label) > 9 else 10.0
        ax.text(x + col_w / 2, (header_y_top + header_y_bot) / 2, label,
                ha="center", va="center", fontsize=fs, color="white", fontweight="bold")

    # --- cross-phase progression arrows between headers (uniform style) ---
    for i in range(n_phases - 1):
        p1 = PHASE_ORDER[i]
        p2 = PHASE_ORDER[i + 1]
        x_end = col_xs[p1] + col_w
        x_start = col_xs[p2]
        y = (header_y_top + header_y_bot) / 2
        arrow(ax, (x_end + 0.0008, y), (x_start - 0.0008, y),
              "#7C7C7C", lw=1.5, ms=10)

    # --- column body very-light tint ---
    for phase in PHASE_ORDER:
        x = col_xs[phase]
        _, light = PHASE_COLOR[phase]
        # 30% lighter for tint
        ax.add_patch(Rectangle((x, body_y_bot - 0.005),
                               col_w, header_y_bot - body_y_bot + 0.001,
                               facecolor=light, edgecolor="none", alpha=0.30, zorder=0))

    # --- per column: stack task cards ---
    card_geom = {}  # phase -> { task_name : (x, y_top, w, h, step_y_centers) }
    for phase in PHASE_ORDER:
        x = col_xs[phase]
        ec, fill = PHASE_COLOR[phase]
        cards = {}
        y_top = body_y_top
        for tname, n_sess, steps in TASKS[phase]:
            n_steps = len(steps)
            card_h = title_bar_h + n_steps * H_step
            # outer card frame
            ax.add_patch(FancyBboxPatch((x, y_top - card_h),
                                        col_w, card_h,
                                        boxstyle="round,pad=0.001,rounding_size=0.005",
                                        facecolor="white",
                                        edgecolor=ec, linewidth=0.9, zorder=2))
            # title bar (solid edge color)
            ax.add_patch(Rectangle((x, y_top - title_bar_h),
                                   col_w, title_bar_h,
                                   facecolor=ec, edgecolor="none", zorder=3))
            # task name
            ax.text(x + 0.004, y_top - title_bar_h / 2, tname,
                    ha="left", va="center",
                    fontsize=7.5, color="white", fontweight="bold", zorder=4)
            # session count
            sess_text = f"x{n_sess}"
            ax.text(x + col_w - 0.004, y_top - title_bar_h / 2, sess_text,
                    ha="right", va="center",
                    fontsize=6.6, color="white", fontweight="bold", zorder=4)

            # step boxes stacked vertically, NO gap between them
            step_y_top = y_top - title_bar_h
            step_centers = []
            for k, step in enumerate(steps):
                box_y_top = step_y_top - k * H_step
                box_y_bot = box_y_top - H_step
                # alternate fill subtly
                fc = fill if k % 2 == 0 else "#FFFFFF"
                # box
                ax.add_patch(Rectangle((x, box_y_bot), col_w, H_step,
                                       facecolor=fc, edgecolor=ec,
                                       linewidth=0.55, zorder=2))
                # number circle on left
                num_x = x + 0.013
                ax.text(num_x, (box_y_top + box_y_bot) / 2, str(k + 1),
                        ha="center", va="center",
                        fontsize=7.1, color=ec, fontweight="bold", zorder=4,
                        bbox=dict(boxstyle="circle,pad=0.18",
                                  facecolor="white", edgecolor=ec, linewidth=0.7))
                # step text
                ax.text(x + 0.024, (box_y_top + box_y_bot) / 2, step,
                        ha="left", va="center",
                        fontsize=6.0, color=COLORS["text"], zorder=4,
                        linespacing=1.0)
                step_centers.append((box_y_top + box_y_bot) / 2)

            cards[tname] = (x, y_top, col_w, card_h, step_centers)
            y_top -= card_h + gap_cards
        card_geom[phase] = cards

    # ---- iteration arrows (intra-column) ----

    # cycle 1: pilot gate <-> pilot reflect, both inside pilot2 column
    pilot2 = card_geom["pilot2"]
    gate = pilot2["Pilot gate"]
    reflect = pilot2["Pilot reflect"]
    reflect_II = pilot2["Pilot reflect II"]
    pilot2_x_left = col_xs["pilot2"]
    pilot2_x_right = col_xs["pilot2"] + col_w
    pilot_ec = PHASE_COLOR["pilot2"][0]

    gate_y_mid = gate[1] - gate[3] / 2
    reflect_y_mid = reflect[1] - reflect[3] / 2
    reflect_II_y_mid = reflect_II[1] - reflect_II[3] / 2

    # ---- cycle 1: gate <-> reflect on RIGHT of pilot2 column ----
    # Bidirectional curve spanning gate-top-right to reflect-bottom-right.
    # Arrowheads at both ends point INTO their cards.
    from matplotlib.patches import FancyArrowPatch as _FAP

    cyc1_x_attach = pilot2_x_right + 0.001
    gate_top_y = gate[1]
    gate_bot_y = gate[1] - gate[3]
    reflect_top_y = reflect[1]
    reflect_bot_y = reflect[1] - reflect[3]
    bidir1 = _FAP(
        (cyc1_x_attach, gate_top_y + 0.004),       # just OUTSIDE top edge of gate
        (cyc1_x_attach, reflect_bot_y - 0.004),    # just OUTSIDE bottom edge of reflect
        arrowstyle="<|-|>",
        mutation_scale=11,
        linewidth=1.7,
        color=pilot_ec,
        connectionstyle="arc3,rad=-0.20",   # negative -> bulges RIGHT (outward into gap)
        alpha=0.98,
        zorder=10,
    )
    ax.add_patch(bidir1)
    # cycle 1 label inside the loop's bulge (further right)
    ax.text(cyc1_x_attach + 0.038, (gate_top_y + reflect_bot_y) / 2,
            "cycle 1", fontsize=6.8, color=pilot_ec, fontweight="bold",
            ha="center", va="center", rotation=90, zorder=11,
            bbox=dict(facecolor="white", edgecolor="none", pad=0.4))

    # ---- cycle 2: gate <-> reflect_II on LEFT of pilot2 column (longer span) ----
    cyc2_x_attach = pilot2_x_left - 0.001
    reflect_II_top_y = reflect_II[1]
    reflect_II_bot_y = reflect_II[1] - reflect_II[3]
    bidir2 = _FAP(
        (cyc2_x_attach, gate_top_y + 0.004),
        (cyc2_x_attach, reflect_II_bot_y - 0.004),
        arrowstyle="<|-|>",
        mutation_scale=11,
        linewidth=1.6,
        color=COLORS["vermillion"],
        connectionstyle="arc3,rad=0.13",   # positive -> bulges LEFT (outward into gap)
        alpha=0.95,
        zorder=10,
    )
    ax.add_patch(bidir2)
    ax.text(cyc2_x_attach - 0.038, (gate_top_y + reflect_II_bot_y) / 2,
            "cycle 2", fontsize=6.8, color=COLORS["vermillion"], fontweight="bold",
            ha="center", va="center", rotation=90, zorder=11,
            bbox=dict(facecolor="white", edgecolor="none", pad=0.4))

    # production cycle (init <-> continue)
    prod = card_geom["prod"]
    prod_init = prod["Prod. init"]
    prod_cont = prod["Prod. continue"]
    prod_ec = PHASE_COLOR["prod"][0]
    prod_x_right = col_xs["prod"] + col_w
    prod_init_y_mid = prod_init[1] - prod_init[3] / 2
    prod_cont_y_mid = prod_cont[1] - prod_cont[3] / 2
    # production cycle: bidirectional curved arrow on right of PRODUCTION column
    cyc_p_attach = prod_x_right + 0.001
    prod_init_top_y = prod_init[1]
    prod_init_bot_y = prod_init[1] - prod_init[3]
    prod_cont_top_y = prod_cont[1]
    prod_cont_bot_y = prod_cont[1] - prod_cont[3]
    bidir_p = _FAP(
        (cyc_p_attach, prod_init_top_y + 0.004),
        (cyc_p_attach, prod_cont_bot_y - 0.004),
        arrowstyle="<|-|>",
        mutation_scale=11,
        linewidth=1.7,
        color=prod_ec,
        connectionstyle="arc3,rad=-0.20",   # negative -> bulges RIGHT (outward into gap)
        alpha=0.98,
        zorder=10,
    )
    ax.add_patch(bidir_p)
    ax.text(cyc_p_attach + 0.038, (prod_init_top_y + prod_cont_bot_y) / 2,
            "x3 adversarial",
            fontsize=6.6, color=prod_ec, fontweight="bold",
            ha="center", va="center", rotation=90, zorder=11,
            bbox=dict(facecolor="white", edgecolor="none", pad=0.4))

    # ---- writing parallelism: fan-in to Polish ----
    # Each Write card shows "x3" in its title bar (n_sess); no external markers.
    # Fan-in arrows from each writing-card right side to Polish-card left center.
    writing = card_geom["writing"]
    polish_card = card_geom["polish"]["Polish"]
    grey = "#6F6F6F"

    polish_x = polish_card[0]
    polish_top = polish_card[1]
    polish_y_mid = polish_top - polish_card[3] / 2

    writing_right_x = col_xs["writing"] + col_w
    for nm in ["Write 1A", "Write 1B", "Write full"]:
        wc = writing[nm]
        wc_y_mid = wc[1] - wc[3] / 2
        arrow(ax, (writing_right_x + 0.001, wc_y_mid),
              (polish_x - 0.001, polish_y_mid),
              grey, lw=1.0, ms=7, alpha=0.78, rad=-0.15)

    # 3->1 label centered in the gap, vertically between top writing card and polish.
    fan_label_x = (writing_right_x + polish_x) / 2
    # vertical mid of the writing card stack
    write_top_y = writing["Write 1A"][1]
    write_bot_y = writing["Write full"][1] - writing["Write full"][3]
    fan_label_y = (write_top_y + write_bot_y) / 2
    ax.text(fan_label_x, fan_label_y, "3->1",
            fontsize=6.4, color=grey, fontweight="bold",
            ha="center", va="center", rotation=90,
            bbox=dict(facecolor="white", edgecolor=grey, linewidth=0.6,
                      boxstyle="round,pad=0.18"))

    # No footer caption inside the figure (see figA2_caption.md for LaTeX caption).

    save_png_pdf(fig, "figA2_phase_workflow", APPENDIX_DIR)
    plt.close(fig)
    print(f"Wrote figA2 (7-col landscape) to {APPENDIX_DIR}, "
          f"fig {fig_w} x {fig_h} in, H_step={H_step:.4f}, col_w={col_w:.4f}")


if __name__ == "__main__":
    main()
