from __future__ import annotations

import csv
import math
from pathlib import Path


RUN_ROOT = Path(__file__).resolve().parents[3]
OUT_DIR = Path(__file__).resolve().parent
STAGE_SUMMARY = RUN_ROOT / "analysis" / "info_flow_data" / "per_stage_summary.csv"
OUT_CSV = OUT_DIR / "pilot_anchor_data.csv"


def load_session_dates() -> dict[str, str]:
    label_to_id = {
        "session_2_tooling": "S2",
        "session_3_reproduce_01": "S3-01",
        "session_3_reproduce_02": "S3-02",
        "session_3_reproduce_03": "S3-03",
        "session_3_reproduce_04": "S3-04",
        "session_3_reproduce_05": "S3-05",
        **{f"pilot_gate_{i:02d}": f"pg{i:02d}" for i in range(1, 16)},
        "pilot_reflect_01": "reflect_01",
        "pilot_reflect_II_02": "reflect_II_02",
    }
    dates: dict[str, str] = {}
    if not STAGE_SUMMARY.exists():
        return dates
    with STAGE_SUMMARY.open(newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            sid = label_to_id.get(row["session_label"])
            if not sid:
                continue
            ts = row.get("first_timestamp", "")
            dates[sid] = ts[:10] if ts else ""
    return dates


def ratio(published: float | None, pipeline: float | None) -> float | None:
    if published is None or pipeline is None or published == 0:
        return None
    return abs(pipeline) / abs(published)


def row(
    session_id: str,
    target: str,
    quantity: str,
    units: str,
    published_value: float | None,
    pipeline_value: float | None,
    t_tier_assigned: str,
    t_tier_threshold: str,
    disposition: str,
    comparison_type: str,
    notes: str,
    source_file: str,
    published_uncertainty: str = "",
    pipeline_uncertainty: str = "",
):
    r = ratio(published_value, pipeline_value)
    return {
        "session_id": session_id,
        "session_date": "",
        "reproduction_target": target,
        "quantity": quantity,
        "units": units,
        "published_value": "" if published_value is None else f"{published_value:.8g}",
        "published_uncertainty": published_uncertainty,
        "pipeline_value": "" if pipeline_value is None else f"{pipeline_value:.8g}",
        "pipeline_uncertainty": pipeline_uncertainty,
        "ratio": "" if r is None or math.isnan(r) else f"{r:.6g}",
        "t_tier_assigned": t_tier_assigned,
        "t_tier_threshold": t_tier_threshold,
        "disposition": disposition,
        "comparison_type": comparison_type,
        "notes": notes,
        "source_file": source_file,
    }


ROWS = [
    row(
        "S2",
        "Fe BCC AHC tool validation (Yao 2004)",
        "|sigma_xy|",
        "S/cm",
        751,
        718,
        "tool validation",
        "magnitude within literature tolerance; report quotes 4.4% magnitude error",
        "PASS",
        "tooling",
        "Session-2 WannierBerri tool validation, retained in CSV but excluded from proposal dots by default.",
        "pilot/session_2_tooling/knowledge/TOOL_REPORT.md",
    ),
    row(
        "S3-01",
        "Smolenski MnTe ground-state moment",
        "mu_Mn",
        "mu_B/Mn",
        4.6,
        4.47,
        "T3",
        "qualitative match with offsets; moment within about 2-3% of literature range",
        "PASS",
        "convergence",
        "Literature value is a representative midpoint of the report's 4.5-4.7 mu_B range.",
        "pilot/session_3_reproduce_01/reproduction_report.md",
        "range 4.5-4.7",
    ),
    row(
        "S3-02",
        "Gonzalez Betancourt MnTe deep-valence AHE",
        "sigma_xy(VBM-1 eV)",
        "S/cm",
        300,
        450,
        "T3",
        "paper says above 300 S/cm; qualitative deep-VB match",
        "PASS",
        "convergence",
        "Ratio uses 300 S/cm as a lower-bound reference; sign depends on chirality convention.",
        "pilot/session_3_reproduce_02/reproduction_report.md",
        "lower bound",
    ),
    row(
        "S3-02",
        "Gonzalez Betancourt MnTe near-VBM AHE",
        "sigma_xy(VBM-20 meV)",
        "S/cm",
        1,
        -46,
        "T3",
        "factor-2 near-VBM target not met; mesh-limited",
        "FAIL",
        "caveated",
        "Near-VBM value depends on broadening and mesh; report gives -35 to -46 S/cm.",
        "pilot/session_3_reproduce_02/reproduction_report.md",
        "visual estimate",
        "range -35 to -46",
    ),
    row(
        "S3-03",
        "Guo-Liu CsV2Te2O relaxed lattice",
        "a0",
        "angstrom",
        4.087,
        4.083,
        "T4",
        "lattice within 1%",
        "PASS",
        "convergence",
        "PBE lattice reproduced to 0.10%.",
        "pilot/session_3_reproduce_03/reproduction_report.md",
    ),
    row(
        "S3-03",
        "Guo-Liu CsV2Te2O strain magnetization",
        "|M(C-type, epsilon=-1%)|",
        "mu_B/cell",
        0.10,
        0.08,
        "T4",
        "magnetization within 30%",
        "PASS",
        "convergence",
        "Central apparent-AM strain response anchor.",
        "pilot/session_3_reproduce_03/reproduction_report.md",
    ),
    row(
        "S3-04",
        "Huyen Mn3NiN Q11 prime",
        "Q'_11",
        "G/MPa",
        0.051,
        0.00292,
        "T2",
        "T4 would be within 20%; report remains partial",
        "FAIL",
        "caveated",
        "Later reflection identifies Huyen as an outlier/internally inconsistent relative to Zemen.",
        "pilot/session_3_reproduce_04/reproduction_report.md",
    ),
    row(
        "S3-05",
        "Ohlendorf/Moriya MnF2 piezomagnetic lambda",
        "lambda(J=1, x=0.005 holes)",
        "dimensionless",
        0.246,
        0.264,
        "T4 after reflect",
        "reflection uses experiment/Table-1 anchor; within 7%",
        "PASS",
        "convergence",
        "The original Ohlendorf DFT figure is larger; reflect_01 switches to the experimental anchor.",
        "pilot/session_3_reproduce_05/reproduction_report.md; pilot/pilot_reflect_01/reflect_report.md",
    ),
    row(
        "pg01",
        "Lopez 2012 Fe BCC orbital magnetization",
        "|m_orb|",
        "mu_B/atom",
        0.0760,
        0.0719,
        "T4",
        "within +/-20%",
        "PASS",
        "convergence",
        "Canonical Fe orbital-magnetization validation.",
        "pilot/pilot_gate_01/pilot_gate_report.md",
    ),
    row(
        "pg02",
        "Huyen Mn3NiN Q11 prime retry",
        "Q'_11",
        "G/MPa",
        0.051,
        0.0032,
        "not T4",
        "target range 0.041-0.061 G/MPa",
        "FAIL",
        "caveated",
        "All four configurations clustered near 0.0032; later reflect recasts this as outlier gap.",
        "pilot/pilot_gate_02/pilot_gate_report.md",
    ),
    row(
        "pg03",
        "Huyen Mn3NiN direct biaxial moment",
        "|M_total|(0.2% biaxial)",
        "mu_B/cell",
        0.024,
        0.01138,
        "T3",
        "T4 [0.019,0.029]; T3 factor-2 [0.012,0.040]",
        "caveat",
        "caveated",
        "Just outside the report's T3 lower edge by direct Huyen comparison; reflect_01 shows Zemen extrapolation 0.010 matches.",
        "pilot/pilot_gate_03/pilot_gate_report.md; pilot/pilot_reflect_01/reflect_report.md",
    ),
    row(
        "pg04",
        "Ye 2026 MnTe orbital magnetization first attempt",
        "|M_orb_z|",
        "mu_B/cell",
        0.1764,
        0.4286,
        "retracted LOW",
        "direct Ye anchor; 2.4x too high",
        "FAIL",
        "caveated",
        "pilot_gate_04 composite HIGH was retracted when reflect_01 located Ye's direct benchmark.",
        "pilot/pilot_gate_04/pilot_gate_report.md; pilot/pilot_reflect_01/reflect_report.md",
    ),
    row(
        "pg05",
        "Ye 2026 MnTe m_orb after U+J switch",
        "|M_orb_z|",
        "mu_B/cell",
        0.1764,
        0.2377,
        "T3",
        "T4 target [0.141,0.211]; within factor-2 T3",
        "FAIL",
        "caveated",
        "Single-dfroz point later shown by pg06/pg07 to sit on a sensitive curve.",
        "pilot/pilot_gate_05/pilot_gate_report.md",
    ),
    row(
        "pg07",
        "Ye 2026 MnTe m_orb 12x12x8 plateau",
        "|M_orb_z|",
        "mu_B/cell",
        0.1764,
        0.1923,
        "T4",
        "within +/-20%; plateau dfroz 13.05-13.15",
        "PASS",
        "convergence",
        "Central 12x12x8 plateau point; report also quotes M_z=0.190+/-0.002.",
        "pilot/pilot_gate_07/pilot_gate_report.md",
        "",
        "plateau std about 0.002",
    ),
    row(
        "pg07",
        "Ye 2026 MnTe m_orb denser k-mesh",
        "|M_orb_z| at 16x16x10",
        "mu_B/cell",
        0.1764,
        0.3245,
        "T3/T2 fail",
        "no tested 16x16x10 configuration entered T4",
        "FAIL",
        "caveated",
        "Denser mesh moved away from Ye, exposing O(2x) systematic.",
        "pilot/pilot_gate_07/pilot_gate_report.md",
    ),
    row(
        "pg08",
        "Ye 2026 MnTe 36-WF basis extension",
        "|M_orb_z|",
        "mu_B/cell",
        0.1764,
        0.0024,
        "T2 FAIL",
        "basis extension must enter T4 at both meshes",
        "FAIL",
        "falsification",
        "36-WF Mn:s,d+Te:p basis drove M_z to near zero and falsified the extension hypothesis.",
        "pilot/pilot_gate_08/pilot_gate_report.md",
    ),
    row(
        "pg09",
        "Thapa KV2Se2O C-vs-G energy",
        "E(C)-E(G)",
        "meV/cell",
        4.43,
        3.745,
        "T4",
        "sign correct and magnitude within factor 2 / about 15-20%",
        "PASS",
        "convergence",
        "Resolved bulk KV2Se2O as G-type hidden altermagnet; production reframed.",
        "pilot/pilot_gate_09/pilot_gate_report.md",
    ),
    row(
        "pg11",
        "Ye 2026 MnTe locked strain-protocol baseline",
        "M_orb_z(epsilon=0)",
        "mu_B/cell",
        0.1764,
        0.19237,
        "T4 with caveat",
        "within +/-20%; inherits pg07 k-mesh caveat",
        "caveat",
        "caveated",
        "Production strain protocol uses matched gauges; absolute M_z still carries pg07/pg08 systematic.",
        "pilot/pilot_gate_11/pilot_gate_report.md",
    ),
    row(
        "pg12",
        "Yu 2025 CrSb canted-L AHC",
        "sigma_xz(E_F)",
        "S/cm",
        72,
        52.87,
        "T4",
        "factor-2 target [36,144]",
        "PASS",
        "convergence",
        "Primary CrSb pipeline anchor; forbidden sigma_yz also zero.",
        "pilot/pilot_gate_12/pilot_gate_report.md",
    ),
    row(
        "pg12",
        "Yu 2025 CrSb secondary AHC sign",
        "sigma_xy(E_F)",
        "S/cm",
        -50,
        113.99,
        "T2/open",
        "secondary observable; sign opposite and magnitude 2.3x",
        "FAIL",
        "caveated",
        "Visual literature estimate; sign discrepancy documented as open.",
        "pilot/pilot_gate_12/pilot_gate_report.md",
        "visual estimate",
    ),
    row(
        "pg13",
        "Khodas-Mu-Mazin MnTe spin piezomagnetism",
        "|Lambda_spin_31|",
        "mu_B/cell per unit strain",
        0.76,
        0.40,
        "factor-2",
        "within factor 2 after unit correction; chirality sign opposite",
        "caveat",
        "caveated",
        "pg13 corrects pg11's unit comparison; values are not the same strain protocol.",
        "pilot/pilot_gate_13/pilot_gate_report.md",
    ),
]


def main() -> None:
    dates = load_session_dates()
    rows = []
    for r in ROWS:
        r = dict(r)
        r["session_date"] = dates.get(r["session_id"], "")
        rows.append(r)

    fieldnames = [
        "session_id",
        "session_date",
        "reproduction_target",
        "quantity",
        "units",
        "published_value",
        "published_uncertainty",
        "pipeline_value",
        "pipeline_uncertainty",
        "ratio",
        "t_tier_assigned",
        "t_tier_threshold",
        "disposition",
        "comparison_type",
        "notes",
        "source_file",
    ]
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with OUT_CSV.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"wrote {len(rows)} rows to {OUT_CSV}")


if __name__ == "__main__":
    main()
