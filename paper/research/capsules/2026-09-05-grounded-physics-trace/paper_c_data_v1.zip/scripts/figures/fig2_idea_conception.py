"""Fig 2 — Idea conception: information flow from corpus to depth programs.

Final publication build.

Structure (top to bottom):
  - 5 depth-program landing boxes
  - external (novelty audit) band
  - breadth_01 / breadth_02 / breadth_03 bands (each 7-month corpus span)
  - corpus paper-count histogram strip (13 bins, ~14 days each)
  - 12 category labels with $n=$ annotation
  - legend strip

x  : 12 regex-classified themes (depth-active first, then breadth-active)
y  : continuous submission month
     - within breadth bands: Oct'25 → Apr'26
     - within external band: Jun'23 → Apr'26 (depth pulled older novelty audit)
     - within histogram strip: Oct'25 → Apr'26
"""
from __future__ import annotations

import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch, Rectangle
from matplotlib.path import Path as MplPath
from matplotlib.patches import PathPatch

THIS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(THIS_DIR / "fig2_brainstorm"))

from _fig2_data4 import (
    CATEGORIES_V3, CATEGORY_TO_IDX, COLORS,
    DEPTH_COLORS, DEPTH_PROGRAMS, FIG_DIR,
    PAPER_RECORDS_V3,
    apply_style, continuous_month, save_png_pdf, theme_idx_for_aid,
    get_v4_ids, is_cited, get_corpus_histogram_binned,
)


N_HIST_BINS = 13


# === Style overrides — bigger fonts ===
apply_style()
import matplotlib as mpl
mpl.rcParams.update({
    "font.size": 9,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
})

# === Figure (full-page-width, comfortably tall) ===
fig = plt.figure(figsize=(11.0, 6.8))
ax = fig.add_axes([0.0, 0.0, 1.0, 1.0])
ax.set_axis_off()
# Restrict the axes range to the actual content extent (legend at the very
# bottom, pilot-selected annotation at the top) — this removes the 12-15% of
# blank space at the bottom of v2 and the small headspace above the depth
# boxes, so the LaTeX caption can sit immediately under the figure.
ax.set_xlim(0.0, 1.0)
ax.set_ylim(0.075, 1.015)


# === Layout constants ===
n_cats = len(CATEGORIES_V3)
THEMES_X = np.linspace(0.155, 0.880, n_cats)
COLUMN_PITCH = THEMES_X[1] - THEMES_X[0]

BAND_KEYS = ["web", "b01", "b02", "b03"]
BAND_LABEL = {
    "web": "external\n(novelty audit)",
    "b01": "breadth$_{01}$",
    "b02": "breadth$_{02}$",
    "b03": "breadth$_{03}$",
}
BAND_COLOR = {
    "web": COLORS["orange"],
    "b01": COLORS["blue"],
    "b02": COLORS["sky"],
    "b03": COLORS["green"],
}

# Vertical layout — packed to minimize wasted space
DEPTH_BOX_H = 0.115
DEPTH_Y_TOP = 0.92
DEPTH_BOX_BOTTOM = DEPTH_Y_TOP - DEPTH_BOX_H / 2

# Gap between depth boxes and external band (1.5x of v2's 0.06 = 0.09)
GAP_DEPTH_TO_BANDS = 0.09
BAND_TOP = DEPTH_BOX_BOTTOM - GAP_DEPTH_TO_BANDS

BAND_HEIGHT = 0.098
BAND_GAP = 0.018
BAND_Y = {}
y = BAND_TOP
for k in BAND_KEYS:
    BAND_Y[k] = y
    y -= (BAND_HEIGHT + BAND_GAP)
BAND_BOT = {k: BAND_Y[k] - BAND_HEIGHT for k in BAND_KEYS}

# Histogram band below b03
HIST_GAP = 0.012
HIST_HEIGHT = 0.090
HIST_Y_TOP = BAND_BOT["b03"] - HIST_GAP
HIST_Y_BOT = HIST_Y_TOP - HIST_HEIGHT


# === Draw breadth bands ===
for k in BAND_KEYS:
    color = BAND_COLOR[k]
    y_lo = BAND_BOT[k]
    ax.add_patch(Rectangle((0.115, y_lo), 0.770, BAND_HEIGHT,
                           facecolor=color, edgecolor="none", alpha=0.10))
    ax.text(0.110, y_lo + BAND_HEIGHT / 2, BAND_LABEL[k],
            ha="right", va="center", fontsize=9.0,
            color=color, fontweight="bold", linespacing=1.05)

# Histogram band background
ax.add_patch(Rectangle((0.115, HIST_Y_BOT), 0.770, HIST_HEIGHT,
                       facecolor=COLORS["light"], edgecolor="none", alpha=0.55))
ax.text(0.110, HIST_Y_BOT + HIST_HEIGHT / 2, "corpus\npaper count",
        ha="right", va="center", fontsize=8.0,
        color=COLORS["text"], fontweight="bold", linespacing=1.05)


# === Theme columns (full vertical guides) + category labels at bottom ===
y_top_overall = BAND_Y["web"]
y_bot_overall = HIST_Y_BOT
LABELS_Y = HIST_Y_BOT - 0.020
LABELS_N_Y = HIST_Y_BOT - 0.040
for ti, (cat_name, n_corpus, n_breadth, n_depth, label) in enumerate(CATEGORIES_V3):
    x = THEMES_X[ti]
    ax.plot([x, x], [y_bot_overall, y_top_overall],
            color=COLORS["grid"], lw=0.45, ls=":", alpha=0.55, zorder=1)
    ax.text(x, LABELS_Y, label,
            ha="center", fontsize=8.4, color=COLORS["text"], fontweight="bold")
    ax.text(x, LABELS_N_Y, f"$n=${n_corpus:,}",
            ha="center", fontsize=7.2, color=COLORS["muted"])
    # (depth-cited theme marker removed — redundant with the lineage arcs;
    #  arcs to depth boxes already mark the depth-active categories.)


# === Position rules ===
def x_for_aid(aid, theme_idx):
    base = THEMES_X[theme_idx]
    off = ((hash(aid) % 1000) / 1000.0 - 0.5) * 0.052
    return float(np.clip(base + off, 0.118, 0.882))


def y_for_month_in_band(month_value, band_key):
    y_lo = BAND_BOT[band_key]
    PAD = 0.004
    if band_key == "web":
        m_min, m_max = -18.0, 16.5      # Jun'23..Apr'26
    else:
        m_min, m_max = 10.0, 16.5       # Oct'25..Apr'26
    frac = (month_value - m_min) / (m_max - m_min)
    frac = max(0.0, min(1.0, frac))
    return y_lo + PAD + frac * (BAND_HEIGHT - 2 * PAD)


def y_for_month_in_hist(month_value):
    PAD = 0.004
    m_min, m_max = 10.0, 16.5
    frac = (month_value - m_min) / (m_max - m_min)
    frac = max(0.0, min(1.0, frac))
    return HIST_Y_BOT + PAD + frac * (HIST_HEIGHT - 2 * PAD)


# === Plot dots: cited (filled big) vs accessed-only (small faint) ===
for band in ["b01", "b02", "b03"]:
    ids = get_v4_ids(band)
    color = BAND_COLOR[band]
    for aid in ids:
        ti = theme_idx_for_aid(aid)
        if ti is None:
            continue
        x = x_for_aid(aid, ti)
        m = continuous_month(aid)
        y = y_for_month_in_band(m, band)
        cited = is_cited(aid, band)
        if cited:
            ax.scatter([x], [y], s=12, color=color, alpha=0.95,
                       edgecolor="white", lw=0.45, zorder=3)
        else:
            ax.scatter([x], [y], s=3.2, color=color, alpha=0.34,
                       edgecolor="none", zorder=2)

# Web band
for aid in get_v4_ids("web"):
    ti = theme_idx_for_aid(aid)
    if ti is None:
        ti = CATEGORY_TO_IDX["altermagnetism"]
    x = x_for_aid(aid, ti)
    m = continuous_month(aid)
    y = y_for_month_in_band(m, "web")
    cited = is_cited(aid, "web")
    if cited:
        ax.scatter([x], [y], s=18, color=BAND_COLOR["web"],
                   edgecolor="white", lw=0.45, zorder=4, marker="s", alpha=0.95)
    else:
        ax.scatter([x], [y], s=5, color=BAND_COLOR["web"],
                   alpha=0.42, zorder=2, marker="s", edgecolor="none")


# === Highlight curated lineage papers ===
PINNED_POS = {}
for rec in PAPER_RECORDS_V3:
    aid, title, theme_idx, bset, dtargets, in_all3 = rec
    if theme_idx is None:
        continue
    m = continuous_month(aid)
    x = x_for_aid(aid, theme_idx)
    if bset:
        for bk in bset:
            y = y_for_month_in_band(m, bk)
            PINNED_POS[(bk, aid)] = (x, y)
            color = BAND_COLOR[bk]
            if in_all3:
                ax.scatter([x], [y], s=32, color=COLORS["text"],
                           edgecolor="white", lw=0.5, zorder=5)
            elif len(bset) == 2:
                ax.scatter([x], [y], s=18, facecolor="white",
                           edgecolor=color, lw=1.0, zorder=5)
            else:
                ax.scatter([x], [y], s=24, color=color,
                           edgecolor="white", lw=0.45, zorder=5)
    else:
        y = y_for_month_in_band(m, "web")
        PINNED_POS[("web", aid)] = (x, y)


# === Histogram band — 13 bins, absolute scale ===
global_max = max(
    c[1] for cat_name, *_ in CATEGORIES_V3
    for c in get_corpus_histogram_binned(cat_name, N_HIST_BINS)
) or 1
for ti, (cat_name, *_rest) in enumerate(CATEGORIES_V3):
    x_center = THEMES_X[ti]
    hist = get_corpus_histogram_binned(cat_name, N_HIST_BINS)
    max_half_width = COLUMN_PITCH * 0.42
    scale = max_half_width / global_max

    bin_height = (HIST_HEIGHT - 2 * 0.004) / N_HIST_BINS
    for i, (m_center, count) in enumerate(hist):
        y_bot = HIST_Y_BOT + 0.004 + i * bin_height
        y_top = y_bot + bin_height
        half = count * scale
        if half < 1e-5:
            continue
        ax.add_patch(Rectangle((x_center - half, y_bot),
                               2 * half, y_top - y_bot,
                               facecolor=COLORS["text"],
                               edgecolor="none", alpha=0.62))


# === Time-axis ticks on RIGHT side ===
TIME_LABEL_X = 0.905
TIME_TICK_X0 = 0.890
TIME_TICK_X1 = 0.898
BREADTH_MONTH_TICKS = [
    (10, "Oct '25"), (11, "Nov"), (12, "Dec"),
    (13, "Jan '26"), (14, "Feb"), (15, "Mar"), (16, "Apr"),
]
WEB_MONTH_TICKS = [
    (-18, "Jun '23"), (-12, "Jan '24"),
    (-6, "Jul '24"), (1, "Jan '25"),
    (10, "Oct '25"), (16, "Apr '26"),
]

for bk in BAND_KEYS:
    ticks = WEB_MONTH_TICKS if bk == "web" else BREADTH_MONTH_TICKS
    for m, label in ticks:
        y_t = y_for_month_in_band(m, bk)
        ax.plot([TIME_TICK_X0, TIME_TICK_X1], [y_t, y_t],
                color=COLORS["muted"], lw=0.6, alpha=0.85)
        ax.text(TIME_LABEL_X, y_t, label, ha="left", va="center",
                fontsize=6.6, color=COLORS["muted"])

# Histogram-band ticks
for m, label in BREADTH_MONTH_TICKS:
    y_t = y_for_month_in_hist(m)
    ax.plot([TIME_TICK_X0, TIME_TICK_X1], [y_t, y_t],
            color=COLORS["muted"], lw=0.6, alpha=0.85)
    ax.text(TIME_LABEL_X, y_t, label, ha="left", va="center",
            fontsize=6.6, color=COLORS["muted"])

ax.text(TIME_LABEL_X - 0.003, BAND_Y["web"] + 0.022, "month",
        ha="left", fontsize=7.6, color=COLORS["muted"], fontweight="bold")


# === Depth boxes on top ===
DEPTH_X = np.linspace(0.18, 0.85, 5)
DEPTH_BOX_W = 0.135
DEPTH_INDEX = {d["key"]: i for i, d in enumerate(DEPTH_PROGRAMS)}
for i, d in enumerate(DEPTH_PROGRAMS):
    fc = DEPTH_COLORS[d["key"]]
    edge = COLORS["text"] if d.get("highlight") else "none"
    lw = 1.6 if d.get("highlight") else 0
    ax.add_patch(FancyBboxPatch(
        (DEPTH_X[i] - DEPTH_BOX_W / 2, DEPTH_Y_TOP - DEPTH_BOX_H / 2),
        DEPTH_BOX_W, DEPTH_BOX_H,
        boxstyle="round,pad=0.005,rounding_size=0.012",
        facecolor=fc, edgecolor=edge, lw=lw, alpha=0.97))
    weight = "bold" if d.get("highlight") else "semibold"
    ax.text(DEPTH_X[i], DEPTH_Y_TOP + 0.032, d["label"],
            ha="center", va="center", fontsize=9.0,
            color="white", fontweight=weight)
    ax.text(DEPTH_X[i], DEPTH_Y_TOP + 0.006, d["subtitle"],
            ha="center", va="center", fontsize=6.6,
            color="white", linespacing=1.20)
    ax.text(DEPTH_X[i], DEPTH_Y_TOP - 0.030, f"{d['n_total']} cited IDs",
            ha="center", va="center", fontsize=6.6,
            color="white", fontweight="bold")
    if d.get("highlight"):
        ax.text(DEPTH_X[i], DEPTH_Y_TOP + 0.082, "$\\bigstar$ pilot-selected",
                ha="center", fontsize=7.6,
                color=COLORS["text"], fontweight="bold")


# === Lineage arcs ===
def arc(x0, y0, x1, y1, color, alpha=0.7, lw=0.7):
    ymid = (y0 + y1) / 2
    verts = [(x0, y0), (x0, ymid), (x1, ymid), (x1, y1)]
    codes = [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4]
    p = MplPath(verts, codes)
    ax.add_patch(PathPatch(p, edgecolor=color, facecolor="none",
                           lw=lw, alpha=alpha, zorder=3))


for rec in PAPER_RECORDS_V3:
    aid, title, theme_idx, bset, dtargets, _ = rec
    if not dtargets:
        continue
    src_bk = next(iter(bset)) if bset else "web"
    if (src_bk, aid) not in PINNED_POS:
        continue
    x0, y0 = PINNED_POS[(src_bk, aid)]
    for dk in dtargets:
        if dk not in DEPTH_INDEX:
            continue
        xt = DEPTH_X[DEPTH_INDEX[dk]]
        yt = DEPTH_Y_TOP - DEPTH_BOX_H / 2 - 0.005
        color = DEPTH_COLORS[dk]
        is_sel = DEPTH_PROGRAMS[DEPTH_INDEX[dk]].get("highlight")
        arc(x0, y0, xt, yt, color,
            alpha=0.85 if is_sel else 0.55,
            lw=1.1 if is_sel else 0.65)


# === Bell-Venderbos call-out ===
piezo_ti = CATEGORY_TO_IDX["altermagnetism"]
ax.text(THEMES_X[piezo_ti], BAND_Y["b01"] + 0.020,
        "Bell--Venderbos cluster\n(b1 unique)",
        ha="center", va="bottom",
        fontsize=6.6, color=COLORS["orange"], fontweight="bold",
        linespacing=1.1)
ax.annotate("", xy=(THEMES_X[piezo_ti], BAND_Y["b01"] - 0.001),
            xytext=(THEMES_X[piezo_ti], BAND_Y["b01"] + 0.018),
            arrowprops=dict(arrowstyle="->", color=COLORS["orange"],
                            lw=1.0, mutation_scale=7))


# === Legend strip BELOW the category labels (not overlapping anywhere) ===
LY = LABELS_N_Y - 0.035
LX = 0.115
LSPACE = 0.135  # horizontal pitch between legend entries

legend_entries = [
    (("scatter", {"s": 12, "color": COLORS["blue"], "alpha": 0.95,
                    "edgecolor": "white", "lw": 0.45}), "cited in report"),
    (("scatter", {"s": 3.2, "color": COLORS["blue"], "alpha": 0.34,
                    "edgecolor": "none"}), "active access only"),
    (("scatter", {"s": 18, "facecolor": "white", "edgecolor": COLORS["blue"],
                    "lw": 1.0}), "in 2 reports (curated)"),
    (("scatter", {"s": 32, "color": COLORS["text"], "edgecolor": "white",
                    "lw": 0.5}), "all 3 (consensus)"),
    (("scatter", {"s": 18, "color": COLORS["orange"], "marker": "s",
                    "edgecolor": "white", "lw": 0.45}), "novelty-audit (web)"),
]

for i, ((kind, kwargs), label) in enumerate(legend_entries):
    x = LX + i * LSPACE
    if kind == "scatter":
        ax.scatter([x], [LY], **kwargs, zorder=10)
    else:
        ax.plot([x - 0.008, x + 0.008], [LY, LY], **kwargs)
    ax.text(x + 0.012, LY, label, fontsize=7.6, va="center",
            color=COLORS["text"])

# Save with very tight margins (2 mm pad)
for suffix in ("png", "pdf"):
    fig.savefig(FIG_DIR / f"fig2_idea_conception.{suffix}",
                dpi=300, bbox_inches="tight", pad_inches=0.005,
                transparent=False)
plt.close(fig)
print("[ok] fig2_idea_conception (final, tight margins)")
