# Task: Replicate Reference Paper 3

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. The final paper must make a clear and substantial scientific contribution.

## Your task

Prior agents have selected published papers as reproduction targets — papers whose calculations our pipeline must demonstrably reproduce before we can trust it on the target system. You replicate paper **3**.

Reproduction means: take the paper's quantitative claims and computational figures, run the equivalent calculations using our local toolchain, and produce numerical and graphical comparisons. **Reproduce ALL quantitative claims and ALL computational figures within the scope defined by `reproduction_targets.md`.** Cherry-picking the simple calculations defeats the purpose.

The paper may have used a different code than ours. Our toolchain (Quantum ESPRESSO, Wannier90, plus tools installed by the prior tooling agent) is the foundation; you have full freedom to configure and extend it. Different code, same physics: comparison is at the physical-quantity level.

## Input

**The paper to reproduce:**

- `prior_work/reproduction_targets.md` — read the entry for paper 3. It specifies mandatory quantitative benchmarks with tolerances, pipeline stages validated, and scope.
- Full text: `prior_work/markdown/<paper_id>.md` — **cat the entire file into context. Read in full, not selectively.**
- Original PDF: `prior_work/pdfs/<paper_id>.pdf` — for figures and any content garbled in markdown.

**Local environment:**

- `runs/run_002/knowledge/TOOL_REPORT.md` — central tool registry. **Read first.**
- `runs/run_002/knowledge/` — per-tool docs, custom-script docs.
- `runs/run_002/tool_examples/` — verified examples per tool.
- `runs/run_002/.venv/` — Python venv: `source <PROJECT>/runs/run_002/.venv/bin/activate`

**Global knowledge (mandatory reads):**

- `<PROJECT>/knowledge/PSEUDOPOTENTIALS.md`
- `<PROJECT>/knowledge/INDEX.md` — contains critical computational gotchas and lessons learned. **Read the sections relevant to your pipeline tools and calculation types carefully before computing anything. Failure in doing so will result in time wasted and garbage produced.**
- `<PROJECT>/knowledge/literature_access.md`
- `PILOT_HOUSE_RULES.md` in your workspace — **read before any computation. Obey EVERYTHING inside. Even if any required procedure increases work significantly, DO IT (like U scan and Wannier band verification). Failure of doing so is regarded complete failure of the whole task since skipping required works and gates will certainly result in garbage data. Especially: 1. after starting a calculation, DO ABSOLUTELY NOTHING (except for checking RAM/core usage) UNTIL IT IS DONE. You should have only ONE monitor to see when the job stops. Do not spawn multiple monitors only to confuse yourself. One job at a time, so no more than one monitor. 2. DO NOT KILL AND RESTART AN SCF RUN UNLESS YOU ARE SURE THE NUMBER STAYS EXACTLY THE SAME FOR >10 ITERATIONS OR HAS OSCILLATED MULTIPLE TIMES. Evidence has shown that you like to grow impatient and kill scf multiple times, resulting in no result.**

**Prior context:**

- `program_selection.md` — which research program was selected and why. Gives you the big picture of what the production pipeline will do. Skim only.
- `../session_3_reproduce_*` - other prior session 3 paper replication results. **IF SOME INTERMEDIATE RESULT FROM PREVIOUS REPLICATION IS USEFUL, COPY AND BUILD ON IT (e.g. converged SCF or U scan of same material and condition). However, do so with critical thinking: is the other result well converged? Does it give expected result quantitatively? If not, do not simply inherit. Rather, step back and think about physics, and improve on top of ths previous parameter/pseudopotential space. EVERYTHING OUTSIDE OF YOUR WORKSPACE IS READ-ONLY, BUT FEEL FREE TO COPY FROM THERE.**

**Compute:** 12 cores, 48 GB RAM. See `TOOL_REPORT.md` for invocation commands.

**Filesystem:** Corpus, knowledge, prior_work are read-only. Write in your workspace (`reproduction/paper_3/`). You may install additional Python packages if necessary — document in worklog.

## Workflow

### Phase 1: Deep reading and research logic analysis

**Cat the full paper markdown into your context.** Then read with two goals:

**Goal A — Reproduction inventory.** The standard inventory:
- Every quantitative claim in scope (per `reproduction_targets.md`).
- Every computational figure in scope.
- Pipeline: codes, parameters (functional, PP, k-mesh, ecutwfc, etc.), workflow.
- Mapping: paper's tool/parameter → our equivalent. Note substitutions and expected systematic shifts.

**Goal B — Research logic and transferable lessons.** Read as a researcher, not just as a reproducer:
- What is the paper's logical structure? Does it build from simple to complex — testing a basic setup, then adding complexity (SOC, U, strain, etc.)? This progression is your reproduction plan's natural order.
- What convergence tests and sensitivity analyses did the authors perform? These tell you which parameters are critical and which are safe to use at default values.
- What gotchas, warnings, or subtleties does the paper mention — explicitly or implicitly? Parameters that are unusually sensitive, sign conventions that differ from defaults, known pitfalls of the method on this material class?
- What parameters and settings from this paper are directly transferable to the production calculations on the target system? These are high-value outputs of the reproduction.

Write `reading_summary.md` with both Goal A (inventory + reproduction plan) and Goal B (research logic + gotchas + transferable lessons).

### Phase 1.5: Critical assessment of inherited toolchain

Before using any tool or custom script from the local environment, critically read `TOOL_REPORT.md`. For each tool you will rely on:

- What was actually validated, and in what regime?
- What is marked partial, deferred, or untested?
- Established open-source codes carry high credibility. Custom scripts from prior sessions carry low credibility.

Write `tooling_assessment.md`: per tool, validation status and your plan (use as-is / revalidate / replace). For partially-validated custom scripts, **prefer rewriting over debugging.**

### Phase 2: Execute reproductions

**Validate the pipeline on a single point quantitatively (aiming within 20% from paper value) before any parameter sweep.** If the paper sweeps a parameter (strain, pressure, doping, etc.), run ONE representative point first. Verify that the output is physically sound and internally consistent before investing hours in the full sweep. If the single-point output has problems, diagnose and fix the pipeline first.

**Think critically about how many sweep points you actually need.** The goal is to verify a trend, not to produce a pretty curve. How many points does the trend require — does it monotonically increase (fewer points suffice) or does it have a non-trivial shape (more points needed at critical features)? Choose the minimum number of well-converged points that fully capture the essential behavior. This rule can be used to override what is specified in `reproduction_targets.md`: you must conduct all parameter sweeps as specified in `reproduction_targets.md`, but you should adjust number of points accordingly for efficiency.

**Prioritize smartly.** One key quantitative value, properly converged, is worth more than ten handwaved values of unknown convergence. Organize your work:

1. **First priority: mandatory targets.** The benchmarks marked mandatory in `reproduction_targets.md` must be matched within the specified tolerances. These validate the production pipeline — get them right. If a mandatory target deviates beyond tolerance, you must diagnose and resolve it before moving on.

2. **Second priority: computational figures.** For each figure in scope, compute your version and produce a side-by-side comparison (`comparison_figN.png`). Read the paper's figure carefully — axis labels, units, parameter values in captions often contain information not in the main text. The cycle is: read the figure → compute → overlay or compare → identify deviations → diagnose → fix → recompute until the comparison is honest and understood. Do not produce a comparison figure you have not actually looked at and evaluated.

3. **Third priority: convergence and sensitivity.** If the paper tested convergence of a key parameter (k-mesh, cutoff, U value), reproduce that test. If it didn't but you suspect sensitivity, run a quick check. Document converged parameters — the production agent will inherit them.

4. **Time-constrained fallback:** If time is tight, ensure all mandatory targets have quantitative values with convergence verified. Reduce figure comparisons to the most informative ones. Never hand-wave a mandatory target.

**Tolerance guidance:** For mandatory targets, use the tolerances specified in `reproduction_targets.md`. For non-mandatory quantitative values where no tolerance is specified, aim for ≤20% agreement — if deviation exceeds this, diagnose and document the cause. If a value is unconverged or quantitatively misaligned, document what you tried, what direction the convergence is heading, and what the production agent should do to close the gap.

For each calculation:
- Process check before launching (house rules §1), log to WORKLOG.
- Launch with proper parallelism. Block fully.
- On success: extract numbers, compare to paper, update `paper_verdict.json`.
- On failure: diagnose. Do not abandon — failures are where pipeline bugs are discovered.

If a result deviates beyond tolerance, **explain why before moving on.** Possible causes: different functional/PP, different convergence, ambiguity in what paper plotted, paper-side error, your-side error.

### Debugging discipline

When a result deviates, suspect in this order:
1. Your custom code (conventions, signs, units, prefactors).
2. Your input parameters (compare against paper parameter by parameter).
3. Tool version or configuration mismatch.
4. The paper itself (last resort — only after exhausting 1-3).

Use the internet for physics conventions and tool documentation (house rules §11).

### Custom script discipline

Custom scripts require ≥3 independent validations on published reference values before their outputs enter the verdict. Document validations in worklog.

### Phase 3: Verdict, lessons, and production parameters

`paper_verdict.json`:
- Tier (T4 = all mandatory within tolerance; T3 = qualitative match with offsets; T2 = partial; T1 = failure).
- Per mandatory target: paper value, your value, deviation, tolerance met (yes/no), diagnosis if no.
- Per figure: comparison produced, match quality.
- Overall: does this reproduction validate the pipeline stage it was selected for?

`reproduction_report.md`:
- Summary of what was reproduced and at what quality.
- **Transferable lessons for production** (highest-value output):
  - Converged parameters the production agent should adopt (k-mesh, ecutwfc, U, smearing, convergence thresholds) — with evidence they are converged.
  - Parameters where convergence was NOT tested — flagged for production to verify.
  - Gotchas encountered and how they were resolved.
  - Any pipeline configuration the production stage should adopt or avoid.
- Open questions or unresolved deviations.

## Time discipline

**Fixed time structure for all papers:**
- **Start:** Record a timestamp in WORKLOG.md.
- **At 6 hours:** Assess progress. If mandatory targets are not yet reproduced, reduce scope — drop lower-priority figures and focus exclusively on mandatory quantitative benchmarks.
- **At 8 hours:** Stop launching new calculations. Focus on writing up results, producing comparison figures, and finalizing the verdict with data on hand.
- **At 10 hours:** Hard stop. Write all deliverables immediately with whatever data exists.

Partial reproduction with honest verdict is better than fabricated complete reproduction.

## Deliverables

| File | Content |
|------|---------|
| `WORKLOG.md` | Continuous log |
| `reading_summary.md` | Inventory + research logic + gotchas + transferable lessons |
| `tooling_assessment.md` | Critical assessment of inherited tools |
| `reproduction_calculations/` | All calculations |
| `comparison_figN.png` | One per computational figure |
| `paper_verdict.json` | Quantitative verdict per mandatory target |
| `reproduction_report.md` | Summary + production-transferable parameters + lessons |

## Begin

Read `PILOT_HOUSE_RULES.md`, then `TOOL_REPORT.md`, then **cat the full paper text** and read it thoroughly — for both reproduction targets AND research logic. Record your start time in WORKLOG.md. The downstream production stage trusts your verdict and inherits your converged parameters. If you cut corners, production builds on a false foundation.
