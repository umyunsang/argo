# House Rules -- Pilot and Production Stages

These rules govern all computation-bearing stages. Violations corrupt results silently; there is no safe shortcut.

---

## 1. Do not oversubscribe -- THE MOST IMPORTANT RULE

**This is the single most important rule in this document. Violating it produces silently wrong results, corrupted outputs, and wasted days. Read it twice.**

You have 12 CPU cores and 48 GB RAM. **The total number of heavy threads across all running processes must never exceed 12.** One heavy job at a time is the simplest way to guarantee this. **Watch out and avoid OOM (see INDEX.md).**

**Before EVERY heavy process launch** (`mpirun`, or any CPU-intensive script), check what is currently running. Use a command like:

```bash
ps aux | grep -E "pw\.x|ph\.x|bands\.x|dos\.x|projwfc\.x|pp\.x|wannier90\.x|python.*mpi|abinit|yambo" | grep -v grep
```

This command may not cover every tool you install. **Adapt it as you add new tools.** The check must not error out. Log the output to `WORKLOG.md` every time -- before every heavy launch, without exception.

If any heavy process is already running: **wait for it to finish or kill it.** Do not launch another.

**For QE and Wannier90 family tools: always `mpirun -np 12` and fully block.** While a QE/Wannier90 job is running, do absolutely nothing else -- do not write input files for the next step, do not run analysis scripts, do not test other tools, do not write code, do not plan ahead. Just wait for it to finish. The reason for strict idleness: agents routinely background jobs by accident, then launch another, oversubscribing the cores and producing garbage.

For other tools, use your judgment on parallelism -- but the total thread count across all concurrent processes must never exceed 12. Oversubscribing makes everything extremely slow and wastes hours. But undersubscribing (running on 1 core when 12 are available) is equally wasteful. **Default to `mpirun -np 12` for any heavy calculation.**

## 2. Memory estimation

**Before scaling any parameter** (k-mesh, grid size, number of bands, supercell) beyond what a previous successful run used, estimate the new memory requirement. If projected memory exceeds 40 GB, restructure before launching (e.g., block decomposition, coarser grid).

## 3. Pipeline sanity check

**After EACH calculation step completes (SCF, NSCF, Wannier, etc.), verify basic physical quantities against expectation (previous step, previous run, paper etc.) BEFORE proceeding to the next step**. For DFT: check band gap, magnetic moments and etc. **Does SCF and NSCF give quantitatively consistent gap and magnetic moment etc.? If gap is smaller, did you forget U term in NSCF?** For Wannier: check spreads, ?_I and etc. A 10-second check prevents days of wasted downstream computation. **THIS IS LEARNED IN VERY HARD WAYS THROUGH MANY LESSONS. MUST FOLLOW.** When setting up a new calculation by copying or modifying a prior input, verify all cards and settings carried over -- missing cards are silent errors that produce plausible-looking but physically wrong output. e.g. nscf should carry majority of settings in scf (like starting_magnetization and especially Hubbard U). Dropping parameters will silently change physics along the pipeline, which can only be catched if you analyze intermediate results thoroughly.

## 4. ibrav=0 always

All QE inputs use `ibrav=0` with explicit `CELL_PARAMETERS {angstrom}` or `{bohr}`. No exceptions.

## 5. Wannier validation is mandatory -- no exceptions

Read INDEX lessons on frozen window orbital character and spread diagnostics and other gotchas before setting up any Wannier chain, very carefully. **THEY ARE EXTREMELY IMPORTANT LESSONS**, ignoring which will result in garbage data and wasted time.

### Setup sequence -- do in order before writing the .win file

**A. Pseudopotential inventory.** List valence orbitals from PP headers; classify semicore vs active valence.

**B. SCF + NSCF.** Verify magnetic moments and gap against expectation before continuing. NSCF nbnd must generously cover the full Berry-relevant window with headroom.

**C. Fatband (projwfc on high symmetry k-path).** Mandatory. Identify the semicore-valence gap and the orbital characters present in the Berry-relevant region. Chemistry intuition alone is not sufficient justification.

**D. Projections and num_wann.** Choose minimal basis combining chemical intuition with the fatband analysis. Include all characters carrying meaningful weight in the Berry-relevant window; missing character -> contaminated gauge that silently passes band checks. Semicore orbitals whose character differs from the chosen basis must be excluded (via `dis_win_min`/`dis_froz_min` set in the semicore-valence gap (recommended) or via `exclude_bands` (less tested)).

**E. Compute the dis_froz_max ceiling.** This is a pure arithmetic step, no Wannier run required. From NSCF eigenvalues on the Wannier k-mesh, find min over k of the (num_wann+1)-th band energy. Setting dis_froz_max above this will result in direct error. But more subtle is when dis_froz_max is slightly below this, yet higher than some k of the num_wann-th band energy: those k are locked (ndimwin = num_wann), causing silent gauge failure which will only result in unphysically compensated m_orb, yet band fit looks still good. So this step gives the absolute max of dis_froz_max and some hint of safer region a bit more below.

**F. Initial dis_froz_max.** dis_froz_max should be always higher than E_F. Usually a good starting point is near E_F + 2 eV (metals) or CBM + 2 eV (insulators with a clear gap), with some headroom below the Step E ceiling. 2 eV is just a starting point that works for many material, you can adjust according Step E ceiling. If the ceiling leaves no viable window with adequate Berry coverage, the basis and num_wann might be insufficient -- return to D and extend. `dis_win_max` usually not as critical as `dis_froz_max`; set wide. But it can also influence the end result so convergence is needed for careful research.

### dis_froz_max must be scanned for Berry-observable production

A single dfroz value is NEVER sufficient justification for m_orb, AHC, SHC, optical/shift current, or any Berry-curvature-derived observable. Scan dfroz within the Step E ceiling and verify a plateau: ideally, a contiguous range where the target observable is stable. But sometimes the plateau can be small or peaky, in which case ideally one should go back to D and extend basis and num_wann, but many papers just live with imperfect plateau and try to converge other parameters choosing a dfroz where signal is clearest. Use your best judgement here. Independent of your decision, you MUST show dis_froz_max variance near the value you choose, which is important information about confidence.

For pure band-interpolation uses (effective masses, BoltzWann, DOS), a single converged recipe is fine. Plateau scan is specifically for Berry observables.

### Community-standard checks (necessary overall, yet not sufficient for Berry)

Additionally, below is the community standard practice for Wannier-based calculations. **Every published Wannier study verifies band quality. You must too.** Any time you produce Wannier functions, you MUST pass ALL THREE checks below BEFORE using them for anything (AHC, orbital magnetization, Berry curvature, transport, or any downstream quantity). Yet, **Passing Checks 1-3 does NOT automaticaly validate Berry observables.** Band energies can be interpolated correctly by a gauge that is k-discontinuous (locked-k), symmetry-broken, or sublattice-symmetric in ways that cancel the target observable. The plateau scan above is what establishes sufficiency.

**Check 1 -- Spreads.** Read the `.wout` Final State spreads. All WFs of the same orbital type should have similar spreads (within ~50%). If any WF has spread >3x the median, the fit is bad. Also check: if ?_total > 2x ?_I, the disentanglement window is likely wrong. Stop and fix.

**Check 2 -- Band comparison.** Compare the nscf eigenstates and the WF eigenstates on the whole k-mesh (which should be available in .wout file). Or run QE `pw.x` and `bands.x` on a high-symmetry path, run Wannier90 band interpolation on the same path, and plot both on the same axes. **The community standard is "perfect agreement" near E_F** (WannierTools tutorial: "Fig 5 shows the band structure comparison between DFT (black lines) and Wannier interpolation (red dots). It shows perfect agreement."). If they don't overlap quantitatively within ~50 meV near E_F, everything downstream is garbage. Stop and fix. If the target observable involves Berry connection (m_orb, AHC, polarization), fit quality is required on BOTH sides of the chemical potential within the Berry-relevant window, since virtual transitions couple occupied to empty states, and ALL occupied states are important.

**Check 3 -- Convergence warnings.** If the `.wout` contains "Disentanglement convergence criteria not satisfied", the result is untrustworthy. Stop and fix (adjust projections, windows, or k-mesh). Convergence warnings are not cosmetic. If disentanglement reports 'criteria not satisfied', downstream results are unreliable -- do not proceed.

**Do not proceed** to any Berry-curvature or response-property calculation until all three checks pass. Do not rationalize a failed check as "good enough."

**Check 4 -- Symmetry-forbidden AHC components (for Berry curvature calculations only).** After computing AHC at a single point, verify that symmetry-forbidden ?_ij components are negligible compared to the physical component. If a forbidden component is comparable to or larger than the signal, the Wannier gauge is breaking crystal symmetry. **Use WannierBerri's `system.set_symmetry()` with the magnetic point group generators and `symmetrize=True` in `wberri.run()`**. Standard Wannier90 MLWFs routinely break symmetry -- this is documented behavior, not a bug.

**Check 5 -- Locked-k fraction (Berry observables).** Fraction of k with ndimwin = num_wann must be exactly zero.

If any check fails, debug. Possible causes (not exhaustive):
- DFT k-mesh too coarse for good Wannier fitting (denser NSCF mesh needed)
- dis_froz_max too close to Step E ceiling, or dis_win_min and dis_froz_min placement letting semicore bleed in
- Basis insufficient (return to Step D)
- Loose SCF convergence feeding noise into overlaps
- WF centers drifting off atomic sites (wrong projections)

Fix and re-check until all four pass. See `INDEX.md` lessons 21-39 for detailed Wannier and AHC gotchas.

## 6. Pseudopotential, functional, and Hubbard U matching

Consult `knowledge/PSEUDOPOTENTIALS.md` before each new system. Match the exchange-correlation functional and pseudopotential to the physical requirements of the system (e.g., semicore states for transition metals, relativistic treatment for heavy elements). Test convergence of plane-wave cutoff on the actual target system before committing to production parameters.

**Hubbard U is not transferable between codes or projector types.** If a paper reports U calibrated with a different code (e.g., VASP PAW) or different Hubbard projectors than yours (e.g., QE ortho-atomic), do NOT copy the U value. The same nominal U produces different effective correlation depending on the projector. You must both: (a) compute U from first principles using QE's `hp.x` (DFPT linear response, self-consistent in 2-3 iterations), and (b) scan U to match the paper's key observable (e.g., band gap, magnetic moment), and (c) compare the results and decide one for downstream calculation. Document the U provenance explicitly.

## 7. Consult knowledge before claiming impossibility

Before concluding "this tool cannot do X" or "this calculation is infeasible": read `knowledge/INDEX.md` and any tool-specific knowledge doc. The conclusion "not feasible" requires a documented attempt or a specific technical reason, not a guess.

## 8. Time awareness -- general guidance

Each session has its own time structure defined in its prompt. Apply this guidance proportionally:

- **First ~50% of time:** execute the plan.
- **At ~70%:** pause and assess. Are critical deliverables done? If not, begin scope reduction.
- **At ~85%:** stop launching new long calculations. Focus on writing up.
- **At cap (hard stop):** finalize and commit all outputs. A partial deliverable with honest verdict beats fabricated completion.

## 9. Production stage -- unlimited time

The production stage has no cumulative wall-time cap. Completeness and correctness take priority over speed. However, for any single calculation exceeding 8 hours, reconsider: is there a cheaper alternative that gives equivalent diagnostic value? If not, proceed. If yes, use the cheaper alternative.

## 10. Filesystem discipline and WORKLOG

- The corpus directory and global knowledge directory are **read-only**. Never write there.
- All your work goes in your own session workspace directory.
- Keep input files, output files, and scripts together in each calculation directory.

**Maintain a running `WORKLOG.md` in your workspace root.** This is mandatory. Append continuously:
- Before every heavy job: the process-check output (?1), input parameters, what you expect.
- After every heavy job: wall time, key output numbers, pass/fail assessment.
- Every decision point and its rationale.
- Every failure and how you diagnosed it.

If it is not in the WORKLOG, it did not happen.

## 11. Internet access

You have full internet access. Use it for:
- Tool documentation and tutorials
- Crystal structures (Materials Project, ICSD, COD)
- Reference values for validation (lattice constants, band gaps, phonon frequencies)
- `knowledge/literature_access.md` for structured API access to literature

Do NOT use internet access to find someone else's solution to this specific problem.

## 12. Scope precedence

If your prompt or any input document explicitly defines a reduced scope -- a list of which claims to reproduce vs. skip, a parameter substitution, etc. -- that explicit scope takes precedence over general guidance like "reproduce everything." If you believe the scope decision is wrong, document the disagreement in your worklog and proceed with the specified scope anyway.
