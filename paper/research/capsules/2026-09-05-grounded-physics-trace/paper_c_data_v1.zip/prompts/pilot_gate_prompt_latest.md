# Task: Pilot Gate -- Iterative Pipeline Confidence Assessment

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. Prior agents have reproduced 5 published papers to validate the computational pipeline. Your job is to assess whether the pipeline is ready for production -- and if not, to close the most critical gap.

## Your task

**Depth over breadth.** One thing fully investigated to quantitative agreement with literature is worth infinitely more than five things explored qualitatively. Do not speculate about what "might work." Pick one gap, close it, and prove it with numbers.

The production pipeline can only be trusted on a new material if every computational step has been demonstrated to give quantitative agreement (?20%) with published literature on a physically similar system. A step that was only smoke-tested on a toy system, or that showed >2x disagreement with unresolved diagnosis, is not validated -- it is a guess.

## Input

**Prior work (mandatory reads -- read ALL before writing your verdict):**

- `session_3_reproduce_*/` -- all 5 reproduction sessions. Read each `reproduction_report.md`, `paper_verdict.json`, and skim each `WORKLOG.md` for methodology lessons and unresolved issues.
- `pilot_gate_*/` -- any previous pilot gate sessions (if they exist). Read each `pilot_gate_report.md` and `pilot_gate_verdict.md`. Pay attention to what was attempted, what worked, and what didn't.
- `pilot_reflect_*/` -- any previous pilot reflect sessions (if they exist). These contain literature searches, published reference values, and recommendations from a fresh-perspective review. **Pay close attention -- these identify specific papers and numbers you should reproduce or compare against.**
- `pilot_reflect_II_*/` -- any previous pilot reflect II sessions (if they exist). These contain paper figure analyses, gap analyses, and **planned pilot_gate tasks with specific deliverables.** **Pilot reflect II sessions supercede everything else regarding tasks. If a reflect II report assigns you a specific task, execute it instead of picking your own gap in Phase 2.**
- `session_1_prior_work/program_selection.md` -- the production program. What pipeline stages does production require? What are the headline claims?

**Local environment:**

- `runs/run_002/knowledge/TOOL_REPORT.md` -- central tool registry. **Read first.**
- `runs/run_002/knowledge/` -- per-tool docs, custom-script docs.
- `runs/run_002/tool_examples/` -- verified examples per tool.
- `runs/run_002/.venv/` -- Python venv: `source <PROJECT>/runs/run_002/.venv/bin/activate`

**Global knowledge (mandatory reads):**

- `<PROJECT>/knowledge/PSEUDOPOTENTIALS.md`
- `<PROJECT>/knowledge/INDEX.md` -- contains critical computational gotchas and lessons learned. **Read the sections relevant to your pipeline tools and calculation types carefully before computing anything. Failure in doing so will result in time wasted and garbage produced.**
- `<PROJECT>/knowledge/literature_access.md`
- `PILOT_HOUSE_RULES.md` in your workspace -- **read before any planning and computation. Obey EVERYTHING inside. Even if any required procedure increases work significantly, DO IT (like U scan and Wannier band verification). Failure of doing so is regarded complete failure of the whole task since skipping required works and gates will certainly result in garbage data. Especially: 1. after starting a calculation, DO ABSOLUTELY NOTHING (except for checking RAM/core usage) UNTIL IT IS DONE. You should have only ONE monitor to see when the job stops. Do not spawn multiple monitors only to confuse yourself. One job at a time, so no more than one monitor. 2. DO NOT KILL AND RESTART AN SCF RUN UNLESS YOU ARE SURE THE NUMBER STAYS EXACTLY THE SAME FOR >10 ITERATIONS OR HAS OSCILLATED MULTIPLE TIMES. Evidence has shown that you like to grow impatient and kill scf multiple times, resulting in no result. 3. For Wannier-based calculations: convergence warnings are not cosmetic. If disentanglement reports "criteria not satisfied", downstream results are unreliable -- do not proceed. Read corresponding PILOT_HOUSE_RULES parts and INDEX lessons on frozen window before setting up any Wannier chain.**

**Prior reproduction artifacts:** `session_3_reproduce_*`, `pilot_gate_*`, and `pilot_reflect_*` workspaces are read-only. **Copy any useful intermediate results (converged SCF, Wannier checkpoints, U scan data) into your own workspace.** But only inherit critically -- if a prior result didn't match literature quantitatively, don't blindly reuse it. Improve on it, or simply start from scratch. For QE, you can copy `outdir/` and use `restart_mode='restart'` to save SCF time when the cell and magnetic configuration are compatible.

**Compute:** 12 cores, 48 GB RAM. See `TOOL_REPORT.md` for invocation commands.

**Filesystem:** Everything outside your workspace is read-only. Your workspace as `pilot_gate_NN/` (ls the pilot directory to determine the next number). All output goes in your workspace only. You may install additional Python packages if necessary -- document in worklog.

**Pseudopotentials:** Virtually all QE-compatible pseudopotential libraries are available locally (see `PSEUDOPOTENTIALS.md` for paths). You should not need to download PPs -- just pick the right ones from what's available. If you genuinely need a PP that isn't local, you may search online and download it.

## Workflow

### Phase 0: Create your workspace as `pilot_gate_NN/` (ls the pilot directory to determine the next number). **All output goes in your workspace only**.

### Phase 1: Confidence assessment and verdict (DO THIS FIRST -- before any calculation)

Read all prior work. **Think critically and independently, as a skeptical referee would. THIS REFLECTION PART IS EXTREMELY IMPORTANT BECAUSE IT IS THE FOUNDATION OF THE WHOLE TASK: TAKE YOUR TIME, DIG DEEP AND THINK CAREFULLY.** Prior agents might neglect important details from raw data, their chain-of-thought reasoning may also be wrong, and their attributions for why a result deviated may be incorrect. Can the results between different runs really compared? Did they compare unconverged with converged results? Do multiple factors change at the same time, contributing to the difference? Dig into raw data. Can you find any difference of parameters that the previous agent neglected, which could tell a different story? Moreover, they lack the global view you now have across all 5 reproductions and any prior pilot gate sessions. Do not take their diagnoses at face value -- verify them against your own physics understanding and against raw data.

During Phase 1, you may search online and quickly fetch paper abstracts or values to inform your verdict. But this is a preliminary scan -- it will miss supplementary details, datasets, and methodological nuances. Do not assume you have read a paper because you skimmed its arXiv page. The full reading with published version, supplementary, and dataset is a separate mandatory step in Phase 2.5, and cannot be skipped even if you already fetched the arXiv version.

Imagine the production paper is published alongside all the reproduce and pilot_gate session data as supplementary material. A referee asks: "You couldn't reproduce [X] quantitatively -- how do I know your production results on a new material aren't noise?" That is the standard you are defending against.

For each pipeline stage that production requires, assess your confidence:

- **HIGH**: this step was tested on a physically similar system AND gave quantitative agreement (?20%) with published literature. The recipe (parameters, pseudopotentials, convergence settings) is documented and transferable.
- **MEDIUM**: this step was tested but only qualitatively (correct signs/trends, wrong magnitudes), OR on a system with different physics than production targets, OR with untested assumptions about why it didn't match quantitatively.
- **LOW**: this step was smoke-tested only (simple system, not production-relevant physics), OR showed >2x disagreement with diagnosis that is speculation rather than verified explanation.
- **NONE**: this step was never executed in any session.

**For each non-HIGH stage, do the following analysis:**

1. **Identify the gap precisely.** What quantitative target was missed, and by how much?
2. **Review prior diagnoses.** What did the reproduce/pilot_gate agents say caused the deviation? Do you agree with their reasoning? What alternative explanations exist?
3. **List concrete possibilities** for closing the gap -- with your assessment of how likely each is to work and why.
4. **REQUIRED: Search online.** For each gap, search documentation, forums, mailing lists, tutorials, examples, and GitHub issues for the relevant tools and physics. Many problems in computational physics are well-known community issues with documented solutions. **Do this search before deciding what to work on -- it may completely change your assessment of which gap is tractable.** Judge the authority of sources yourself (official docs > tutorials > forum posts > random blogs).
5. **Assess tractability.** Is there a clearly promising path, or has this been extensively attempted across multiple sessions without convergence? Do not go down rabbit holes -- if prior sessions have made extensive, well-reasoned attempts and the gap remains, it may be genuinely hard. Prioritize gaps where you see a concrete, evidence-based path to T4 over gaps that are high-impact but have no clear solution.

Write `pilot_gate_verdict.md` with:
1. A confidence table (one row per production pipeline stage).
2. For each non-HIGH stage: the full analysis above (gap, prior diagnoses, your assessment, online research findings, possibilities, tractability).
3. Overall verdict: **PASS** (all production-critical stages at HIGH) or **NOT PASS** (list gaps ranked by combined impact x tractability).

**If PASS, stop here.** Write `pilot_gate_report.md` summarizing why and finalize.

**If NOT PASS, proceed to Phase 2.**

### Phase 2: Pick ONE targeted project

From your NOT PASS gaps, pick **the single gap that best combines high impact on production confidence with a clear, evidence-based path to resolution.** Not two gaps. Not three. One.

You have two options:

**Option A -- Reproduce one new paper.** Download and reproduce a published paper that directly exercises the gap. Same workflow as `session_3_reproduce` sessions (reading_summary, WORKLOG, comparison figures, verdict). Use literature_access.md for paper retrieval. Pick a paper where the answer is known so you can verify quantitatively.

**Option B -- Enhance a previous result or run a targeted test.** This could include: convergence studies (k-mesh, cutoff), pseudopotential comparison, U scan to match a known observable, SOC on/off comparison, or any other controlled test that produces a quantitative number compared to published literature.

### Phase 2.5: MANDATORY -- Read the reference paper before any calculation

**This applies to BOTH Option A and Option B.** Any time you are comparing your result against a published number, you MUST read the source paper thoroughly first. A number without its context is meaningless -- you need to understand what code, what parameters, what conventions produced that number before you can meaningfully compare.

**Step 1: Get the published version.** If the paper has a journal-published version, you MUST use it. An arXiv preprint is NEVER the published version, even if the content appears identical -- arXiv lacks supplementary materials, datasets, and final methodological details, and using it wastes sessions and computation. Do not attempt to bypass paywalls or download published PDFs yourself. Stop, create a folder in your workspace (e.g., `reference_papers/`), and ask the user: give them the DOI, tell them you need the main text PDF, supplementary PDF, and any linked code or dataset. Wait for "continue."

**Step 2: Read the full paper -- main text AND supplementary AND dataset.** Not just the abstract. Not just one number from a table. Read the computational details section word by word. Read the supplementary material. If a dataset or code repository is linked, examine **every file** -- input files, scripts, output logs, intermediate products. Not just files for our code -- files for ANY code the paper used. The paper may use a different DFT code, but every parameter in their input files has a physical meaning that maps to our pipeline. Extract ALL of them.

**Step 3: Replicate the recipe.** The goal is **faithful replication of the paper's computational setup**, translated to our pipeline. Do not fixate on the seemingly biggest discrepancy or contribution and selectively pick which parameters to match and which to dismiss. Very often, some details you ignore at the beginning turn out to be important. So, pay attention to everything. Specifically:

- Map every parameter from the paper's input files to our pipeline equivalent. If the paper uses a different code, read the documentation for BOTH codes to understand what each parameter does and find the correct equivalent. Do not assume parameter names are transferable across codes -- follow the references the paper cites for each methodological choice.
- For parameters not explicitly stated in the main text (e.g., number of bands, energy windows, convergence thresholds), analyze thoroughly the dataset's input files, output logs, and figures. Inspect the paper's figures carefully -- band structure plots, convergence plots, and DOS figures encode implicit parameter information.
- If a parameter cannot be determined from any source or it is genuinely not comparable due to different software, note it explicitly and make a physically motivated choice. Document your reasoning.

Write `parameter_comparison.md` (MANDATORY deliverable): every parameter from the paper, the equivalent in our pipeline, and how you will match it. This is not a document for deciding what matters -- it is a checklist for confirming you have matched everything.

**After writing `parameter_comparison.md`, STOP.** Re-read `PILOT_HOUSE_RULES.md` and the relevant sections of `INDEX.md`. Check: does your parameter comparison cover everything the rules require? Have you dismissed any parameter as "can't map" or "probably not important" that a rule actually addresses? Prior sessions have written parameter comparisons, dismissed the most important difference, and wasted entire sessions debugging the wrong thing. If a parameter differs and you haven't matched it, it is a candidate problem -- not something to explain away.

**Step 4: Validate by comparing intermediate products against the reference.** If the dataset includes intermediate outputs (Wannier spreads, band structures, convergence logs), compare yours against theirs at each pipeline stage. If intermediates don't match, stop and think deeply about physics -- what is physically different? Fix the upstream cause before proceeding. A final number produced without intermediate validation is not trustworthy. If your final result does not match the paper, you have two tools: (1) compare intermediates more deeply to locate where the pipeline diverges, and (2) go back to `parameter_comparison.md` -- every parameter difference you listed but did not match is a candidate cause. The answer is almost always in the parameters you haven't matched yet.

**Step 5: Write `reading_summary.md`.** Summarize the paper's physics, your complete parameter mapping, and your replication plan. The final verdict must come from running the full pipeline end-to-end with our own tools -- but intermediate comparisons against the dataset are essential for debugging.

**Pseudopotential choice is often the most impactful variable.** Before starting any calculation, check what pseudopotential files are available locally (in the PP directories documented in PSEUDOPOTENTIALS.md). Are there alternative choices (different libraries, different core-valence partitions, PAW vs NC) that might give better results for your specific system? If a prior reproduction showed systematic deviation, pseudopotential mismatch is a prime suspect.

**The goal is to reach T4 (?20% agreement with literature) on this one thing.** Write a concrete plan in WORKLOG before starting: what is the central question, what quantitative target will you compare against, what parameter mapping ensures an apples-to-apples comparison, and what does success look like.

### Phase 3: Execute

**Before launching any calculation, STOP and re-read `PILOT_HOUSE_RULES.md` in full AND the relevant sections of `INDEX.md` for the tools you are about to use.** Do this now, not from memory -- hours of reading and planning have passed since session start. Every rule and check in these documents was written because ignoring it has resulted in garbage data and days of wasted computation. This is not hypothetical: prior sessions have lost 10+ hours to violations of rules that were read at session start and forgotten by calculation time. Re-read. **OBEY `PILOT_HOUSE_RULES.md` IN FULL, especially all those checks and gotchas.** Then compute.

**Validate on a single point before any sweep.** If the paper or test sweeps a parameter, run ONE representative point first. Verify it is physically sound and within reasonable range of the target before investing hours in the full sweep.

**Think critically about how many points you need.** The goal is to verify quantitative agreement, not to produce pretty curves.

**Prioritize the quantitative target.** One key value, properly converged and matching literature, is the entire deliverable. Everything else is secondary.

For each calculation:
- Process check before launching (house rules ?1), log to WORKLOG.
- Launch with proper parallelism. Block fully.
- On success: extract numbers, compare to literature.
- On failure: diagnose. Failures are where pipeline gaps are discovered.

### Debugging discipline

When a result deviates, suspect in this order:
1. Your custom code (conventions, signs, units, prefactors).
2. Your input parameters (compare against paper parameter by parameter).
3. Tool version or configuration mismatch.
4. The paper itself (last resort -- only after exhausting 1-3).

Use the internet for physics conventions and tool documentation (house rules ?10).

### Custom script discipline

Custom scripts require ?3 independent validations on published reference values before their outputs enter the verdict. Document validations in worklog.

### Phase 4: Updated assessment (APPEND, do not overwrite)

After completing your targeted project, write `pilot_gate_report.md`. This is a NEW document -- do NOT overwrite or modify `pilot_gate_verdict.md` from Phase 1. The Phase 1 verdict is the "before" snapshot; the report is the "after." Both must be preserved for provenance.

`pilot_gate_report.md` should contain:
- What gap you targeted and why.
- What you did (briefly).
- Quantitative result vs literature.
- Updated confidence assessment for the stage you worked on -- did the gap close?
- Remaining gaps (for the next pilot_gate iteration, if needed).

**Re-evaluate honestly.** If your targeted project did NOT close the gap (result still >20% off, or revealed a deeper problem), say so. Do not inflate confidence because you spent time.

## Time discipline

- **Start:** Record a timestamp in WORKLOG.md.
- **At 6 hours:** Assess progress. If the quantitative target is not yet matched, reduce scope -- focus exclusively on getting one clean number.
- **At 8 hours:** Stop launching new calculations. Write up.
- **At 10 hours:** Hard stop. Finalize all deliverables with whatever data exists.

## Deliverables

| File | Content |
|------|---------|
| `pilot_gate_verdict.md` | Confidence table + gap analysis + PASS/NOT PASS (written FIRST, before calculations) |
| `WORKLOG.md` | Continuous log |
| `parameter_comparison.md` | Every parameter from reference paper/dataset mapped to our pipeline -- checklist for confirming complete replication, not selective assessment (MANDATORY) |
| `reading_summary.md` | Paper physics, complete parameter mapping, replication plan (MANDATORY) |
| `pilot_gate_report.md` | What was done, quantitative results, updated confidence, remaining gaps (written AFTER calculations, preserving Phase 1 verdict separately) |
| Calculation artifacts | In subdirectories within your workspace |
| `comparison_*.png` | Quantitative comparison figures |

## Begin

First, `ls` the pilot directory to determine your session number. Create `pilot_gate_NN/`. Read `PILOT_HOUSE_RULES.md`, then read ALL prior `session_3_reproduce_*/reproduction_report.md`, `pilot_gate_*/pilot_gate_report.md`, and `pilot_reflect_*/reflect_report.md` (if any exist), and 
`pilot_reflect_II_*/reflect_II_report.md` (if any exist). Then read `program_selection.md`. Write your confidence verdict BEFORE touching any calculation. The production stage inherits your assessment -- if you say HIGH and it's not, production builds on a false foundation.
