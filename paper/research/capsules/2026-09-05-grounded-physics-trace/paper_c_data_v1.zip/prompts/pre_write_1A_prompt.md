# Task: Pre-Write Step 1A -- Data Scan and Literature Deep Dive

You do not run calculations or draw figures. You read, search, and write markdown deliverables. Create `paper/` in the run directory.

## What to read

1. `pre_production/tentative_manuscript_story.md` -- the storyline seed. Read to understand the paper's direction and what quantities matter.
2. `pre_production/final_literature_review.md` -- prior literature survey. A starting point, not exhaustive.
3. `production/production_report.md`, `production/production_reflect_report_*.md`, `production/open_questions.md` -- what was computed, what has caveats.
4. `production/figures/` -- look at existing production figures to understand what the data looks like.
5. `pre_production/pilot_final_report.md` -- skim for pilot results that enter the paper.

## Phase A: Data scan

Scan all production outputs. Do not recompute -- catalog. For each quantity production delivered:
- What is the number?
- Is it converged? What convergence level? Is it gauge-stable? Do symmetry checks pass?
- What caveats or uncertainties exist?
- Where is the raw data file?
- Is there an existing figure? If so, load and read the figure. What does the figure show? Does it show the expected trend? Does it show good data quality or it looks more like noise?

Write `data_inventory.md`. Be honest about quality.

## Phase B: Literature deep dive

The purpose of this literature search is to serve the paper. Start from `tentative_manuscript_story.md` and the real data you just scanned -- together they define the direction. Search for all papers relevant to this direction.

### B1: Comprehensive bibliography

For every relevant paper you find (target 35-45 references):

- **Fetch the abstract.** Copy it verbatim. Do not paraphrase from memory. If `final_literature_review.md` lists a paper without a verbatim abstract, re-fetch it.
- **Read the figure captions.** For each figure: what quantity, what axes, how many panels, what each panel shows.
- **Classify:** background, competing method, experimental comparison, adjacent computation, methodological reference.

Build `bibliography.bib` as you go. Every entry must have a verified DOI or arXiv ID.

### B2: Adjacent paper deep reading

Identify at least 3 papers most closely adjacent to ours. PRB papers are preferred because we will be writing PRB style paper later. The purpose of this task is to learn from published literature how to write a scientific paper. **These must be published journal versions.** If you don't have the PDF, stop and ask the user to download it -- give them the DOI and where to put it.

For each adjacent paper, **read the full main text -- every word, not skimming.** Then skim the SI to understand the main/SI split. Look at every figure.

Write a detailed reading report in `literature_notes.md` for each:
- **Paper structure.** How is it organized? What are the sections? How long is each? Where do methods go, where do results start? How is the argument built from section to section? What is the storyline?
- **Argument chain.** How does the paper go from "we computed X" to "this means Y"? What are the logical steps? What supporting evidence does each claim rely on? What physical quantities the paper used to support its results?
- **Every figure.** What type (line plot, heatmap, multi-panel, inset)? What data does it show? Why is this figure in the paper -- what role does it play in the argument? How many figures in main vs SI, and what determined the split?
- **Scope.** How many materials, how many observables, how much convergence detail in main vs SI?
- **Caveats and limitations.** How does the paper handle what it can't do or doesn't know?
- **What we can learn** for our paper's structure and storytelling.
- **Language.** What is the tone and language of the paper? How do authors make claims of different confidence levels?

### B3: Positioning

Where does our paper fit? What is genuinely new? Write a positioning statement.

## Deliverables

| File | Content |
|------|---------|
| `paper/data_inventory.md` | Per-quantity: number, quality, caveats, raw data path |
| `paper/literature_notes.md` | All abstracts verbatim, all figure captions, 3+ adjacent paper full reading reports, positioning |
| `paper/bibliography.bib` | 30-40 verified entries with DOIs |
