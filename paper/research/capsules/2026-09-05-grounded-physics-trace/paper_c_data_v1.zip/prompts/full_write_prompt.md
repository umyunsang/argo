# Task: Full Write -- Draft the Manuscript

**Target journal: Physical Review B (Regular Article).**

## Before anything else

1. **Look up PRB submission requirements.** Search online for the current REVTeX template, formatting guidelines, abstract word limit, figure requirements, and any author instructions. Download the template.
2. **Set up and test compile.** Copy the template into `paper/draft/`, add a test figure, compile to PDF. Confirm the toolchain works before writing a single word of content.

## What to read

1. `paper/detailed_outline.md` -- your section-by-section blueprint.
2. `paper/figure_disposition.md` -- which figures, where, main vs SI.
3. `paper/figure_captions.md` -- draft captions to refine.
4. `paper/figures/` -- **look at each figure** before writing the section that discusses it.
5. `paper/bibliography.bib` -- verified citations.
6. `paper/literature_notes.md` -- adjacent paper reading reports. **Read the structure and style analyses carefully.** These are your writing models: how PRB computational physics papers in this subfield phrase arguments, handle caveats, connect sections. Match their conventions.
7. `paper/data_analysis.md` -- verified numbers and caveats.
8. `production/open_questions.md` -- documented uncertainties.

## How to write

Write directly in LaTeX in `paper/draft/`. Produce:
- `paper/draft/manuscript.tex` -- main text.
- `paper/draft/supplementary.tex` -- SI.

Use `\bibliography{bibliography}` and `\includegraphics` referencing `paper/figures/`.

### Writing principles

**Lead with physics, not method.** Results section interprets; methods section enables reproduction.

**Every claim has evidence.** No unsupported statements.

**Uncertainties: honest but not excessive.** State essential caveats where they matter for interpretation. Do not flood the narrative with concessions on every number. If a caveat is not essential to understanding the result, put it in SI or drop it. The paper should read as a confident presentation of what the data shows, with honest acknowledgment of what it doesn't. **It is a publication, not a progress report.**

**Learn from the adjacent papers.** The reading reports in `literature_notes.md` describe how the best PRB papers in this field structure arguments. Use them as models.

**Figures drive the narrative.** Introduce, describe, interpret.

**No deferrals. No blanks.** Every section complete. Every citation present. Every figure referenced. If something is unclear, resolve it now. If irresolvable, drop it.

### Author block

Use this exact author block:

```latex
\author{Claude Opus}
\noaffiliation
\author{Anonymous Author}
\email[Contact author: ]{anonymous@example.org}
\affiliation{Department of Physics, Anonymized for double-blind review}
```

Do not list any institution, company name, or email for Claude Opus. Do not put "Anthropic" on the author byline.

**Methods section must include a System Specification subsection. Leave no placeholder.**

> The first author of this paper, "Claude Opus," refers to an autonomous instance of the Claude Opus model (Anthropic), accessed via the Claude Code CLI interface during [month year of execution]. The agent has no institutional affiliation. It operated with direct shell access to invoke Quantum ESPRESSO without intermediate orchestration framework. The full pipeline design, prompt architecture, and decision traces are discussed in a companion paper [cite companion].

**Author Contributions** (after Acknowledgments, natural language, leave no placeholder):

> Claude Opus conducted the literature research, conceived the research direction, selected target materials, designed and executed all [specify calculation types, e.g., density functional theory, Wannier interpolation, Berry-phase post-processing] calculations, performed [specify key analyses, e.g., symmetry tests, convergence studies, finite-difference tensor extraction], analyzed the results, produced all figures, and wrote the manuscript. Anonymous Author provided computational infrastructure (local workstation), designed the autonomous-execution pipeline, supervised the agent sessions, and performed a final factual accuracy check before publication. No human input was provided on the research question, methodological choices, parameter selection, intermediate decisions, analysis, interpretation, or drafting.

Do not add philosophical commentary about AI authorship anywhere in the paper.

### Iterate writing

After writing your draft, stop and take a step back, and reflect adversarially and critically on your own writing, from the view point of a fresh reader. Think about the story. Look back on literature landscape. Look back on how previous literature was written (the storyline, language, figures, arguments, logic chain etc.). Then look back at your draft with fresh eye, as if you were new reader. Is everything clear and easy to understand? Is the language proper? Is the connection between paragrphs and sections smooth? Is the logic solid? Any problem you find while writing? Think carefully, how to improve the draft towards scientific publication quality. General consideration: title, abstract and figures are the first thing reader reads, then introduction, then the main text, then SI. Iterate high stake parts with extreme care, and ensure coherence within the whole paper.

Iterate the draft at least **two** times. Each time, re-read the whole draft (because you might have modified things incrementally but lost sight of the whole picture), do the above critical thinking process as if you were a fresh, curious yet critical reader, first write `paper/draft/self_draft_reflection_NN.md` (NN is next number, depending on the iteration) about what problems of the paper (both main text and SI) you found if you were a fresh reader, and how you plan to mitigate that (full rewrite of whole paper? Rewrite certain parts? Polish some language? etc.). You are an agent with full control, so think deeply and find all problems yourself.

### Iterate pdf
After finishing drafting, compile to PDF. Read the compiled output visually. Fix layout issues, overfull boxes, figure placements, missing references.Do you find any problem with figures, like overlapping legend/axes labels? Almost always, there will be some problem of the figure. You can re-generate figures using the scripts and adjust/fix/font layout according to the paper.

Iterate until the PDF looks like a published PRB article. The deliverable is a compiled, clean PDF -- not just a .tex file. First iterate main text to publication quality. Then iterate SI. The goal is that one can directly submit main + si pdf for publication. Scrutiny with magnifying glass since this will be the last step before submission. No defer, no to-do, no "left for user to decide/to add". You have full control and you need to ship the final pdfs with scientific rigor, impact and highest quality possible.

## Deliverables

| File | Content |
|------|---------|
| `paper/draft/self_draft_reflection_NN.md` | Self-reflection reports, at least **two** |
| `paper/draft/manuscript.tex` | Complete main text |
| `paper/draft/supplementary.tex` | Complete SI |
| `paper/draft/manuscript.pdf` | Compiled, clean PDF |
| `paper/draft/supplementary.pdf` | Compiled, clean PDF |