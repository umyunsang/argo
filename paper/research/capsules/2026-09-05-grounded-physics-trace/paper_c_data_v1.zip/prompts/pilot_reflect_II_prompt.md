# Task: Pilot Reflect II -- Self-Validation Strategy and Production Plan

You do not run any calculations. You do not modify anything outside your own workspace. Create `pilot_reflect_II_NN/` (ls pilot/ for the next number).

## Context

Multiple rounds of pilot_gate and pilot_reflect sessions have been run. The goal is no longer to fit a specific number from a specific paper. The goal is to understand the physics behind your numbers, identify what is still missing to support them, and plan the remaining work before production.

## Step 1: Study the published papers -- figures AND physics logic

Find every paper that was reproduced or referenced across all reproduce and pilot_gate sessions. Use the published version with SI if available (check `reference_papers/` folders in prior pilot_gate sessions first; those have publisher PDFs, SI, and datasets). For each paper:

**Physics logic chain.** How does the paper explain the physical mechanism behind its headline quantity? What produces this quantity at the microscopic level? What orbitals, interactions, or symmetry-breaking mechanisms are responsible? How does the paper connect the mechanism to its computed result? Quote the key sentences verbatim -- the ones where the authors explain WHY a quantity has the value it does, not just WHAT the value is. These logic chains tell you what physical understanding is required to interpret and defend a result.

**Figures.** Look at every figure in main text AND SI. For each figure:
- What physical quantity is displayed, and what is it plotted against (energy, k-point, strain, doping)?
- What does this dependence reveal about the mechanism? (e.g., a k-resolved plot shows WHERE in the Brillouin zone a quantity originates; an energy-resolved plot shows WHICH bands contribute)
- How does this figure support or diagnose the headline quantity? Could it reveal why a calculation succeeded or failed?
- Is this figure related to any quantity our pipeline computes?

Write `paper_figure_analysis.md`: paper by paper, figure by figure, logic chain by logic chain. This is a deliverable -- not a mental exercise.

## Step 2: Review everything in pilot/

Read all `reproduction_report.md`, `pilot_gate_report.md`, `pilot_gate_verdict.md`, `pilot_reflect_*/reflect_report.md`, and `session_1_prior_work/program_selection.md`.

**Think critically.** Prior agents may lack the global view you now have. They may have overlooked details or drawn wrong conclusions. Any doubt -- check raw data (calculation outputs, logs, numbers) rather than trusting a prior agent's verdict or claim.

What numbers do we have? What recipes work? What sensitivities have we discovered? What remains unresolved? Write a concise summary grounded in raw data.

## Step 3: Gap analysis -- what do we need for a paper?

Imagine writing a paper from our existing pilot data. Compare against the papers analyzed in Step 1:

- For each paper's physics logic chain: does our work include the supporting quantities and analyses that chain requires? If a paper explains a quantity through a specific mechanism and supports that explanation with a specific type of analysis (e.g., k-resolved decomposition of a Brillouin-zone integral, orbital-projected band structure, energy-dependent integration), have we done the equivalent? If not, flag it.
- What figures and analyses did those papers include that we have NOT done? For each: essential (paper rejected without it), important (strengthens argument), or nice-to-have?
- Are there quantities we computed but never validated with a diagnostic that would reveal whether the physics is correct?
- Are there parameter sensitivities we discovered but never explained -- we know THAT something is sensitive, but not WHY? Is there an underlying physical quantity whose analysis would reveal the mechanism?

## Step 4: Plan remaining pilot_gate sessions

Write a concrete plan for closing the gaps from Step 3. The goal is **understanding**, not expanding scope. Prioritize:

1. **Big gaps that block production.** If production requires a pipeline step that has never been validated, or a quantity that was computed but is physically unsupported, this must be addressed. New calculations are justified here.
2. **Supporting analyses for existing results.** We have numbers from prior sessions -- what analyses and figures would make them defensible? The goal is to understand why the pipeline gave the results it did, not to add more calculations for their own sake. If we discovered a sensitivity, compute the diagnostic that explains it.

Each planned session should be:
- A specific computation or analysis with a clear deliverable (a figure, a convergence study, a validated recipe)
- Sized to fit within a 6-10h pilot_gate session (one task per session)
- Ordered by priority (production blockers first)

For each planned session, specify:
- What to compute and why (tied to a specific gap from Step 3)
- What figure(s) to produce
- What analysis to write -- load and inspect every figure you produce, check if the physics makes sense, write what you learned. A figure without interpretation is not a deliverable.
- What the success criterion is
- What to do if unexpected results appear (allowed: follow up with a targeted test within the same session to understand the physics; not allowed: scope expansion into a new research direction)

After these pilot_gate sessions are completed, a final summary session will consolidate all results into an interim report and produce a detailed production plan.

## Deliverables

| File | Content |
|------|---------|
| `paper_figure_analysis.md` | Paper-by-paper: figure inventory (quantity, dependence, what it reveals, relation to our pipeline) + physics logic chain verbatim quotes |
| `reflect_II_report.md` | Step 2 critical summary + Step 3 gap analysis + Step 4 packaged session plan |

If a paper is behind a paywall or download fails, pause and ask the user to download it. Tell them the paper ID, where to put the PDF, and say "continue."
