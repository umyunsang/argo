# Task: Pre-Write Step 1B -- Data Analysis, Storyline, and Publication Figures

**Target journal: Physical Review B (Regular Article).** Look up PRB's formatting requirements, figure specifications, and length guidelines yourself before starting figures.

Create your workspace in `paper/` (created by Step 1A).

## What to read

1. `paper/data_inventory.md` -- what data exists and where.
2. `paper/literature_notes.md` -- adjacent paper reading reports: their structure, argument chains, figure designs, scope. **This is your primary reference for how to organize a paper and design figures in this field.**
3. `paper/bibliography.bib` -- citations available.
4. `pre_production/tentative_manuscript_story.md` -- storyline seed. A starting reference point, not gospel.
5. `production/production_report.md`, `production/production_reflect_report_*.md`, `production/open_questions.md` -- results with caveats.
6. `production/calculations/` and `production/figures/` -- raw data and existing diagnostic figures.

## Phase 1: Deep data analysis

Go through every quantity in `data_inventory.md`. **Think critically -- do not trust prior agents' claims. Check raw data yourself.**

- Load raw data files. Verify numbers match what production reports claim.
- Rewrite analysis scripts to be self-contained and reproducible. Put in `paper/scripts/`. Someone running `python paper/scripts/analyze_XYZ.py` should get the same numbers.
- Cross-check: where the same quantity was computed in different sessions, different gauges, or different meshes -- are they consistent? **Carefully check the error bar, including all plotted quantities.** Is the error bar inconsistent across one dataset (one point has significantly larger error bar than others)? Is the error bar as large as the signal or trend? If any of the problem exists, DO NOT HANDWAVE AWAY, DO NOT TRY TO JUSTIFY IT. You must think critically and deeply. Maybe the window of averging is wrong and should be better shifted to give smaller variation? Diagnose and do data analysis. You are a careful researcher and must catch all details. If there is subtle data integrity issue, demote to SI or drop completely.
- Form your own assessment of each quantity's reliability.
- If you cannot flag and solve any problem (you feel that everything is correct), you must be ignoring something. Go through everything and dig through them again.
Write `paper/data_analysis.md`: per quantity, verified number with provenance, consistency checks, your assessment.

## Phase 2: Storyline

You now have data (Phase 1) and literature (Step 1A `literature_notes.md`). Write the storyline.

Start from `tentative_manuscript_story.md` -- but treat it only as a reference point. The real storyline comes from what the data actually shows and how the adjacent papers in this field tell their stories. Learn from the literature how to structure the argument: what comes first, how claims build on each other, how figures drive the narrative. Do not copy any paper's structure -- but let the best ones inform yours.

**Write `paper/detailed_outline.md` -- this is an anchor document.** Write it to file. Structure:
- Central message (one sentence).
- Section-by-section: what each section argues, what evidence, what citations.
- Per-paragraph for Results and Discussion: the claim, the supporting figure/number, the citations.
- Main text vs SI split with rationale.
- What to drop: if a result is not decisive, looks messy, or risks opening a can of worms without adding to the main message -- consider dropping it or moving it to SI. How does the storyline adapt?

**Write `paper/figure_disposition.md`.** **THIS IS THE MOST IMPORTANT TASK:** figures are the most important way to convey message. As general guideline, existing figures are useful starting points, but inheriting them directly here **will ALWAYS result in crappy publication**. Always re-think critically with respect to story telling: only plot the panels that convey the message. Delete unrelevant details or move them to SI. Look at how many panels per figure and how many figures in total are there in previous literature. Less is more. Focus on visually good ones and scientifically important ones. For each figure:
- Main text or SI (or drop).
- What panels, what data source, what the figure demonstrates.
- Which adjacent-paper figure (from `literature_notes.md`) serves as a style or scope reference.
- If you use the same panel arrangement from previous figures, most probably you did not think carefully. If you point all figures as a whole to previous figures, the resulting paper will certainly be bad. Rethink. Imagine the referee/reader will only read the figures. Will then understand the story? Are you missing some intermediate physical plot like bands, upon which later plots build on? Are you stuffing unrelated intermediate result as panels that will distract the readers? Do you really need so many panels in one figure? Which of them are necessary?

Take your time in phase 2. It lays foundation of the paper, so a careless phase 2 will directly result in the failure of the whole project.

## Phase 3: Publication figures

Draw each figure in `figure_disposition.md`. Follow PRB style conventions.

For each figure:

1. **Write the script** in `paper/scripts/make_figN.py`. Self-contained, reproducible.

2. **Draw and inspect ADVERSARIALLY AND CRITICALLY. EXTREMELY IMPORTANT.** Load the output and look at it carefully (both png loading and raw data loading). Is the trend clear? Is the error bar consistent across data points or is error comparable to signal or trend (if not, what's the cause, is it for example something like wrong averaging window causing large deviation?)? Verify EVERY relevant claim you have in the paper or caption against the figure visually. If you claim plateau, is it really plateau, or it is better shifted to real plateau position? Are all labels and legends correct and make physically sense? More importantly, would a referee understand it? Is there redundant information that should better be moved to SI or dropped? Write down the justification of the existence of each and every panel.

3. **Iterate** until it meets the standard of the published papers you read in Step 1A. Make figure, load and check visually the png carefully, identify problems (like typo, overlapping things, font problems etc), and iterate.

4. **Write a draft caption** in `paper/figure_captions.md`.

5. **After each figure, re-read `detailed_outline.md`.** Does seeing the actual figure change anything? Should something move to SI or be dropped? If the figure shows the data is noisier or less decisive than expected -- update the storyline now, don't defer.

After all figures are done, look at them together as a set. Consistent style? Coherent visual narrative? Final check of `detailed_outline.md` and `figure_disposition.md`. **IMPORTANT: ITERATE IMAGES USING LOWER RESOLUTION TO SAVE CONTEXT, AND ONLY OUTPUT HIGH RESOLUTION PUBLICATION QUALITY (both as pdf and as 600dpi png) IN THE END.** 

## Deliverables

| File | Content |
|------|---------|
| `paper/data_analysis.md` | Per-quantity verified numbers, consistency checks, reliability assessment |
| `paper/detailed_outline.md` | Section-by-section outline, main/SI split (iterated during figure drawing) |
| `paper/figure_disposition.md` | Per-figure: main/SI/drop, panels, data source, style reference (iterated) |
| `paper/figure_captions.md` | Draft captions |
| `paper/figures/` | All publication figures |
| `paper/scripts/` | Reproducible analysis and figure scripts |
