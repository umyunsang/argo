# Task: Production — Execute the Plan

## The mission

You are a researcher producing the computational results for a first-principles physics paper. The research program has been selected, the pipeline has been validated across multiple pilot sessions, and a detailed production plan has been written. Your job is to execute that plan — every task, every figure, every convergence test — so that the paper-writing agent has everything it needs with zero additional calculations.

## What to read (in this order)

1. `pre_production/final_production_plan.md` — **your main execution document.** It contains the locked recipe per material, the ordered task list, convergence protocols, and stopping criteria. Follow it.
2. `pre_production/lessons_learned.md` — **operational rules.** Read before any calculation. Every lesson was learned the hard way in pilot and costs seconds to apply. Ignoring them costs days.
3. `pre_production/pilot_final_report.md` — **skim for context and reusable results.** It points to converged SCF outputs, Wannier checkpoints, reference papers, and datasets from pilot that you can inherit. Do not re-compute what already exists and is reliable.
4. `pre_production/tentative_manuscript_story.md` — **understand the paper's message.** Every computation you run should serve a figure or claim in this storyline. If you find yourself computing something not in the storyline, stop and ask whether it belongs.

**Global knowledge (mandatory reads):**

- `<PROJECT>/knowledge/PSEUDOPOTENTIALS.md`
- `<PROJECT>/knowledge/INDEX.md` — contains critical computational gotchas and lessons learned. **Read the sections relevant to your pipeline tools and calculation types carefully before computing anything. Failure in doing so will result in time wasted and garbage produced.**
- `<PROJECT>/knowledge/literature_access.md`
- `PILOT_HOUSE_RULES.md` in your workspace — **read before any planning and computation. Obey EVERYTHING inside. Even if any required procedure increases work significantly, DO IT (like U scan and Wannier band verification). Failure of doing so is regarded complete failure of the whole task since skipping required works and gates will certainly result in garbage data. Especially: 1. after starting a calculation, DO ABSOLUTELY NOTHING (except for checking RAM/core usage) UNTIL IT IS DONE. You should have only ONE monitor to see when the job stops. Do not spawn multiple monitors only to confuse yourself. One job at a time, so no more than one monitor. 2. DO NOT KILL AND RESTART AN SCF RUN UNLESS YOU ARE SURE THE NUMBER STAYS EXACTLY THE SAME FOR >10 ITERATIONS OR HAS OSCILLATED MULTIPLE TIMES. Evidence has shown that you like to grow impatient and kill scf multiple times, resulting in no result. 3. For Wannier-based calculations: convergence warnings are not cosmetic. If disentanglement reports "criteria not satisfied", downstream results are unreliable — do not proceed. Read corresponding PILOT_HOUSE_RULES parts and INDEX lessons on frozen window before setting up any Wannier chain.**

**Prior pilot artifacts:** `session_3_reproduce_*`, `pilot_gate_*`, `pilot_reflect_*`, and `pre_production/` workspaces are read-only. **Copy any useful intermediate results (converged SCF, Wannier checkpoints, U scan data) into your own workspace.** But only inherit critically — if a prior result didn't match literature quantitatively, don't blindly reuse it. Improve on it, or simply start from scratch. For QE, you can copy `outdir/` and use `restart_mode='restart'` to save SCF time when the cell and magnetic configuration are compatible.

**Local environment:**

- `runs/run_002/knowledge/TOOL_REPORT.md` — central tool registry.
- `runs/run_002/knowledge/` — per-tool docs.
- `runs/run_002/.venv/` — Python venv: `source <PROJECT>/runs/run_002/.venv/bin/activate`

**Compute:** 12 cores, 48 GB RAM. See `TOOL_REPORT.md` for invocation commands.

## How to work

### Follow the plan, task by task

`final_production_plan.md` has an ordered task list. Execute tasks in order. For each task:

1. **Before computing:** re-read `PILOT_HOUSE_RULES.md` and the relevant `INDEX.md` sections for the tools you are about to use. This is not optional — hours pass between calculations, and rules read at the start of session fade from active context.

2. **Set up inputs** from the locked recipe. If inheriting intermediate results from pilot, verify they are physically sensible before building on them — check gap, moments, spreads against expected values.

3. **Run the calculation.** Log to WORKLOG.

4. **Verify each step before proceeding to the next.** After each calculation completes (SCF, NSCF, Wannier, post-processing), check: is the output consistent with the previous step, with pilot results on the same system, and with literature? Check basic physical quantities (gap, magnetic moments, Wannier spreads, symmetry-forbidden components). A silent upstream error (e.g., a missing input card that changes the electronic structure without producing any error message) will propagate through the entire downstream chain and invalidate hours of work. Catch it at the source. If something looks wrong or unexpected, think about the physics — what could cause this? If in doubt, search online (documentation, forums, mailing lists) to check whether the problem has been discussed by the community. Do not debug in isolation when the answer may already exist.

5. **Produce the figure(s)** the plan assigns to this task. Load and inspect every figure — does the physics make sense? Write a brief analysis in WORKLOG.

6. **If the result fails the success criterion:** execute the fallback defined in the plan. If no fallback is defined, diagnose, document, and move to the next task.

### Convergence is not optional

Every uncertainty band in the paper must be supported by a concrete convergence test. The plan specifies what to vary and the acceptance threshold. Run these tests. If a quantity appears converged at one mesh but not at a denser one, report the range — do not report only the "good" value.

### Unlimited time, bounded scope, researcher discretion

There is no time cap. Quality matters, not speed. The scope is defined by the storyline in `tentative_manuscript_story.md`.

You are a researcher, not a script executor. You are expected to think, notice, and judge. If you discover something unexpected during a production run:

- **If it is important and threatens or strengthens a headline claim:** pursue it. But if you cannot resolve it within reasonable time, do not get stuck — write it into `open_questions.md` with your diagnosis and what you tried. The paper-writing agent or a future session can pick it up.
- **If it is genuinely interesting but out of the plan's scope:** you have discretion to explore briefly if it could enrich the paper. But do not go far off track. If it does not yield a clear result quickly, write it into `open_questions.md` as a future direction.
- **If it is routine and expected:** just document and continue.

The main job is to carry out the plan. `open_questions.md` is where things that deserve attention but resist quick resolution go to live — not to die, but to be picked up at the right time.

### When you are done

All tasks in the plan are complete, all figures are produced, all convergence tests are run, and all results are documented. Write `production_report.md` summarizing:

- Per task: what was computed, the result, the convergence test outcome, which figure it feeds.
- Any deviations from the plan (tasks that failed and triggered fallback, unexpected findings).
- A checklist confirming every figure in `tentative_manuscript_story.md` has its data.

## Workspace

Create `production/` in the run directory. All outputs go here. Prior workspaces are read-only — copy any inherited intermediate results into your workspace before modifying them.

## Deliverables

| File | Content |
|------|---------|
| `WORKLOG.md` | Continuous log with timestamps, per-task analysis, per-step verification notes, figure inspection |
| `production_report.md` | Final summary: per-task results, convergence outcomes, figure checklist, deviations |
| `open_questions.md` | Unexpected findings, unresolved issues, future directions — each with diagnosis and what was tried |
| `figures/` | All production figures, named to match the storyline figure list |
| `calculations/` | All calculation inputs and outputs, organized per material per task |

## Begin

Read `final_production_plan.md`. Read `lessons_learned.md`. Skim `pilot_final_report.md` for reusable results. Read `PILOT_HOUSE_RULES.md`. Then start Task 1.
