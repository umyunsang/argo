# Task: Tooling Resolution and Local Knowledge Base Construction

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. The final paper must make a clear and substantial scientific contribution.

## Your task

Prior agents have selected a research program and reproduction-target papers. Your job is to install and validate every tool that downstream reproduction and production agents will need, in an isolated environment, with everything ready-to-use and documented.

This is a **tooling and validation task.** You:

1. Set up an isolated Python venv local to this run.
2. For every tool the reproduction targets and the program need: install (parallel version), benchmark parallelism, **download and run the tool's official tutorial/example**, replicate a known quantitative result, and document.
3. Build a single central report listing every tool, where it is, how to use it, and where example calculations live.

Tool scope: install whatever is needed to reproduce the target papers' computations and to execute the program's pipeline on the target system. If a paper used a code we do not have (e.g., VASP), determine whether our toolchain can produce equivalent calculations. Do not accept "we'll skip this" for any tool the final paper depends on.

**Boundary with Session 3:** Your job is to validate that tools **work** (install, run, produce correct output on simple test systems). Session 3 agents validate that tools give **correct physics on relevant systems** by reproducing the target papers. Do not replicate the reproduction target papers yourself — that crosses into Session 3 territory and wastes time. Your validation should use simple, fast, well-known systems (Si, Fe, NaCl, etc.) as smoke tests.

## Input

**Prior-stage outputs (read in full):**

- `program_selection.md` — which research program was selected and why. Understand the full production pipeline.
- `prior_work/reproduction_targets.md` — selected papers with reproduction guidance. Read to understand what tools each paper used.
- `prior_work/markdown/<id>.md` for each reproduction target — read full-text to understand what calculations the reproduction agents will need to run.

**Knowledge:**

- `<PROJECT>/knowledge/PSEUDOPOTENTIALS.md`
- `<PROJECT>/knowledge/INDEX.md`
- `PILOT_HOUSE_RULES.md` in your workspace — **read before any computation.**

**Compute environment:**

- 12 cores, 48 GB RAM.
- QE binaries: `<PP_ROOT>
- Other engines: `<PP_ROOT> (inspect for ABINIT, Yambo, ORCA, etc.)
- Pseudopotential libraries: `<PP_ROOT>
- Global Python venv: `<HOME>/qe-paper-replication/.venv/` — **read-only, do not modify.**
- Full internet access for downloading tools, examples, reference data.

**Filesystem discipline:**

- Corpus and global knowledge directories are read-only. Global Python venv is read-only.
- All work goes under `runs/run_002/`.
- Local venv, tools, examples, knowledge all live under `runs/run_002/`.

## Workflow

### Step 1: Isolated local environment

```bash
cd <PROJECT>/runs/run_002/
python -m venv .venv
source .venv/bin/activate
```

Replicate the global venv's package set as baseline:

```bash
<HOME>/qe-paper-replication/.venv/bin/pip freeze > /tmp/global_packages.txt
pip install -r /tmp/global_packages.txt
```

**From this point on, all installations go into this local venv or under `runs/run_002/tools/`.**

### Step 2: Tool requirement analysis

Read the reproduction targets and program_selection.md. For each paper and for the production pipeline, list what codes are needed, what calculations will be run, and whether our existing toolchain covers them.

Produce `tool_requirements.md`: per-tool entry with name, why needed, which paper/stage requires it, available or needs installation.

### Step 3: Tool installation, benchmarking, validation, documentation

For every tool, follow `PILOT_HOUSE_RULES.md` §3:

1. **Install the parallel version.**
2. **Benchmark parallelism (new tools only).** For newly installed tools, compare np=6 vs np=12 on a small job. Skip for established tools (QE, Wannier90, ABINIT) — default to np=12.
3. **Download and run the tool's official tutorial/example.** Find them, download them, run them, verify the output. Record the tutorial source (URL), expected result, and actual result.
4. **Quick validation on a simple known system.** Run on a well-characterized system (Si, Fe, NaCl — simple, fast) and compare at least 3 quantities to literature. This is a smoke test taking minutes, not a research calculation. **Do not replicate the reproduction target papers — that is Session 3's job.**
5. **Write a knowledge document** in `runs/run_002/knowledge/<TOOLNAME>.md`: install path, invocation command, validation results, known gotchas, example directory.

This applies to compiled codes, Python packages, and anything downstream stages rely on. **For existing tools (QE, Wannier90, etc.):** comprehensive knowledge documents already exist in the global knowledge base (`<PROJECT>/knowledge/INDEX.md` — read it). These will be passed to downstream agents. Your job is to go further than the global docs on topics relevant to the selected program: find and run additional official tutorials/examples specific to the calculation types the program needs, achieve tighter convergence benchmarks on representative systems, and document these in `runs/run_002/knowledge/` as supplements. New tools not in the global knowledge base need full knowledge documents from scratch.

### Step 4: Tool sufficiency check

Re-read reproduction targets and program_selection.md. For each:

- Can our toolchain reproduce each paper's quantitative claims? Note tool-to-calculation mapping.
- Can our toolchain execute the production pipeline? List tool-to-stage mapping.
- Apply forward-looking provisioning (house rules §12): install tools needed by production even if not needed by reproduction.

If a tool installation fails, document the failure and propose what reduced scope becomes feasible without it.

### Step 5: Central tool report

Write `runs/run_002/knowledge/TOOL_REPORT.md`:

- Local venv location and activation.
- Per-tool table: name, purpose, binary path, knowledge doc path, validation status, example directory.
- Pipeline coverage: for each calculation type the program needs, which tool handles it.
- Reproduction-target tool mapping: for each target paper, which tools its reproduction agent will use.
- Known limitations and workarounds.
- Where example calculations live: `runs/run_002/tool_examples/<TOOLNAME>/`.

## Deliverables

| File | Content |
|------|---------|
| `WORKLOG.md` | Continuous log |
| `runs/run_002/.venv/` | Isolated Python venv |
| `runs/run_002/tools/` | Compiled tool binaries |
| `runs/run_002/tool_examples/<TOOLNAME>/` | Verified examples per tool (including official tutorials) |
| `runs/run_002/knowledge/<TOOLNAME>.md` | Knowledge doc per tool |
| `runs/run_002/knowledge/TOOL_REPORT.md` | Central report |
| `tool_requirements.md` | Tool requirement analysis + sufficiency notes |

## Begin

Read `PILOT_HOUSE_RULES.md` first, then `program_selection.md` and `reproduction_targets.md`, then the target paper full texts. **No time limit, no token limit.** Every shortcut in tool validation becomes a silent bug downstream. Take the time this task deserves.
