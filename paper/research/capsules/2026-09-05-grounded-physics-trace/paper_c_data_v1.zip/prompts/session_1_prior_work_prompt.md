# Task: Program Selection, Prior Work, and Reproduction Target Selection

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. The final paper must make a clear and substantial scientific contribution.

## Your task

Prior agents produced multiple candidate research programs (depth reports). Your job is to select the best program, map the prior work landscape, and select 3 papers for downstream reproduction that together validate the entire production pipeline.

## Input

- `depth_reports/` — multiple research programs from independent depth agents. Read all in full.
- `<PROJECT>/knowledge/literature_access.md` — APIs for literature search.
- Corpus: `<PROJECT>/corpus/` (corpus.db, markdown/, pdfs/).
- Write only in your own workspace.

## Workflow

### Phase 0: Program selection

Read all depth reports. Select the program with the best combination of:

- **Novelty**: genuine scientific gap, not incremental.
- **Feasibility**: every pipeline stage has a named open-source tool; hardware fits 12 cores / 48 GB / ~24h.
- **Tool readiness**: prefer programs where published work has demonstrated the same pipeline (same tools, same observable class, similar material class). A program where a published paper computed the same observable with the same tools on a related system is much safer than one where no such benchmark exists.
- **Reproducibility**: prefer programs with published quantitative benchmarks the pilot can validate against.

Write a brief `program_selection.md`: which program you selected, why, and why the others were not selected.

### Phase 1: Comprehensive prior work discovery

From the selected program, search exhaustively for all relevant prior work across dimensions: same material, related materials, same physics, same methodology, reviews and foundations. Use every tool in `literature_access.md`.

Write `prior_work_full.md`: comprehensive citation list (30–80 entries), each with arXiv ID or DOI, title, year, 1-line takeaway, relevance dimension, access status.

### Phase 2: Novelty recheck

Re-evaluate the program's novelty against the full prior-work list. Has the main calculation been done? Does the program need sharper differentiation?

Write `novelty_recheck.md`: assessment, red flags, recommended adjustments if any.

### Phase 3: Candidate selection (15 papers)

Select up to 15 candidates for full-text reading. Criteria: reproduction value, methodological proximity to production pipeline, coverage of uncertainty, reference-quality quantitative data.

Check full-text availability for each. Download what is accessible into `prior_work/pdfs/` and convert to `prior_work/markdown/`. For closed-access papers needing manual download, write `manual_download_request.md` with numbered list (title, DOI/URL, where to drop PDF), then **stop** and tell the user: "Manual download required. See `manual_download_request.md`. After placing available PDFs in `prior_work/pdfs/`, reply `continue`."

If all 15 are accessible, proceed without stopping.

### Phase 4: Full-text reading and final selection

Read every available candidate in full (methodology, results, figures — not just abstracts). Write a 3–5 sentence assessment per paper in `prior_work/notes/<id>.md`.

Select **3 papers** for downstream reproduction. The 3 must satisfy:

**Pipeline coverage requirement.** List every stage of the production pipeline (e.g., DFT ground state, band structure, Wannier interpolation, post-processing observable). For each stage, at least one of the 3 selected papers must exercise that stage on a real system with a published quantitative benchmark. If a production-critical stage is not covered by any of the 3, either find a paper that covers it or flag the gap explicitly — this gap is a risk the project carries into production.

**Selection criteria per paper:**
- Clear, specific quantitative claims the reproduction agent must match.
- Methodological details reported (parameters, convergence settings, code choices).
- Reproducible within 6–10 hours on 12 cores / 48 GB.

### Write `reproduction_targets.md`

For each of the 3 papers, use this structured format:

```
## Paper N: [full citation]
arXiv/DOI: [id]
Full text: prior_work/markdown/[id].md

### Why selected
[Which pipeline stages this paper validates; which uncertainty it addresses]

### Production pipeline stages covered
- [Stage name]: [what this paper demonstrates for that stage]

### Mandatory reproduction targets
Each target is a quantitative benchmark the reproduction agent MUST match.
- [ ] [Stage]: [Observable] = [published value] ± [tolerance] — [source: Table/Fig N]
- [ ] [Stage]: [Observable] = [published value] ± [tolerance] — [source: Table/Fig N]
- [ ] ...

### Scope
[Full scope or reduced scope with justification. If reduced, state what is excluded and why.]

### Time estimate
[Estimated wall time for reproduction on 12 cores / 48 GB]
```

After the 3 papers, include:

```
## Pipeline coverage summary
| Production pipeline stage | Covered by paper # | Benchmark |
|---|---|---|
| [stage] | [1/2/3] | [value from paper] |
| [stage] | [1/2/3] | [value from paper] |
| ...     | ...     | ...                |

## Uncovered stages (if any)
[List any production pipeline stage not covered by any of the 3 papers, with risk assessment]
```

## Deliverables

| File | Content |
|------|---------|
| `WORKLOG.md` | Continuous log |
| `program_selection.md` | Which program selected and why |
| `prior_work_full.md` | Comprehensive prior work (30–80 entries) |
| `novelty_recheck.md` | Second-pass novelty audit |
| `prior_work/pdfs/` | Downloaded PDFs |
| `prior_work/markdown/` | Markdown conversions |
| `prior_work/notes/<id>.md` | Per-candidate assessment |
| `manual_download_request.md` | Only if needed |
| `reproduction_targets.md` | 3 papers with structured mandatory targets + pipeline coverage table |

## Begin

Read all depth reports first, then `literature_access.md`. **No time limit, no token limit.** The program you select and the reproduction targets you define determine whether the downstream pipeline is validated or flies blind. Take the time this task deserves.
