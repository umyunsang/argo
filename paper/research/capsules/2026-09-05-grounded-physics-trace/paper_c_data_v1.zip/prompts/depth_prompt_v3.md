# Task: Research Program Formulation

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. The final paper must make a clear and substantial scientific contribution.

## Your task

Read landscape maps from prior agents, dive deep into a promising direction, read substantial full-text literature, and formulate a research program -- a main question with sub-questions and a fallback -- that could become a publishable paper. A pilot agent will later audit feasibility; your job is to deliver a program strong enough to survive that audit.

## Input

- `breadth_reports/` -- landscape maps from prior agents. Read all in full.
- `chosen_topics.md` -- directions already chosen by prior depth agents. **Read before committing.** Your direction must differ substantially from any listed. After committing, append your direction (one line) to this file.
- **Corpus** (read-only, ~11k papers, 6 months): `corpus/title_list.md` (cat in full), `corpus/corpus.db` (SQLite), `corpus/markdown/<id>.md`, `corpus/pdfs/<id>.pdf`. Path: `<PROJECT>/corpus/`.
- **Internet access** for novelty audit. Read `<PROJECT>/knowledge/literature_access.md` first for structured APIs (arXiv all-time, Semantic Scholar, OpenAlex, Crossref, Elsevier TDM).
- Write only in your own workspace.

## Constraints

**Hardware**: 12 cores, 48 GB RAM, ~24h production compute. **Toolchain**: DFT, DFPT, TDDFT, GW, Wannier interpolation, ballistic transport -- standard first-principles methods assumed available. Do not exceed this ecosystem.

**Software feasibility gate.** For each simulation stage in the proposed pipeline (not analysis or plotting), you must be able to name a specific existing open-source tool or package that performs it. If a stage cannot be done by a named tool and would require writing custom simulation code -- even if the underlying formulas are well-documented -- that stage is methodology development, not pipeline execution. The scientific contribution should be in the physical insight, not the computational method.

## Workflow

This is an **iterative** process, not a linear one. You explore multiple candidates and screen them before committing deeply to one.

**Stage 1 -- Candidate generation.** Read breadth reports and `chosen_topics.md`. Identify 2--3 candidate research directions (different from any in `chosen_topics.md`). For each candidate, write a brief sketch: one-paragraph description + the computational pipeline as a list of stages. Do not deep-read literature yet.

**Stage 2 -- Feasibility screen.** For each candidate's pipeline, apply two gates:

- **Hardware gate:** Can each stage plausibly complete within 24h on 12 cores / 48 GB? Are the system sizes reasonable?
- **Software gate:** For each simulation stage, name the specific open-source tool that performs it. If any stage has no named tool and would require custom simulation code (constructing Hamiltonians, implementing solvers, deriving formulas from papers), the candidate fails.

If at least one candidate passes both gates -> proceed to Stage 3 with the best one.

If all candidates fail -> **return to Stage 1** with fresh candidates. You may return up to twice (3 rounds total, screening 6--9 candidates). After 3 rounds with no viable candidate, simplify the most promising candidate from all rounds until it passes both gates.

**Stage 3 -- Commit + deep reading.** Select the best candidate that passed both gates. Append your direction to `chosen_topics.md`. Now dive deep: read full-text papers, develop main question + sub-questions + fallback.

**Stage 4 -- Novelty audit.** The corpus covers only 6 months. Audit every question against the broader literature using external APIs. For each question: has it been done? If partially, what is your contribution beyond it? If the direction is completely done, try the next passing candidate from Stage 2 -- or return to Stage 1 if none remain.

**Stage 5 -- Finalize.** Only a program that has passed both feasibility screen and novelty audit is finalized.

## Deliverable

A single `research_program.md`:

1. **Candidates considered** -- the 2--3 directions you screened, with pipeline sketch and feasibility outcome for each. Include dropped candidates and why they were dropped.
2. **Direction and rationale** -- which candidate you committed to, why, how it differs from `chosen_topics.md` entries.
3. **Literature foundation** -- full-text papers read, 1--2 lines each on what you took from them.
4. **Main research question** -- specific, first-principles-addressable.
5. **Sub-questions** (2--4) -- concrete enough for a pilot agent to estimate cost.
6. **Fallback path** -- if the main question fails, what salvageable story remains?
7. **Prior work + novelty** -- per question: relevant prior work (URL, title, year, 1-line takeaway) + differentiation.
8. **Computational feasibility** -- per pipeline stage: named tool, has it been demonstrated on a similar system, hardware estimate.
9. **Expected deliverable** -- what the paper would argue, one paragraph.
10. **Computational footprint** -- classes of calculation, system sizes, 24h/48GB plausibility.

## Begin

Read `chosen_topics.md`, then breadth reports. Start with candidate generation and feasibility screening -- do NOT deep-read literature until a candidate has passed both gates. **No time limit, no token limit.** The program you conceive here determines the ceiling of impact for the entire project.
