# Task: Pilot Reflect -- Analyze, Search Literature, Find Problems

You do not run any calculations. You do not modify anything outside your own workspace. Create `pilot_reflect_NN/` (ls pilot/ for the next number). Your only deliverable is `reflect_report.md`.

## Read

Everything in `pilot/`: all `reproduction_report.md`, `pilot_gate_report.md`, `pilot_gate_verdict.md`, prior `reflect_report.md`. Also `session_1_prior_work/program_selection.md`.

## Your primary task

Identify every pipeline step production requires. For each step, identify the key physical quantity. For each quantity, answer:

**What do we get? What does the literature say?**

Search broadly -- arXiv, Google Scholar, journal sites. Find published theoretical values for the same quantity. Prefer same material, then same material family, then same physics on any material. Find experiments too. Read the papers our agents tried to reproduce -- and find papers they didn't try. Follow-up papers, competing calculations, reviews.

For each quantity where our pipeline disagrees with a paper we tried to reproduce, diagnose:

- **Is it a literature problem?** Does the broader literature (other theory groups, experiments) support our value or the paper's? If multiple independent sources agree with us, the paper may be an outlier -- find a better reference to validate against.
- **Is it a methodology problem?** Did our agents use shortcuts, skip steps the paper did, use different pseudopotentials without testing alternatives? Check unit conventions, sign conventions, normalization (per atom vs per cell, Ry vs eV, etc.). If the disagreement is a constant factor, think hard about whether it's a convention mismatch before concluding it's physics.
- **Is it a pipeline problem?** If results are noisy rather than a consistent offset, that points to convergence or implementation issues, not literature disagreement.
- **Is it a code problem?** Check if any custom code, patches, or agent-derived formulas were used. Verify them independently.

Also scrutinize quantities where agents declared agreement -- is the agreement real, or was it against an internal benchmark rather than an independent published number?

## Your secondary task

Based on your analysis, issue a verdict.

**PASS:** every production-critical pipeline step has ?20% agreement with at least one published theoretical value on a physically similar system. Theory is the primary source for quantitative comparison. Experimental agreement provides qualitative confidence (correct sign, right order of magnitude) but does not substitute for theory-vs-theory quantitative benchmarking.

**NOT PASS (expected outcome):** provide a task list for the next pilot_gate round. For each task: the gap, a specific paper to reproduce or test to run (with arXiv ID and the specific number to match), and a decision tree -- under what conditions can this gap be considered closed? Under what conditions should we stop trying and accept the uncertainty?

**PARTIAL PASS (last resort):** issue only if a specific pipeline step has been extensively attacked (?3 independent theoretical references attempted, convention/unit issues ruled out, pipeline systematics investigated) and still cannot be reproduced. In that case, recommend dropping that specific claim from production scope. This is a scope reduction, not a free pass.

## Write `reflect_report.md`

Per-step analysis with our values, literature values (cited), diagnosis. Task list if NOT PASS. Keep it concrete -- every recommendation should point to a specific number in a specific paper.

If a paper is behind a paywall or download fails, pause and ask the user to download it. Tell them the paper ID, where to put the PDF, and say "continue."
