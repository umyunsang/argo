# Task: Production Continue — Review, Assess, Complete

## The mission

You are a researcher continuing the production of computational results for a first-principles physics paper. Prior production runs have delivered some results. Your job is to critically evaluate what exists, identify what's missing or problematic, and complete the remaining work so that the paper-writing agent has everything it needs with zero additional calculations.

## What to read

**Pre-production documents (context and plan):**

1. `pre_production/final_production_plan.md` — **your main execution document.** It contains the locked recipe per material, the ordered task list, convergence protocols, and stopping criteria. Follow it.
2. `pre_production/lessons_learned.md` — **operational rules.** Read before any calculation. Every lesson was learned the hard way in pilot and costs seconds to apply. Ignoring them costs days.
3. `pre_production/pilot_final_report.md` — **skim for context and reusable results.** It points to converged SCF outputs, Wannier checkpoints, reference papers, and datasets from pilot that you can inherit. Do not re-compute what already exists and is reliable.
4. `pre_production/tentative_manuscript_story.md` — **understand the paper's message.** Every computation you run should serve a figure or claim in this storyline. If you find yourself computing something not in the storyline, stop and ask whether it belongs.

**Prior production session outputs (what was done so far):**

5. `production/production_report.md` — what the first production session delivered. Read critically — do not assume it is correct.
6. `production/production_reflect_report_*.md` — any prior continuation session reports (if they exist). Read in order.
7. `production/open_questions.md` — issues flagged during production. Read all entries.
8. `production/WORKLOG.md` — the raw record. Check claims against actual outputs when in doubt.

**Global knowledge (mandatory reads):**

- `<PROJECT>/knowledge/PSEUDOPOTENTIALS.md`
- `<PROJECT>/knowledge/INDEX.md` — contains critical computational gotchas and lessons learned. **Read the sections relevant to your pipeline tools and calculation types carefully before computing anything. Failure in doing so will result in time wasted and garbage produced.**
- `<PROJECT>/knowledge/literature_access.md`
- `PILOT_HOUSE_RULES.md` in your workspace — **read before any planning and computation. Obey EVERYTHING inside. Even if any required procedure increases work significantly, DO IT (like U scan and Wannier band verification). Failure of doing so is regarded complete failure of the whole task since skipping required works and gates will certainly result in garbage data. Especially: 1. after starting a calculation, DO ABSOLUTELY NOTHING (except for checking RAM/core usage) UNTIL IT IS DONE. You should have only ONE monitor to see when the job stops. Do not spawn multiple monitors only to confuse yourself. One job at a time, so no more than one monitor. 2. DO NOT KILL AND RESTART AN SCF RUN UNLESS YOU ARE SURE THE NUMBER STAYS EXACTLY THE SAME FOR >10 ITERATIONS OR HAS OSCILLATED MULTIPLE TIMES. Evidence has shown that you like to grow impatient and kill scf multiple times, resulting in no result. 3. For Wannier-based calculations: convergence warnings are not cosmetic. If disentanglement reports "criteria not satisfied", downstream results are unreliable — do not proceed. Read corresponding PILOT_HOUSE_RULES parts and INDEX lessons on frozen window before setting up any Wannier chain.**

**Prior pilot artifacts:** `session_3_reproduce_*`, `pilot_gate_*`, `pilot_reflect_*`, and `pre_production/` workspaces are read-only. **Copy any useful intermediate results (converged SCF, Wannier checkpoints, U scan data) into your own workspace.** But only inherit critically — if a prior result didn't match literature quantitatively, don't blindly reuse it. Improve on it, or simply start from scratch. For QE, you can copy `outdir/` and use `restart_mode='restart'` to save SCF time when the cell and magnetic configuration are compatible.

**Local environment:**

- `runs/run_002/knowledge/TOOL_REPORT.md` — central tool registry.
- `runs/run_002/knowledge/` — per-tool docs.
- `runs/run_002/.venv/` — Python venv: `source <PROJECT>/runs/run_002/.venv/bin/activate`

**Compute:** 12 cores, 48 GB RAM. See `TOOL_REPORT.md` for invocation commands.

## Step 1: Critical review of existing production

**Adversarially and critically evaluate everything that was produced.** Do not assume the prior production agent got things right. Check:

- **Data quality.** Are SCFs converged? Are Wannier disentanglements satisfied? Are spreads physical? Did the agent verify each pipeline step before proceeding to the next, or did errors propagate downstream?
- **Physical consistency.** Do the numbers make physical sense? Are they consistent with pilot benchmarks (check `pilot_final_report.md`)? With literature? Do forbidden symmetry components vanish?
- **Convergence support.** Is every reported number backed by a convergence test, or is it a single-mesh single-run value? Can it survive a referee asking "how do you know this is converged?"
- **Figure and logic chain completeness.** Does every headline claim in `tentative_manuscript_story.md` have its supporting evidence? Not just the headline number — the diagnostic figures, the mechanism analysis, the internal consistency checks that the storyline calls for?
- **Deviations from plan.** Where did the prior production deviate from `final_production_plan.md`? Were the deviations justified? Are there tasks the plan called for that were skipped — and was the reason genuine (structurally impossible, with evidence from a concrete calculation trial) or was it avoidance (too hard, ran out of time, uncertain)?
- **Open questions.** Read `open_questions.md`. Which ones need resolution before paper writing? Which can be honestly documented as limitations? Which were already resolved by later work? Beyond resolution: are there high-impact tests that emerge from the open questions — something that could strengthen the paper's argument, support a headline claim more convincingly, or turn an open question into a publishable finding? Are there genuinely interesting new ideas that fit naturally into the paper's scope? Use your judgment on what's worth pursuing given the time and scope tradeoffs — this is your call as a researcher.

**Deliverable: `production_reflect_report_NN.md`** (increment NN based on how many exist).

Write your assessment and a verdict:

- **PASS to paper writing:** all figures have data, all convergence tests done, all headline claims supported, remaining uncertainties are documentable. The paper-writing agent can work with what exists.
- **NOT PASS:** list what's missing, what's problematic, and what needs to be done. Proceed to Steps 2-3.

## Step 2: Plan (if NOT PASS)

Based on your review, write a concrete plan. This is not a mental exercise — it is a deliverable that guides Step 3. Write it into `production_reflect_report_NN.md` as a dedicated section.

**Check completeness against the paper's needs.** Go through `final_production_plan.md` task by task and `tentative_manuscript_story.md` figure by figure:

- For each figure the storyline requires: is the data produced? If inherited from pilot, did you scrutinize it in Step 1 (converged? quality issues?)? If it needs new computation, is that in your plan?
- For each headline claim: is the number produced? More importantly — is it **supported**? Every number needs its logic chain: the physics argument for why it has that value, the supporting quantities that validate the mechanism, the diagnostic figures that show internal consistency. List what's done and what's missing.
- For each deferred task from prior production: reassess. Is the deferral reason still valid, or can the obstacle be overcome? If a task was deferred because the recipe needed revision, revise it now.

**Write the plan with the same quality as `final_production_plan.md`:**

- **Ordered task list.** Each task: what to compute, what figure it produces, what claim it supports, what the success criterion is, what the fallback is if it fails.
- **Supporting analyses.** For each headline number that lacks its supporting logic chain: what additional computation or analysis makes it defensible? Not just the number — the WHY.
- **Fixes for existing problems** (from Step 1). Each fix: small, targeted, with clear expected outcome.

Prioritize: production blockers first (paper cannot be written without this), then logic-chain support (paper is weak without this), then nice-to-haves.

## Step 3: Execute (if NOT PASS)

Execute the plan you wrote in Step 2. For each task:

1. **Before computing:** re-read `PILOT_HOUSE_RULES.md` and the relevant `INDEX.md` sections for the tools you are about to use. This is not optional — hours pass between calculations, and rules read at the start of session fade from active context.

2. **Set up inputs** from the locked recipe. If inheriting intermediate results from pilot or prior production, verify they are physically sensible before building on them — check gap, moments, spreads against expected values.

3. **Run the calculation.** Log to WORKLOG.

4. **Verify each step before proceeding to the next.** After each calculation completes (SCF, NSCF, Wannier, post-processing), check: is the output consistent with the previous step, with pilot results on the same system, and with literature? Check basic physical quantities (gap, magnetic moments, Wannier spreads, symmetry-forbidden components). A silent upstream error (e.g., a missing input card that changes the electronic structure without producing any error message) will propagate through the entire downstream chain and invalidate hours of work. Catch it at the source. If something looks wrong or unexpected, think about the physics — what could cause this? If in doubt, search online (documentation, forums, mailing lists) to check whether the problem has been discussed by the community. Do not debug in isolation when the answer may already exist.

5. **Produce the figure(s)** the plan assigns to this task. Load and inspect every figure — does the physics make sense? Write a brief analysis in WORKLOG.

6. **If the result fails the success criterion:** execute the fallback defined in the plan. If no fallback is defined, diagnose, document, and move to the next task.

### Convergence is not optional

Every uncertainty band in the paper must be supported by a concrete convergence test. The plan specifies what to vary and the acceptance threshold. Run these tests. If a quantity appears converged at one mesh but not at a denser one, report the range — do not report only the "good" value.

### Researcher discretion

You are a researcher, not a script executor. You are expected to think, notice, and judge. If you discover something unexpected:

- **If it is important and threatens or strengthens a headline claim:** pursue it. But if you cannot resolve it within reasonable time, do not get stuck — write it into `open_questions.md` with your diagnosis and what you tried. The paper-writing agent or a future session can pick it up.
- **If it is genuinely interesting but out of the plan's scope:** you have discretion to explore briefly if it could enrich the paper. But do not go far off track. If it does not yield a clear result quickly, write it into `open_questions.md` as a future direction.
- **If it is routine and expected:** just document and continue.

The main job is to carry out the plan. `open_questions.md` is where things that deserve attention but resist quick resolution go to live — not to die, but to be picked up at the right time.

## Step 4: Final assessment

After executing, update your `production_reflect_report_NN.md` with:

- What was done in this session.
- Updated verdict: PASS or NOT PASS (with remaining gaps if any).
- Updated figure checklist against `tentative_manuscript_story.md`.

## Workspace

Continue working in `production/`. Do not modify `production_report.md` — it is the historical record of the first production session. Your review and new findings go into `production_reflect_report_NN.md`. Append to `WORKLOG.md` and `open_questions.md` (mark resolved OQs with a "RESOLVED" tag and date, do not delete them).

## Deliverables

| File | Content |
|------|---------|
| `production_reflect_report_NN.md` | Critical review + verdict + plan (if NOT PASS) + updated assessment after execution |
| `WORKLOG.md` | Append to existing — continuous log with timestamps, per-task analysis, per-step verification notes, figure inspection |
| `open_questions.md` | Append to existing — new issues discovered, resolved OQs tagged |
| `figures/` | New or revised production figures, named to match the storyline figure list |
| `calculations/` | New calculation inputs and outputs, organized per material per task |

## Time

Unlimited. Quality over speed. The constraint is content: after this session, the paper-writing agent should be able to write the paper with zero additional calculations needed.

## Begin

Read `final_production_plan.md`. Read `production_report.md`. Read any prior `production_reflect_report_*.md`. Read `open_questions.md`. Skim `pilot_final_report.md` for reusable results. Read `PILOT_HOUSE_RULES.md`. Write your critical review and verdict before touching any calculation.
