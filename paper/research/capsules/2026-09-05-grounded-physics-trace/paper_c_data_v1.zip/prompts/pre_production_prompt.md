# Task: Pre-Production -- Final Consolidation, Literature Review, and Production Plan

You do not run any calculations. You do not modify anything outside your own workspace. Create `pre_production/` in the pilot directory.

## Context

The pilot phase is complete. Multiple rounds of reproduce, pilot_gate, and pilot_reflect sessions have validated (or failed to validate) each pipeline stage. A draft production_plan exists from a consolidation session. Your job is to synthesize everything into the definitive set of documents that the production agent will work from. This is a comprehensive consolidation -- everything in pilot/ is production-relevant, no filtering.

## Step 1: Identify the production program

Read `session_1_prior_work/program_selection.md`. What is the production paper about? What are the target materials? What are the headline claims?

## Step 2: Comprehensive pilot review

Read everything in `pilot/`. ALL reproduction reports, ALL pilot_gate reports and verdicts, ALL reflect reports, ALL WORKLOGs. **Do not trust prior agents' summaries -- check their claims against raw data (calculation outputs, logs, numbers, convergence).** This is a comprehensive consolidation with no filter. Every result in pilot/ is production-relevant.

Be aware that later sessions generally had more information and more critical perspective -- they corrected earlier agents' mistakes, retracted wrong diagnoses, and discovered new issues. But later agents may also have lost sight of earlier findings or lessons. Think critically and independently: prior agents' chain-of-thought may be wrong, their attributions for deviations may be incorrect, and they may have overlooked important details. When in doubt, raw data is the ground truth -- not any agent's verdict or claim.

**Deliverable: `pilot_final_report.md`.**

The single document that tells the production agent everything about what pilot achieved. Production agent reads this instead of hunting through dozens of session folders. Therefore it must be accurate and complete, grounded in raw data.

Contents:
- **Per pipeline stage, per material:** what was computed, the actual number (with citation to the specific session and file path where the raw output lives), literature comparison, tier assessment, uncertainty band with its physical origin.
- **What works reliably:** validated recipes with concrete parameters.
- **What doesn't work and why:** failed attempts with diagnosis and root cause.
- **Reusable intermediate results:** point to converged SCF charge densities, Wannier checkpoints, NSCF outputs, or other intermediate products that production can inherit to save time. For each, state whether it is a final reliable result or a good starting point (e.g., a converged SCF at ?=0 that production can restart from for strained runs). Give file paths.
- **Reference papers and datasets:** point to published PDFs, supplementary materials, and datasets that were downloaded during pilot (in `reference_papers/` folders within pilot_gate sessions). These are valuable for production -- the agent should not have to re-download them.
- **Recipe guidance per material:** the concrete parameter set that production should use, with cross-references to the lessons that motivated each choice.

**Deliverable: `lessons_learned.md`.**

Operational knowledge base. Each lesson must be:
- A specific, actionable rule. Example: "If U is used in SCF, the NSCF input must carry over the HUBBARD card -- omitting it silently produces a much smaller gap without any error, and gives completely wrong downstream results."
- Backed by evidence from pilot (which session, what went wrong, what fixed it).
- Cross-checked online: search documentation, tutorials, mailing lists, GitHub issues. Does the community know about this? Is there official guidance? If you find contradictory information, report both and flag the uncertainty.
- Rated for confidence: HIGH (verified in pilot + confirmed by documentation), MEDIUM (verified in pilot, no external confirmation), LOW (hypothesis, not independently verified).

Dig deep. The most valuable lessons cost hours to discover and seconds to apply.

## Step 3: Final literature review

Search the current literature for the production topic. This is a fresh, comprehensive survey as of today -- not a repeat of prior searches. The production paper must be positioned against the latest work.

**Deliverable: `final_literature_review.md`.**

For each relevant paper:
- Full citation, DOI, arXiv ID.
- Read the abstract AND relevant sections of the full text. Extract specific numbers that production will compare against.
- What figures does the paper include? For each: what physical quantity, what it shows, how it supports the paper's claims. This tells us what the community expects to see in a paper on this topic.
- Relationship to our work: same quantity on same material? Related quantity? Competing method? Supports or contradicts our results?
- Is there any paper that scoops our headline claim? If so, what can we still contribute?

Establish novelty: what has been done, what hasn't, where our production fits.

If a paper is behind a paywall or download fails, pause and ask the user. Tell them the DOI, where to put the PDF, and say "continue."

## Step 4: Storyline -- what is the paper's message?

This is the intellectual core of this session. A paper is not a weak collection of calculations -- it delivers a message with impact. Think about what that message is.

**Start from the original production program message** (from program_selection.md). After all the pilot work -- successes, failures, surprises, scope changes -- and after the fresh literature survey in Step 3: how should the message be adjusted? What can we credibly claim? What turned out to be more interesting or less interesting than expected?

**Review how the literature supports its own numbers.** Go back to `pilot_reflect_II` and subsequent pilot_gate sessions -- they analyzed published papers' figures and logic chains. Combine that with the latest literature from Step 3. How do other papers in this field build their arguments? What figures, what analyses, what internal consistency checks? What scope and depth does a typical computational physics paper in this area have? Use these as models.

**Design the paper structure.**

**Deliverable: `tentative_manuscript_story.md`.**

- Central message (one sentence).
- Headline claims (numbered, each with supporting evidence from pilot and expected production data).
- Main text outline: section by section, what each section argues, what evidence it presents, what figures.
- SI outline: what goes in supplementary and why (convergence tests, extended data tables, methodological details).
- Figure list: for each figure, what it shows, where the data comes from (pilot or production), what role it plays in the argument. Distinguish between figures that support the mechanism (WHY the numbers are what they are) and figures that report the numbers themselves.
- Internal consistency: how does the paper demonstrate that its results are converged, reproducible, and physically sensible? What cross-checks?
- Weaknesses and defense: what will referees attack? How does the paper preemptively address each weakness?
- Fallback: for each planned production computation, what happens if it fails? Can the paper still stand, or does the scope need to reduce? Define the minimum viable paper.

## Step 5: Detailed production plan

First, re-read the existing `production_plan.md` from the consolidation session **in full** -- it contains recipes, budgets, and stopping criteria that prior agents developed with significant effort. Use it as a starting point but do not inherit uncritically -- Steps 2-4 may have revealed issues it missed.

**Deliverable: `final_production_plan.md`.**

This is the main document the production agent works from. It must be self-contained.

**5a. Locked recipe per material per pipeline stage.** Every parameter, no ambiguity. If a parameter was discovered to be critical in pilot, call it out explicitly with the lesson reference from `lessons_learned.md`.

**5b. Ordered task list.** Each task is one production run, tied to a specific figure or claim in the storyline. For each:
- What to compute and why.
- Input parameters (from locked recipe).
- Convergence checks: every uncertainty band in the paper must be backed by a concrete convergence test. Specify what to vary and the acceptance threshold.
- Success criterion.
- Fallback if it fails (tied to Step 4 fallback analysis).
- Estimated wall time and memory.

Priority ordering: production-blocking tasks first, then supporting analyses, then optional items for referee defense. Each task should have a clear place in the storyline -- if a computation doesn't contribute to a figure or a claim, question whether it belongs.

**5c. Convergence protocol.** For each quantity in a headline claim: what convergence tests? At minimum: two different ab initio k-meshes for Wannier-interpolated quantities, symmetry-forbidden component check, comparison against at least one pilot-validated benchmark. State specific meshes and acceptance thresholds.

**5d. Scope and stopping criteria.** Production has unlimited time -- the constraint is content quality, not clock. The scope is defined by Step 4's storyline: production must deliver ALL figures and analyses the paper requires, with convergence support. The standard is similar quality and confidence as comparable published papers -- not extreme perfection, but defensible.

Planning guidance: if the total estimated wall time is below 30h, the plan is probably missing convergence tests or fallback computations -- justify why not. 60h is typical for a three-material paper with convergence studies. Above 90h, consider whether scope should be limited -- every task must earn its place in the storyline.

**5e. What the production agent reads.** State explicitly: production agent reads `final_production_plan.md` as the main execution document, `lessons_learned.md` for operational rules, and skims `pilot_final_report.md` for context and reusable results. Everything else in pilot/ is background -- production agent does not need to read individual session reports.

## Deliverables

| File | Content |
|------|---------|
| `pilot_final_report.md` | Comprehensive pilot results, raw-data traced, reusable intermediates, reference paper locations |
| `lessons_learned.md` | Operational rules with evidence + online cross-check + confidence rating |
| `final_literature_review.md` | Current literature survey with numbers, figures, novelty assessment |
| `tentative_manuscript_story.md` | Paper message, structure, figures, defense, fallbacks |
| `final_production_plan.md` | Self-contained execution plan: recipes, tasks, convergence, scope, stopping criteria |

## Time

This is a reading-and-writing session. No calculations. This session's context window will be heavily used -- that is expected and acceptable. Prioritize accuracy over speed. If you must triage, `pilot_final_report.md` and `final_production_plan.md` are the two documents production cannot function without.
