# Task: Polish -- Evaluate, Select, Merge, and Finalize the Manuscript

**Target journal: Physical Review B (Regular Article).**

Three independent prewrite-write pipeline runs have produced three complete drafts. Your job is to critically evaluate all three, select the best base, surgically improve it with the best elements from the others, and produce a submission-ready manuscript.

## What to read

Each run produced a complete package in `paper/run_1/`, `paper/run_2/`, `paper/run_3/`:
- `draft/manuscript.tex` + `draft/manuscript.pdf` -- main text
- `draft/supplementary.tex` + `draft/supplementary.pdf` -- SI
- `figures/` -- all production figures
- `scripts/` -- reproducible figure scripts
- `detailed_outline.md`, `figure_disposition.md`, `data_analysis.md` -- planning docs
- `draft/self_draft_reflection_*.md` -- the draft agent's own reasoning about its choices

Also read:
- `paper/literature_notes.md` and `paper/bibliography.bib` -- shared literature notes
- `paper/data_inventory.md` -- ground truth for numbers
- `production/open_questions.md` -- documented uncertainties

As a reminder: for targeting PRB Regular Articles, there is no length limit.

## Phase 1: Evaluate (read-only -- do not edit any draft)

### 1a. Cross-draft number and analysis comparison

The three drafts analyzed the same underlying production data independently. **Do not assume they report the same numbers.** Different analysis choices -- energy windows, fitting ranges, conventions, data transformations -- may produce different headline values from identical raw data.

For each material/system that appears in all three drafts:
- Extract the specific headline numbers each draft reports. Compare. If they differ, trace why (different window? different fitting method? different convention?).
- Compare the figures panel by panel. What does each panel show? What representation was chosen? What analysis parameters (windows, ranges, meshes) were used?
- Compare the argument and logic chain. How does each draft justify its numbers?

Document all differences. Where drafts disagree, independently judge which analysis choice is best -- you may read the draft agents' documents for their reasoning, but form your own judgment. If needed, go back to the raw data or the production reports to verify. Decide on a set of final numbers, judging from physics (e.g. if you claim plateau, is it really plateau, or it is better shifted and shrinked to real plateau position) rather than simply some numbers.

### 1b. Score each draft -- text

For each draft, read the full main text carefully as a critical PRB reviewer:
- Structure and flow: do sections build a logical argument?
- Physics accuracy: are claims supported? Caveats placed correctly?
- Writing quality: does it read like a published PRB paper, or like a report?
- Introduction: does it motivate the problem and state what is new?
- Discussion: does it synthesize across materials with genuine insight, or just repeat results?

### 1c. Score each draft -- figures, panel by panel

For each figure in each draft, evaluate **every panel individually**:

- First read the draft agents' `figure_disposition.md` to understand their arguments about the choice of each figure panels, but do form your own judgement.
- What physical quantity does this panel display? What is the representation (line plot, color map, bar chart, schematic)?
- Does this panel tell a story that belongs in the main text? Main text figures exist to tell physics and strengthen the **physics story**. Their priority is: first, convey the physical result; second, support and strengthen the physical argument; third, do so in a visually persuasive and clean way. Panels that show mathematical or analysis details, methodology transparency, convergence studies, or parameter-dependence sensitivity investigations that do not directly advance the physics story belong in the SI -- unless the community routinely places them in the main text for this type of paper. Caveats can be discussed in main text while pointing to SI for futher information and plots.
- **Can the reader independently verify the claim from this panel?** The most persuasive figures show data in a form where the reader can see the trend themselves -- not a processed summary that requires trusting the analysis. If several curves visibly collapse onto one, that is more convincing than a table of residual numbers of some fit. Ask: could the raw data have been shown instead? Would that be more informative? If the reader can directly judge from raw data, show it. If some processed/transformed form of raw data shows the trend well, show it also. Showing raw data is nearly always desirable.
- Is this the representation the published literature uses for this type of data? Check against the adjacent-paper reading reports in `literature_notes.md`. If all comparable published papers use one plot type and this draft uses something different, consider whether the draft's choice is genuinely better or just unfamiliar.
- Are error bars correct and consistent? Are axis ranges appropriate? Labels readable at PRB column width? Any overlapping elements?

Then **cross-compare** the same data across drafts at the panel level. Different drafts may represent the same quantity with different plot types, different transformations, or different parameter choices. Which representation is most informative? Could elements be combined -- for example, one draft's panel representation with another draft's parameter choices? Also, you do not have to decide on one analysis/representation of data. Often it is beneficial to combine raw data plot with different analysis angle panels to establish the whole picture.

Finally, evaluate the **figure sequence as a whole**: each figure should tell one coherent thing, and the figures together should tell the paper's entire story. A reader flipping through just the figures and captions should be able to follow the argument.

### 1d. Write evaluation and verdict

**Deliverable: `paper/final/evaluation_and_verdict.md`.**

- Number comparison table (from 1a): per material, headline numbers from each draft, analysis differences, best choice with justification.
- Per-draft text scores with brief justification.
- Per-figure, per-panel cross-draft comparison: for each panel slot, which draft's version is best and why. Where a hybrid would improve on any single version (e.g., one draft's representation + another draft's analysis parameters, or transplanting a single strong panel from one draft into another's figure layout), specify exactly.
- Final verdict: which draft is the main text base? What specific figures, panels, sections, or paragraphs from other drafts should be transplanted? Be surgical in text, but take better figures/panels or regenerate figures with inspiration of parameters from other drafts. Very often, image quality does not align with writing quality. Make independent decisions. Decide a final set of images that tells a coherent story aligning with the base draft.

## Phase 2. Regenerate all figures according to verdict (both main text and SI)

In this phase, you will curate the final set of images for main text and SI according to the verdict.

**Do not copy figure image files (PNG/PDF) from any draft.** Copy figure **scripts** from `paper/run_N/scripts/` into `paper/final/scripts/`. For each figure, write the script that implements your verdict's panel selection, parameter choices, and hybrid decisions. If the verdict calls for panels from different drafts combined, or a panel with one draft's representation but another's parameters -- write a new script that produces exactly that.

Draw every figure. Inspect every figure. Each figure must tell one coherent thing. All figures together must tell the paper's entire story -- a reader flipping through figures and captions alone should follow the argument. **Iterate each figure to publication quality before moving on. EXTREMELY IMPORTANT. Figures are first impression.** Generate figure, load them and visually check, find problems, update script, iterate until publication quality. Do lower quality preview for efficient iteration to save context, and generate both pdf and 600dpi png version in the end.

After this phase, you will have all the figures for main text and SI for final publication.

**Deliverables: publication figures in both pdf and 600dpi png format in paper/final/figures.**

## Phase 3: Assemble and edit -- main text

Copy the selected draft's text into `paper/final/`. Do not modify the original drafts.

### 3a. Adapt main text around new figures

The figures may have changed from the base draft (different panels, different representations, different parameter choices). The text must match.

- **First pass: figure-adjacent text.** Update captions, in-text figure references ("as shown in Fig. X(c)"), and the paragraphs that interpret each figure. This is where most changes concentrate.
- **Second pass: surgical transplants.** Per your verdict, transplant specific sections or paragraphs from other drafts. Keep these surgical -- do not turn the main text into a patchwork.

### 3b. Iteratively improve main text as a whole

After writing your draft, stop and take a step back, and reflect adversarially and critically on your own writing, from the view point of a fresh reader. Think about the storyline. Does the story flow well? Is everything clear and easy to understand? Is the language proper and scientifically rigorous? Is the connection between paragrphs and sections smooth? Is the logic solid? Any problem you find while writing? Think carefully, how to improve the draft towards scientific publication quality. General consideration: title, abstract and figures are the first thing reader reads, then introduction, then the main text, then SI. Iterate high stake parts with extreme care, and ensure coherence within the whole paper.

Iterate the draft at least **two** times. Each time, re-read the whole draft (because you might have modified things incrementally but lost sight of the whole picture), do the above critical thinking process as if you were a fresh, curious yet critical reader, first write `paper/final/self_draft_reflection_NN.md` (NN is next number, depending on the iteration) about what problems of the paper you found if you were a fresh reader, and how you plan to mitigate that (full rewrite of whole paper? Rewrite certain parts? Polish some language? etc.). You are an agent with full control, so think deeply and find all problems yourself.

### 3c. Compile and visual iteration

After text is stable:
- Compile to PDF. Load and inspect every page.
- Check every figure in the compiled output: readable at print size? Any overlapping labels/legend/data? Figure placement reasonable?
- If any figure has problems, go back to the script, fix, regenerate, recompile.
- Iterate until the main text PDF looks like a published PRB article.

**Do not touch SI yet.** Main text must be finalized first.

## Phase 4: SI

Now that main text is final:
- Which draft's SI best matches the finalized main text? Start from that.
- Update cross-references and numbering to match main text changes.
- Check SI figures (same panel-level checklist, though standard can be slightly lower).
- Are there SI figures or tables from other drafts that would strengthen the SI? You are allowed to change SI figures whenever you see fit, just iterate whatever figure you create until publication quality.
- Compile SI PDF. Visual check. Fix both visual and text issues. Iterate until publication quality.

## Phase 5: Citation walk-through

General rule for this phase: avoid hallucination, and write a detailed worklog as `paper/final/added_references.md` including verbatim abstract plus all necessary informations for each citation item.

### 5a: Add citations for the main text aiming at 40+

First check how many citations are there in the **main text**. Add references till 40+, which is the norm for PRB Regular Article. Search online proper citations to add. 
- **Fetch the abstract.** Copy it verbatim. Do not paraphrase from memory. We will verify the existence of the vabatim abstract later, so do not skip.
- Judge suitability to the manuscript. Add citation to bib and insert citation to proper places of the manuscript if suitable. Write down the reasoning of your decision in the worklog.
- Recompile properly and verify pdf of the new entries, iterate until no visible problem.

### 5b: Add citations for the SI

After expanding citations to 40+ for the main text, do a citation adding pass for SI, but in that case only out of genuine physical and publication quality enhancement, not aiming number of citations. Recompile properly and verify pdf of the new entries, iterate until no visible problem.

### 5c: Systematically verify ALL citations critically with a fresh mind

Afterwards comes the very important verification pass: systematically verify every citation in both main text and SI, even if you just added it. Your previous pass might be wrong/incomplete or cannot compile cleanly or miss certain information. Do this check with a fresh and critical mind. Log down your trajectories and decisions in the worklog.

For every `\cite{key}`:
- Key exists in `bibliography.bib`?
- Fetch the paper online (DOI or arXiv). Read the abstract. Does the cited paper actually say what the manuscript claims?
- Is this the right citation for this claim?

For every bib entry used:
- DOI or arXiv ID correct? Author names, title, journal, year accurate?

Flag and fix any issues. Remove hallucinated citations. Recompile to pdf, check visually and iterate until no problem.

## Phase 6: Pre-publication checklist

**Deliverable: `paper/final/pre_publication_check.md`.**

### Part 1: Main text verification
- Every numerical value traced to source. Units, signs, decimal places correct.
- Notation consistent throughout.
- No contradictions between sections.
- Abstract accurately summarizes actual results.
- Author block, acknowledgments, author contributions complete.

### Part 2: Figure and visual verification
Per-figure, per-panel checklist:
- [ ] Message clear at a glance
- [ ] Panel belongs in main text (not SI-level detail)
- [ ] Reader can independently verify the claim from the visual
- [ ] Labels readable at PRB column width
- [ ] Axis ranges appropriate
- [ ] No overlapping elements
- [ ] Caption self-contained
- [ ] Consistent style across all figures

### Part 3: SI verification
- SI consistent with finalized main text.
- Cross-references correct.
- SI figures pass checklist (abbreviated).

### Part 4: Citation verification
- Per-cite log: key, claim in manuscript, abstract confirms (Y/N), notes.

### Part 5: PRB compliance
- Two-column layout clean.
- Page count appropriate.
- References formatted correctly.
- SI properly separated.
- All compilation warnings resolved.

Final compile. Inspect PDFs one last time.

## Deliverables

| File | Content |
|------|---------|
| `paper/final/evaluation_and_verdict.md` | Number comparison, per-draft scores, per-panel cross-comparison, verdict |
| `paper/final/manuscript.tex` | Submission-ready main text |
| `paper/final/supplementary.tex` | Submission-ready SI |
| `paper/final/bibliography.bib` | Verified and cleaned |
| `paper/final/added_references.md` | Worklog of adding citations |
| `paper/final/figures/` | Final figure set |
| `paper/final/manuscript.pdf` | Compiled main text PDF |
| `paper/final/supplementary.pdf` | Compiled SI PDF |
| `paper/final/main_text_reflection_NN.md` | Text iteration logs. Two expected. |
| `paper/final/pre_publication_check.md` | Full verification checklist |
