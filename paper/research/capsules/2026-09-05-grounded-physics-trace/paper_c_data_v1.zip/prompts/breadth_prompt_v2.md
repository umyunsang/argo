# Task: Research Landscape Mapping

## The mission

You are working in a large project that aims to produce a first-principles computational physics paper suitable for peer review at a respectable journal. The standard is novelty, rigor, and thoroughness throughout. The final paper must make a clear and substantial scientific contribution -- not incremental, not a routine calculation, not a minor variation on existing work.

## Your task

This is an **extensive reading task**. You read the recent arXiv literature in condensed-matter and adjacent physics and produce a map of the research landscape: what people are working on, where the activity is, what directions look scientifically promising. A later agent will use your map, together with its own deep reading, to conceive specific research directions.

You do not propose research ideas. Your output is a map. Ideation is the next stage's job.

## Reading material

**Primary source -- local arXiv corpus (read-only):** the most recent 6 months of papers from six arXiv categories: cond-mat.mtrl-sci, cond-mat.mes-hall, cond-mat.supr-con, cond-mat.str-el, physics.chem-ph, physics.comp-ph. ~11k papers total.

- `<PROJECT>/corpus/title_list.md` -- every paper in the corpus, one line per paper: `[arxiv_id] (category, date) Title -- journal_ref?`. **Cat this entire file into context at session start; do not skim or sample.** Journal references are present for ~10% of papers (only those whose authors manually added a publication record on arXiv); absence does not mean unpublished.
- `corpus/corpus.db` -- SQLite. Query for abstracts and full metadata. Columns include `arxiv_id`, `title`, `abstract`, `primary_category`, `all_categories`, `submission_date`, `doi`, `journal_ref`. Use it freely.
- `corpus/markdown/<arxiv-id>.md` -- full paper text in markdown, converted from PDF. Read selectively for papers worth understanding deeply.
- `corpus/pdfs/<arxiv-id>.pdf` -- original PDF. Read directly if a markdown conversion looks garbled or you need to inspect figures the markdown cannot represent.
- `corpus/latex/<arxiv-id>.tar.gz` -- original LaTeX source for ~78% of papers. If markdown is garbled or you need clean equations/figure captions, extract on demand into your own workspace: `tar -xzf corpus/latex/<id>.tar.gz -C <your_workspace>/latex_unpacked/<id>/`. Do not extract into the corpus directory.

**Secondary source -- full internet access (on demand):** for anything beyond the corpus -- older literature, specific paper lookup, broader context. Before reaching for the generic web search tool, read `<PROJECT>/knowledge/literature_access.md`. It documents the structured APIs available (arXiv all-time, Semantic Scholar, OpenAlex, Crossref, Elsevier TDM with key) with code examples. Structured APIs are higher precision than web search; use them first.

**Filesystem discipline:** the corpus directory and knowledge directory are **read-only** for you. Write only under your own working directory. Any extracted LaTeX, downloaded PDFs, or intermediate files go in subdirectories of your workspace.

## What to look for

The corpus is diverse. Good landscape entries include:

- **Dominant themes**: directions where many papers cluster.
- **Emerging bursts**: recent activity that has not yet consolidated.
- **Underrepresented but substantive directions**: scattered high-quality work that has not converged into a visible theme. Low competition.
- **Gaps**: experimental observations without clean theoretical understanding, theoretical predictions awaiting experimental test, contradictory findings, methodology shifts mid-corpus.
- **Cross-pollinations**: ideas that appear across subfield boundaries.

A first-principles computational study could make a contribution in many of these. The map should surface areas where such a contribution is plausible -- not restricted to papers that already used computation. Experimental papers, reviews, and theory papers are all fair game.

## Deliverable

A single file `breadth_report.md` in your working directory. Suggested structure:

1. **Themes** -- dominant directions, with representative arXiv IDs and a sense of activity level.
2. **Emerging patterns** -- new bursts, methodology shifts, anomalies.
3. **Underrepresented directions** -- scattered but substantive, low competition.
4. **Gaps** -- where a first-principles study could contribute.
5. **Candidate directions for deep-dive** -- a ranked shortlist (5--10) of directions worth dedicated investigation. Rank by scientific potential, not by heat. Heat and novelty both matter; explicitly note which drives each ranking.

Use arXiv IDs inline as evidence. Do not fabricate citations. For each claim, distinguish between "I read N papers in this area" and "I inferred this from abstracts alone" -- mark your epistemic state per theme.

If you find yourself writing "someone should study X" or "we propose Y" -- stop and rewrite. Say "there is a gap around X" or "direction Y appears unexplored." You are mapping, not ideating.

## Begin

Read the resources, develop your own reading strategy, and produce `breadth_report.md`. **No time limit, no token limit -- do not save tokens, this stage matters.** Your effort here feeds directly into every downstream stage; the ideation agents can only work with what you surface. Take the time this task deserves.
