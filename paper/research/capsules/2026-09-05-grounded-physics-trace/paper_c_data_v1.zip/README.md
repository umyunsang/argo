# Data and scaffolding archive — "Grounded autonomous research: a fault-tolerant LLM pipeline from corpus to manuscript in frontier computational physics"

**Paper:** H. Huang, *Grounded autonomous research: a fault-tolerant LLM pipeline from corpus
to manuscript in frontier computational physics*, ICML 2026 AI for Science Workshop.
OpenReview: https://openreview.net/forum?id=R5YXaPgUAx
**This record:** doi:10.5281/zenodo.21126996 (v1).

## Purpose

This is the claim-support archive for the camera-ready paper: the minimal set of prompts,
curated-knowledge files, scripts, derived data, and verdict records needed to check the
paper's quantitative claims and to reuse its pipeline scaffolding. Every file is justified
against a specific claim or promise in the paper — see `MANIFEST.md`.

## Scope

**This archive covers the canonical run.** The pre-architecture baseline and no-pilot
ablation runs are characterized in §4 of the paper; their artifacts are retained in the
project archive, except for a minimal evidence set for the ablation's §4 claims
(`ablation_evidence/`). The post-run anchor investigation noted in §3.2 of the paper will
be reported separately and is not part of this record. Raw session transcripts are
retained in the project archive (not published, for sensitivity reasons); the
intervention record is published at the summary level in `intervention_ledger/`
(per-event ledger + counting script + audited counting rules), which is the evidence base
of the paper's Table 2.

Internal run numbering used in some archived files: `run_001` = the pre-architecture
baseline, `run_002` = the canonical run, `run_003_ablation` = the no-pilot ablation
(all three as defined in §4 of the paper). Some archived scripts and data columns
reference analysis documents in the private project archive; those are provenance
pointers, not package contents.

## Contents (per directory)

- `prompts/` — the full canonical prompt set (latest operative version of each), including
  the five prompts reproduced verbatim in Appendix C of the paper (byte-identical to these
  files), the house rules, the per-stage prompts summarized in Appendix C.6, and the
  below-T3 conditional reproduction patch. Note: the S1 program-selection prompt requests
  three reproduction papers; the canonical S1 session nominated five targets in its
  selection report, and all five were executed (the paper's k = 5). Superseded prompt
  versions (e.g., the eight earlier pilot-gate versions noted in Appendix C) are retained
  in the project archive.
- `knowledge/` — the curated knowledge base as described in the paper: `INDEX.md`
  (470 lines, post-canonical-pilot state; identical to the state inherited by the no-pilot
  ablation) and `PSEUDOPOTENTIALS.md`. Local absolute paths replaced by placeholders
  (`<PROJECT>`, `<PP_ROOT>`, `<HOME>`). These files are archived as operated (including
  their internal cross-references to project-archive paths).
- `scripts/categorization/` — the 12-theme corpus categorization: regex rules
  (`categories.md`), categorizer (`categorize.py`), its JSON/CSV outputs, and its audit
  note (Appendix E of the paper).
- `scripts/info_flow/` — the literature-consultation event extraction and deduplication
  scripts behind the 2,162-event / 14-channel accounting (Fig. 1B,C).
- `scripts/figures/` — the exact scripts that generated Figs. 1, 2, 3, 4 (appendix
  Fig. A1) and 5 (appendix Fig. A2), plus their shared style/data modules and extractors.
  **Script provenance note:** these are archived as operated in the project tree; several
  read inputs that live in the private archive (raw transcripts, breadth reports, corpus
  database), so they document methodology rather than run push-button inside this
  package. The derived data they produced is in `figure_data/`.
  `intervention_ledger/count_anchor_outcomes.py` has been made runnable in-package.
- `figure_data/` — derived data: `pilot_anchor_data.csv` (Fig. 3A / Fig. 4 anchor
  trajectories; the 7-anchor final-outcome accounting), `literature_total_dedup.json`
  (grand total 2,162), per-stage summaries, per-session scaffolding-access table
  (47 sessions), `breadth_cited_ids.json` (the three breadth reports' cited-ID lists;
  reproduces the paper's 877 union, 22/27/100 exactly-two counts, 27 consensus core,
  701 exactly-one count), and `corpus_arxiv_ids.csv` (all 11,083 corpus arXiv IDs with
  theme category; the corpus itself is reconstructable from arXiv).
- `verdicts/` — the five pilot reproduction verdict files (`paper_verdict.json`), the
  primary records of the T1–T4 tier scheme as operated.
- `intervention_ledger/` — Table 2's evidence base: per-event ledger
  (`intervention_events.csv`: 9 in-session events + 3 offline curations + the architected
  below-T3 patch), the counting script, the audited counting rules and spot-checks
  (`counting_rules_AUDIT.md`), and the Fig. 3B episode recount ledger (15 catch episodes).
- `production_inputs/` — the Quantum ESPRESSO / Wannier90 input decks (`.in`, `.win`) of
  the canonical production calculations (MnTe sin(3φ), CrSb strain, CsV₂Te₂O baseline and
  B1g strain), archived as operated — some angle directories retain only the Wannier
  input because the run reused chain inputs across angles — plus
  `mnte_strain_recipe_pilot_gate11/`: the MnTe ε = ±0.2% strain-endpoint decks of the
  locked Λ_orb recipe, produced in pilot gate 11 and carried into production.
  Wavefunctions/charge densities/outdirs are not included (size); extracted final numbers
  are tabulated in the companion manuscript and its Supplemental Material.
- `toolchain/` — the QE 7.5 `pw2wannier90.f90` wfcU allocation fix (lesson L12) required
  for the noncollinear+SOC+Hubbard orbital-magnetization chain, with provenance.
- `ablation_evidence/` — minimal support for §4's no-pilot-ablation claims: the
  disentanglement-window scan data (`mnte_dfroz_plateau.csv`), the ablation's headline
  M_orb value (`cross_material_synthesis.csv`, row `M_orb_z_eps0_100adapt` = 0.0661
  μB/cell), the verbatim "Plateau is BROAD" characterization with provenance, and a grep
  transcript (`reflect_cycles_grep.md`) verifying that the anchor comparison "0.066 vs.
  0.176" was never written across the four reflect cycles.
- `companion_SM/` — the companion manuscript's Supplemental Material PDF, as produced by
  the pipeline (see the provenance note in that directory).

## Provenance notes

- All prompt and knowledge files are the run's operative versions; prompts in `prompts/`
  that also appear in Appendix C of the paper are byte-identical to the paper's sources.
- Text files were desensitized (path placeholders; no other content changes), except
  where noted: the published copies of `count_interventions.py`,
  `count_anchor_outcomes.py`, and `episode_recount.md` carry condensed scope/provenance
  headers (full internal versions retained in the project archive). PDFs are
  binary-identical to the as-produced artifacts.
- `SHA256SUMS` covers every file in this record.

## Version note

v1 is the minimal claim-support set. A fuller curated release (e.g., per-gate verdict
records, superseded prompt versions) may follow as a new version of this record.

## License and citation

License: CC BY 4.0 (see `LICENSE`). Please cite the paper (above) and this record
(doi:10.5281/zenodo.21126996).
