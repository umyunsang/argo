# Pseudopotentials — MATCH THE PAPER'S XC FUNCTIONAL

PP choice is the single most important decision. Wrong PP → 30-60% error. Right PP → <5%.

**RULE: The PP's XC functional must match the calculation's XC functional.**
- Paper uses PBE → use PBE PPs
- Paper uses PBEsol → use PBEsol PPs (GBRV PBEsol / PseudoDojo PBEsol — all local)
- Paper uses LDA → use LDA PPs (HGH, GBRV LDA, or PseudoDojo PAW/NC LDA — all local)
- Paper uses PW91 → no PW91 PPs exist, this is the ONE case where `input_dft='pw91'` with PBE PPs is acceptable
- **Do NOT use `input_dft` to override XC when matching PPs are available.** PP and calculation XC must be physically consistent.

## Local libraries

Base path: `<PP_ROOT>

All variants from the `assets-2025-12-26` release are installed locally
(verified by SHA256 on install, each dir has `head.json` + UPFs).

| Library | XC | SOC? | Type | Elements | Path |
|---------|-----|------|------|----------|------|
| SSSP Efficiency | PBE | No | Mixed PAW+US | 103 | `SSSP/efficiency/1.3.0/` |
| SSSP Precision | PBE | No | Mixed PAW+US | 103 | `SSSP/precision/1.3.0/` |
| GBRV PBE | PBE | No | All-US | 65 | `GBRV/pbe/1.5/` |
| GBRV PBEsol | PBEsol | No | All-US | 64 | `GBRV/pbesol/1.5/` |
| GBRV LDA | LDA | No | All-US | 64 | `GBRV/lda/1.5/` |
| SG15 | PBE | SR+FR | All-NC | 219 | `SG15/oncv/2020-02-06/` |
| PseudoDojo NC-SR PBE std | PBE | No | All-NC | 72 | `PseudoDojo/nc-sr_pbe_standard/0.4/` |
| PseudoDojo NC-SR PBE stringent | PBE | No | All-NC | 72 | `PseudoDojo/nc-sr_pbe_stringent/0.4/` |
| PseudoDojo NC-SR PBEsol std | PBEsol | No | All-NC | 72 | `PseudoDojo/nc-sr_pbesol_standard/0.4/` |
| PseudoDojo NC-SR PBEsol stringent | PBEsol | No | All-NC | 72 | `PseudoDojo/nc-sr_pbesol_stringent/0.4/` |
| PseudoDojo NC-SR LDA (PW) std | LDA | No | All-NC | 70 | `PseudoDojo/nc-sr_pw_standard/0.4/` |
| PseudoDojo NC-SR LDA (PW) stringent | LDA | No | All-NC | 70 | `PseudoDojo/nc-sr_pw_stringent/0.4/` |
| PseudoDojo NC-FR PBE std | PBE | **YES** | All-NC | 70 | `PseudoDojo/nc-fr_pbe_standard/0.4/` |
| PseudoDojo NC-FR PBE stringent | PBE | **YES** | All-NC | 72 | `PseudoDojo/nc-fr_pbe_stringent/0.4/` |
| PseudoDojo NC-FR PBEsol std | PBEsol | **YES** | All-NC | 71 | `PseudoDojo/nc-fr_pbesol_standard/0.4/` |
| PseudoDojo NC-FR PBEsol stringent | PBEsol | **YES** | All-NC | 71 | `PseudoDojo/nc-fr_pbesol_stringent/0.4/` |
| PseudoDojo PAW PBE std | PBE | No | All-PAW | 86 | `PseudoDojo/paw-sr_pbe_standard/1.1/` |
| PseudoDojo PAW PBE stringent | PBE | No | All-PAW | 86 | `PseudoDojo/paw-sr_pbe_stringent/1.1/` |
| PseudoDojo PAW PBEsol std | PBEsol | No | All-PAW | 86 | `PseudoDojo/paw-sr_pbesol_standard/1.1/` |
| PseudoDojo PAW PBEsol stringent | PBEsol | No | All-PAW | 86 | `PseudoDojo/paw-sr_pbesol_stringent/1.1/` |
| PseudoDojo PAW LDA std | LDA | No | All-PAW | 86 | `PseudoDojo/paw-sr_lda_standard/1.1/` |
| PseudoDojo PAW LDA stringent | LDA | No | All-PAW | 86 | `PseudoDojo/paw-sr_lda_stringent/1.1/` |
| PSLibrary v1.0.0 | Multi (PBE/PBEsol/LDA/PW91/WC) | Mixed | PAW+US | 928 | `PS-Library/default/1.0.0/` |
| PSLibrary legacy | Multi | Mixed | PAW+US | 494 | `PS-Library/legacy/legacy/` |
| HGH | PBE+LDA | No | NC | 266 | `HGH/default/current/` |
| GIPAW (Ceresoli) | PBE+LDA | No | NC+US | 146 | `GIPAW/default/current/` |
| SCAN TM (Yao 2017) | SCAN | No | NC | 32 | `SCAN_TM/default/2017/` |

Filename naming inside each dir follows the library's upstream convention
(e.g. `Si.upf` for PseudoDojo, `si_pbe_v1.uspp.F.UPF` for GBRV, `Si_ONCV_PBE-1.2.upf` for SG15).
See **PP filename patterns** below.

## Source archives (reference)

All libraries above were extracted from the release:
`https://github.com/QMatSuite/qmatsuite-assets/releases/tag/assets-2025-12-26`.
Archive → local-path mapping:

| Archive | Installed at |
|---------|-------------|
| `SSSP_1.3.0_PBE_efficiency.tar.gz` | `SSSP/efficiency/1.3.0/` |
| `SSSP_1.3.0_PBE_precision.tar.gz` | `SSSP/precision/1.3.0/` |
| `GBRV_pbe_UPF_v1.5.tar.gz` | `GBRV/pbe/1.5/` |
| `GBRV_pbesol_UPF_v1.5.tar.gz` | `GBRV/pbesol/1.5/` |
| `GBRV_lda_UPF_v1.5.tar.gz` | `GBRV/lda/1.5/` |
| `sg15_oncv_upf_2020-02-06.tar.gz` | `SG15/oncv/2020-02-06/` |
| `nc-sr-04_{pbe,pbesol,pw}_{standard,stringent}_upf.tgz` | `PseudoDojo/nc-sr_<xc>_<quality>/0.4/` |
| `nc-fr-04_{pbe,pbesol}_{standard,stringent}_upf.tar` | `PseudoDojo/nc-fr_<xc>_<quality>/0.4/` |
| `paw-sr-11_{pbe,pbesol,lda}_{standard,stringent}_upf.tgz` | `PseudoDojo/paw-sr_<xc>_<quality>/1.1/` |
| `ps-library-v1.0.0.tar.gz` | `PS-Library/default/1.0.0/` |
| `ps-library-legacy.tar.gz` | `PS-Library/legacy/legacy/` |
| `hartwigesen-goedecker-hutter-pp.tar.gz` | `HGH/default/current/` |
| `GIPAW_DavideCeresoli.zip` | `GIPAW/default/current/` |
| `SCAN_TM_YiYao_2017.zip` | `SCAN_TM/default/2017/` |

Seed archives cached at `<PP_ROOT>

## PP filename patterns

- `*kjpaw*` / `*paw*` = PAW
- `*rrkjus*` / `*van*` / `*uspp*` = Ultrasoft (US)
- `*oncv*` / `*ONCV*` = Norm-conserving (NC)
- SG15 FR files have `_FR` suffix (e.g., `Si_ONCV_PBE_FR-1.1.upf`)
- HGH LDA files have `*.pz-*` naming
- GBRV: lowercase element names (e.g., `si_pbe_v1.uspp.F.UPF`)
- PseudoDojo: capitalized element names (e.g., `Si.upf`)

For SOC: use FR PPs + `noncolin=.true., lspinorb=.true.` in &SYSTEM.

## PP type constraints by QE executable

| PP Type | Works with | Does NOT work with |
|---------|-----------|-------------------|
| NC (norm-conserving) | All QE codes | — |
| US (ultrasoft) | pw.x, ph.x, hp.x, neb.x, pp.x, dos.x, projwfc.x, bands.x | epsilon.x, turbo_*.x, gww.x, epw.x, kcw.x |
| PAW | pw.x, ph.x, hp.x, neb.x, pp.x, dos.x, projwfc.x, bands.x | epsilon.x, turbo_*.x, gww.x, epw.x, kcw.x |

**NC PPs are required by:** epsilon.x, turbo_lanczos.x, turbo_eels.x, turbo_davidson.x, gww.x, pw4gww.x, epw.x, kcw.x, pw2bgw.x.
**FR PPs are required for:** SOC calculations (`lspinorb=.true.`).
**Never mix PAW and US PPs** in the same calculation — QE will crash.

## Special pseudopotentials for specific workflows

### XSpectra (XANES/XAS) — core-hole PPs

XSpectra needs **two special things** for the absorbing atom:
1. A PP with `2pj` (two projectors per l channel) — for high angular momentum resolution
2. A **core-hole PP** — for the excited-state SCF (one core electron removed, `tot_charge=+1.0`)

**Where to find:**
- Bundled with QE source at `XSpectra/examples/pseudo/` — contains TM PPs for C, Cu, Ni, O, Si:
  - `C_PBE_TM_2pj.UPF` (ground state), `Ch_PBE_TM_2pj.UPF` (core hole)
  - `Cu_US_PBE_3pj_lowE.UPF`, `Cu_halfh_US_PBE_3pj.UPF` (half core hole)
  - `Ni_PBE_TM_2pj.UPF`, `O_PBE_TM.UPF`, `Si_PBE_USPP.UPF`
- Core wavefunction must be extracted: `$QE_ROOT/XSpectra/tools/upf2plotcore.sh PP.UPF > element.wfc`
- **Generate for any element with ld1.x:** modify the all-electron config to create a hole
  (K-edge: `1S2 → 1S1`; L-edge: `2P6 → 2P5`), set `lgipaw_reconstruction=.true.`
- QE Legacy PP Library (`https://pseudopotentials.quantum-espresso.org/legacy_tables/original-qe-pp-library`)
  has some `star1s` (full core hole) and `starhNl` (half core hole) variants — but these URLs may
  require manual browsing, they are not curl-friendly

### GIPAW (NMR chemical shifts, EPR)

GIPAW PPs need additional all-electron reconstruction data that standard PPs lack.
- **Available in assets:** `GIPAW_DavideCeresoli.zip` (downloaded from Davide Ceresoli's collection)
- Upstream: `https://sites.google.com/site/dceresoli/pseudopotentials` (Google Drive links, not curl-friendly)
- GitHub (partial): `https://github.com/dceresoli/gipaw-pseudopotentials` (lanthanides + Al)
- **Generate with ld1.x:** add `lgipaw_reconstruction=.true.` to `&inputp` namelist

### SCAN meta-GGA

Standard PPs (PBE/LDA) are used with SCAN — you set `input_dft='scan'` and use PBE PPs.
But for better accuracy, dedicated SCAN PPs exist:
- **Available in assets:** `SCAN_TM_YiYao_2017.zip` (transition metal SCAN PPs)
- Upstream: `https://yaoyi92.github.io/scan-tm-pseudopotentials.html`

## Upstream sources (reference only — use local/assets copies)

These URLs are the original sources where the PP libraries were collected from.
**Do NOT try to download from these URLs directly** — many require JavaScript rendering,
authentication, or special download procedures. All usable PPs have been collected into
the QMatSuite assets release and the local libraries listed above.

| Library | Upstream URL | Notes |
|---------|-------------|-------|
| SSSP | `https://www.materialscloud.org/discover/sssp` | v1.3.0, PBE+PBEsol, efficiency+precision |
| PseudoDojo | `https://www.pseudo-dojo.org/` | NC (ONCV v0.4) + PAW (JTH v1.1), PBE/PBEsol/LDA, SR+FR |
| SG15 ONCV | `http://www.quantum-simulation.org/potentials/sg15_oncv/` | NC PBE, SR+FR |
| GBRV | `https://www.physics.rutgers.edu/gbrv/` | US, PBE/PBEsol/LDA v1.5 |
| PSLibrary | `https://dalcorso.github.io/pslibrary/` | PAW+US, PBE/PBEsol/LDA/PW91/WC, ~94 elements |
| HGH | `https://pseudopotentials.quantum-espresso.org/legacy_tables/hartwigesen-goedecker-hutter-pp` | NC, LDA+PBE, legacy |
| QE Legacy Original | `https://pseudopotentials.quantum-espresso.org/legacy_tables/original-qe-pp-library` | Mixed, has core-hole + GIPAW variants |
| GIPAW (Ceresoli) | `https://sites.google.com/site/dceresoli/pseudopotentials` | NC/US with GIPAW reconstruction |
| SCAN TM | `https://yaoyi92.github.io/scan-tm-pseudopotentials.html` | NC for SCAN meta-GGA |

## Decision tree

```
What XC does the paper use?
├── PBE (most common)
│   ├── Need SOC? → PseudoDojo nc-fr PBE (local) or SG15 FR (local)
│   ├── Need NC only (epsilon.x, turbo, GW, EPW)? → SG15 or PseudoDojo nc-sr PBE (local)
│   ├── Need PAW? → SSSP or PseudoDojo paw-sr PBE (local)
│   └── Default → GBRV PBE (local, all-US, reliable, 65 elements)
├── LDA
│   ├── HGH (local, but CHECK z_valence for heavy elements — HGH often has minimal valence!)
│   ├── GBRV LDA (local, all-US, 64 elements, recommended)
│   ├── PseudoDojo PAW LDA (local, all-PAW, 86 elements)
│   └── PseudoDojo nc-sr LDA/PW (local, NC, for epsilon.x/GW/EPW)
├── PBEsol
│   ├── GBRV PBEsol (local, all-US)
│   ├── PseudoDojo PAW PBEsol (local)
│   ├── PseudoDojo nc-sr PBEsol (local, NC, for epsilon.x/GW/EPW)
│   └── Need SOC? → PseudoDojo nc-fr PBEsol (local)
├── PW91
│   └── Use PBE PPs + input_dft='pw91' (only acceptable case for input_dft override)
├── Hybrid (HSE06, PBE0, B3LYP)
│   └── Use PBE PPs (hybrid functionals add exact exchange on top of PBE base)
├── meta-GGA (SCAN, r2SCAN)
│   └── Use PBE PPs + input_dft='scan' (or use SCAN TM PPs from assets for better accuracy)
└── vdW-DF
    └── Use PBE PPs + input_dft='vdw-df' (or vdw-df2, rev-vdw-df2, etc.)
```

## Known gotchas

1. **HGH PPs for heavy elements (Pb, Bi, Sn, Tl, etc.):** HGH often has minimal valence
   (e.g., Pb with 4 electrons instead of 14). Always check `z_valence` in the UPF header.
   If too low → use GBRV or PseudoDojo instead. This caused a 5-hour debugging session in batch 2.

2. **SSSP has no LDA PPs.** SSSP covers PBE and PBEsol only (v1.3).

3. **ecutrho matters more for US/PAW than NC.** NC needs 4× ecutwfc; US/PAW needs 8-12×.
   If the paper doesn't state ecutrho, use 8× for US/PAW, 4× for NC.

4. **SG15 FR naming is easy to miss:** `Si_ONCV_PBE_FR-1.1.upf` (note `_FR` suffix).
   Using the SR PP `Si_ONCV_PBE-1.2.upf` for an SOC calculation will silently give wrong results
   (no spin-orbit splitting) without any error message.

5. **PSLibrary PPs** come in many naming conventions depending on download source.
   The QMatSuite assets `ps-library-v1.0.0.tar.gz` has the full collection organized by XC/type.

6. **XSpectra PPs are NOT in any standard library.** They are bundled with QE source only.
   The `2pj` and core-hole variants must come from `XSpectra/examples/pseudo/` or be generated with ld1.x.

7. **GIPAW PPs are NOT in SSSP or standard PseudoDojo.** Use the dedicated `GIPAW_DavideCeresoli.zip`
   from assets, or generate with ld1.x using `lgipaw_reconstruction=.true.`.
