# QE Knowledge Base

Single source of truth for "what can QE do and how." All workflows verified on local QE 7.5.

## Quick References

- [Pseudopotential guide (MUST READ before choosing PPs)](PSEUDOPOTENTIALS.md)
- [All 87 executables with purposes and doc URLs](qe_executables.md)
- [QE parameter metadata (22 modules, 1000+ params)](metadata/README.md)
- [Workflow verification summary with physics checks](workflows/VERIFICATION_SUMMARY.md)
- [Analysis/plotting scripts](scripts/) — reusable Python scripts for all common outputs

## Analysis Scripts

Reusable Python scripts for extracting and plotting QE/Wannier90 results. All scripts accept input/output paths as arguments and produce publication-quality PNGs. Located in `knowledge/scripts/`.

| Script | What it plots | Input format | Verified on |
|--------|-------------|--------------|-------------|
| `plot_bands.py` | Electronic band structure | bands.x `.dat.gnu` | Si L-Γ-X-W-Γ |
| `plot_dos.py` | Total DOS + orbital PDOS | dos.x `.dat` + projwfc.x `.pdos_*` | Si s+p |
| `plot_phonon.py` | Phonon dispersion | matdyn.x `.freq.gp` (multi-column or 2-col) | Si 6 branches |
| `plot_epsilon.py` | Dielectric function ε₁+ε₂ | epsilon.x `epsr_*.dat` + `epsi_*.dat` | Si IPA |
| `plot_charge.py` | 2D slice of charge density or ELF | pp.x `.cube` | Si ρ and ELF |
| `plot_xspectra.py` | XANES spectrum | xspectra.x `xanes.dat` | Diamond C K-edge |
| `plot_work_function.py` | Planar-averaged potential + Φ | average.x `avg.dat` | Al(111) Φ=4.08 eV |
| `plot_wannier_bands.py` | Wannier-interpolated bands (optionally overlay QE) | wannier90 `*_band.dat` | Si sp3 |
| `plot_tddfpt.py` | TDDFPT optical absorption | turbo_spectrum.x `.plot_chi.dat` | CH4 spectrum |
| `plot_spin_dos.py` | Spin-resolved DOS (up/down + orbital) | dos.x + projwfc.x (nspin=2) | Fe BCC d-band splitting |
| `plot_fatbands.py` | Fat bands (orbital-projected) | projwfc.x k-resolved PDOS | Si s/p character |
| `plot_phonon_dos.py` | Phonon density of states | matdyn.x `.phdos` | Si phonon DOS |
| `plot_neb.py` | NEB energy path profile | neb.x `.path` | H₂+H barrier |
| `extract_bandgap.py` | Band gap, VBM, CBM extraction | pw.x SCF/NSCF output | Si |
| `extract_lattice.py` | Relaxed lattice from vc-relax | pw.x vc-relax output | Si a=3.87 Å |
| `plot_isosurface.py` | Charge/ELF isosurface contours (3 orthogonal slices) | pp.x `.cube` | Si ρ and ELF |
| `plot_wannier_comparison.py` | Bands + DOS overlay: QE vs Wannier90 | bands.x `.gnu` + W90 `_band.dat` + `dos.dat` | Si bands+DOS match |

Each script has a `__main__` block with a working example using the verified workflow data.
Usage: `python3 scripts/plot_bands.py` (runs the example), or import the function:
```python
from scripts.plot_bands import plot_bands
plot_bands('my_bands.dat.gnu', output_png='my_bands.png', efermi=5.0)
```

## Verified Workflows

Every workflow below has been run on local QE 7.5 with input files, output files, and physics verification.

| # | Workflow | Directory | Executables | System | Key Result |
|---|---------|-----------|-------------|--------|------------|
| 1 | SCF ground state | `workflows/scf/` | pw.x | Si | E = -19.193 Ry |
| 2 | Band structure | `workflows/bands/` | pw.x → pw.x(bands) → bands.x | Si | L-G-X-W-G path |
| 3 | DOS + PDOS | `workflows/dos_pdos/` | pw.x → pw.x(nscf) → dos.x + projwfc.x | Si | Total + orbital-projected DOS |
| 4 | Relaxation | `workflows/relax/` | pw.x(relax) | Si | Forces → 0 |
| 5 | Variable-cell relax | `workflows/vc_relax/` | pw.x(vc-relax) | Si | a → 5.43 Å |
| 6 | Phonon dispersion | `workflows/phonon_dispersion/` | pw.x → ph.x → q2r.x → matdyn.x | Si | Full dispersion + phonon DOS |
| 7 | Gamma phonon + IR | `workflows/gamma_phonon_ir/` | pw.x → ph.x(Gamma) → dynmat.x | AlN | 12 modes, IR intensities |
| 8 | Spin-polarized | `workflows/spin_polarized/` | pw.x(nspin=2) | Fe BCC | μ = 2.31 μ_B |
| 9 | SOC noncollinear | `workflows/soc/` | pw.x(noncolin+lspinorb) | Pt FCC | FR PPs required |
| 10 | DFT+U / Hubbard hp.x | `workflows/hubbard_hp/` | pw.x(+U) → hp.x | NiO | U = 7.5-10.6 eV |
| 11 | Wannier90 bands | `workflows/wannier90_bands/` | pw.x → pw.x(nscf) → wannier90.x -pp → pw2wannier90.x → wannier90.x | Si | 8 sp3 WFs, interpolated bands |
| 12 | Wannier90 AHC | `workflows/wannier90_berry/` | pw.x → pw.x(nscf) → wannier90.x → pw2wannier90.x → wannier90.x → postw90.x | Fe, Ni | AHC_z(Ni) ~ 2079 S/cm |
| 13 | Dielectric function | `workflows/epsilon_optical/` | pw.x → pw.x(nscf) → epsilon.x | Si | ε₁(0) = 17.2 (NC PPs only!) |
| 14 | TDDFPT absorption | `workflows/turbo_eels/` | pw.x → turbo_lanczos.x → turbo_spectrum.x | CH4 | Optical spectrum |
| 15 | XANES / XAS | `workflows/xspectra/` | pw.x → xspectra.x | Diamond | C K-edge spectrum |
| 16 | NEB transition state | `workflows/neb/` | neb.x | H₂+H | Barrier = 0.20 eV |
| 17 | Quantum transport | `workflows/pwcond/` | pw.x → pwcond.x | Al | Complex band structure |
| 18 | Charge density / ELF | `workflows/pp_charge_density/` | pw.x → pp.x | Si | .cube files |
| 19 | Work function | `workflows/work_function/` | pw.x(slab) → pp.x → average.x | Al(111) | Planar average |
| 20 | Equation of state | `workflows/eos/` | pw.x × N volumes → ev.x | Si | a₀=5.47Å, B=88.7 GPa |
| 21 | CP molecular dynamics | `workflows/cp_md/` | cp.x | Si | 50 damped-electron steps |
| 22 | Berry phase polarization | `workflows/berry_phase/` | pw.x(scf) → pw.x(nscf+lberry) | BaTiO₃ | P = -0.054 C/m² |
| 23 | DFT+U static | `workflows/dftu_static/` | pw.x(HUBBARD card) | NiO | μ = 1.86 μ_B with U=6 eV |
| 24 | Electric field | `workflows/efield/` | pw.x(lelfield) | Si | Forces from finite E-field |
| 25 | DFT-D3 van der Waals | `workflows/vdw_dftd3/` | pw.x(vdw_corr='dft-d3') | Graphite | ΔE = 85 meV/atom binding |
| 26 | HSE06 hybrid functional | `workflows/hybrid_hse/` | pw.x(input_dft='hse') | Si | NC PPs required; uses EXX q-mesh; **NSCF forbidden — use ADDITIONAL_K_POINTS or open_grid.x, see Gotcha #40** |
| 27 | Born-Oppenheimer MD | `workflows/bomd/` | pw.x(calculation='md') | Si 8-atom | T ~ 300 K with rescaling |
| 28 | MAE with SOC | `workflows/mae_soc/` | pw.x(noncolin+lspinorb, angle1/angle2) | FePt L1₀ | MAE = 1.43 meV/atom, [001] easy axis (lit 1-3) |
| 29 | Spin-resolved DOS | `workflows/spin_dos/` | pw.x(nspin=2) → dos.x + projwfc.x | Fe BCC | Exchange splitting, d-band visible |
| 30 | Fat bands | `workflows/fatbands/` | pw.x → pw.x(bands) → projwfc.x(kresolveddos) | Si | s/p orbital character along k-path |
| 31 | Elastic constants | `workflows/elastic_constants/` | pw.x(tstress) × 5 strains | Si | C11=162, C12=65, C44=105 GPa |
| 32 | STM image | `workflows/stm/` | pw.x → pp.x(plot_num=5) | Al slab | 2D LDOS at bias voltage |
| 33 | Band-decomposed charge | `workflows/band_charge/` | pw.x → pp.x(plot_num=7) | Si | Specific band charge density |
| 34 | NCI analysis | `workflows/nci/` | pw.x → pp.x(plot_num=20) | Si | Reduced density gradient |
| 35 | SOC band structure | `workflows/soc_bands/` | pw.x(noncolin+lspinorb) → bands.x | Pt FCC | SOC splitting at L and X |
| 36 | Fermi surface LDOS | `workflows/fermi_surface/` | pw.x → pw.x(nscf) → pp.x(plot_num=11) | Al | ILDOS near E_F |
| 37 | Charge isosurface | `workflows/pp_charge_density/` | pp.x → plot_isosurface.py | Si | ρ and ELF contour plots |

## Parameter Variations (not separately verified — use QE examples)

These capabilities differ from the above only in pw.x input parameters. Find examples in the QE tutorial directory (`knowledge/tutorials/qe-7.5-examples/PW/examples/`):

| Capability | Key Parameters | QE Example | Notes |
|-----------|---------------|------------|-------|
| DFT+U (static) | `lda_plus_u=.true.`, `HUBBARD` card | PW/example06 | See also HP example for self-consistent U |
| Hybrid functional (HSE06) | `input_dft='hse'`, `nqx1,nqx2,nqx3`, `x_gamma_extrapolation` | PW/example15, **PP/examples/exx_scf_bands_example/** | Uses PBE PPs; NC recommended; **NSCF/bands NOT supported** — see Gotcha #40 |
| DFT-D2/D3 vdW | `vdw_corr='dft-d3'` | PW/dftd3_example | vdW for molecular crystals |
| vdW-DF (nonlocal) | `input_dft='vdw-df'` | PW/vdw_example | Nonlocal vdW functional |
| ESM (slab/surface) | `assume_isolated='esm'` | PW/ESM_example | Electric field at surfaces |
| Metallic smearing | `occupations='smearing'`, `smearing='mv'`, `degauss` | spin_polarized/ | Already verified for Fe |
| Electric field | `lelfield=.true.`, `efield_cart` | PW/example04 (part 2) | Self-consistent E-field |
| Noncollinear magnetism | `noncolin=.true.`, `angle1`, `angle2` | PW/example10 | Without SOC |
| Constrained magnetization | `constrained_magnetization` | PW/example10 | Fix spin direction |
| Cluster/molecule | `assume_isolated='mt'` or big box | PW/cluster_example | Martyna-Tuckerman |
| Raman intensities | `lraman=.true.` in ph.x | PHonon/example01 | **NC PPs only** (USPP crashes) |
| Electron-phonon λ | `electron_phonon='interpolated'` in ph.x | PHonon/example03 | Superconducting Tc |
| Born-Oppenheimer MD | `calculation='md'` in pw.x | PW/example03 | verified: #27 |
| Phonon + SOC | `lspinorb=.true.` in pw.x before ph.x | PHonon/example06 | FR PPs required |
| STM image | `plot_num=5` in pp.x | PP/example04 | Tersoff-Hamann approximation |
| Band-decomposed charge | `plot_num=7`, `kpoint`, `kband` in pp.x | PP/example01 | Specific band at specific k |
| Fermi surface | pp.x `plot_num=0` + visualization, or projwfc.x | PP/example | Use VESTA or FermiSurfer |
| Spin Hall conductivity | postw90.x `berry_task=shc` | W90/tutorial29 | SOC + spinors required |
| Shift current | postw90.x `berry_task=sc` | W90/tutorial17 | Nonlinear optical |
| Orbital magnetization | postw90.x `berry_task=morb` | W90 docs | Requires SOC |
| Boltzmann transport | postw90.x `boltz_*` keywords | W90/tutorial17 | Semiclassical σ(T) |
| Wannier DOS | postw90.x `dos=true` | W90/tutorial11 | Interpolated DOS |
| Wannier Fermi surface | postw90.x `fermi_surface_plot=true` | W90/tutorial06 | Metal Fermi surface |
| EPW electron-phonon | epw.x | EPW/diamond, EPW/pb | Tc, λ, resistivity, phonon linewidths |
| Koopmans functional | kcw.x + kcwpp_interp.x | KCW/example01 | Accurate band gaps beyond DFT |
| GW quasiparticle | pw4gww.x → gww.x | GWW/example01 | QP band gaps |
| BSE optical | bse_main.x | GWW/example03 | Excitonic spectra |
| EELS | turbo_eels.x → turbo_spectrum.x | TDDFPT/example | Plasmons, charge-fluctuation excitations |
| Magnon / spin-wave spectra | turbo_magnon.x → turbo_spectrum.x | TDDFPT/example | Inelastic neutron scattering |
| Thermodynamics from phonons | matdyn.x (dos=.true.) | phonon_dispersion/ | Free energy, heat capacity, entropy (harmonic) |
| Electro-optic tensor | ph.x (epsil=.true.) | PHonon/example01 | Nonlinear optical response |
| Piezoelectric tensor | ph.x (epsil=.true., piezo) | PHonon docs | Born charges → piezoelectric constants |
| Temperature-dependent bands | postahc.x | QE docs | Allen-Heine-Cardona e-ph renormalization |
| Core-level shifts | initial_state.x | PP/CLS_IS_example | Initial-state XPS shifts |
| NCI analysis | pp.x (plot_num=19,20) | PP docs | Noncovalent interaction visualization |
| Kinetic energy density | pp.x (plot_num=22) | PP docs | For meta-GGA analysis |
| ESM electrochemistry | pw.x (assume_isolated='esm') | PW/ESM_example | Slab with applied bias |
| 3D-RISM solvation | rism1d.x → pw.x (trism=.true.) | QE docs | Implicit solvent |
| Thermal conductivity | all_currents.x (QEHeat) + CP-MD | QEHeat docs | Green-Kubo heat current |
| Gyrotropic properties | postw90.x (gyrotropic module) | W90 docs | Berry curvature dipole, natural optical activity |
| Seebeck coefficient | postw90.x (BoltzWann) | W90/tutorial17 | Thermoelectric power |
| Electronic thermal conductivity | postw90.x (BoltzWann) | W90/tutorial17 | κ_e(T) |
| EPW superconducting Tc | epw.x (Eliashberg equations) | EPW/pb | Anisotropic gap, λ, α²F |
| EPW carrier mobility | epw.x (IBTE/SERTA) | EPW docs | Electron/hole mobility vs T |
| EPW phonon-assisted optics | epw.x | EPW docs | Indirect absorption, temperature-dependent |
| EPW polarons | epw.x (polaron module) | EPW docs | Small/large polarons without supercells |
| Band unfolding | bands_unfold.x (EPW ZG) | EPW/ZG docs | Supercell → primitive zone |
| Phonon diffuse scattering | disca.x (EPW ZG) | EPW/ZG docs | Thermal diffuse X-ray scattering |

**To search for parameter examples:**

1. Search parameter name in `knowledge/metadata/qe_module_parameters.json` to confirm it exists and which namelist it belongs to
2. Search `knowledge/tutorials/qe-7.5-examples/` for usage: `grep -r "parameter_name" tutorials/`
3. Check the QE doc URL in `qe_executables.md` for the relevant executable

## Wannier90 Tutorials

37 tutorials in `knowledge/tutorials/wannier90-examples/tutorials/`. Key QE+Wannier90 ones:

| Tutorial | System | What it does |
|----------|--------|-------------|
| tutorial05 | Diamond | Basic QE+W90: SCF → NSCF → W90 bands |
| tutorial06 | Copper | Metal Wannierization with disentanglement |
| tutorial07 | Silane | Molecular WFs |
| tutorial08 | Iron | SOC + spinor Wannier functions |
| tutorial11 | Silicon | Wannier + postw90 (DOS, Fermi surface) |
| tutorial17 | Gallium arsenide | Berry phase, shift current |
| tutorial29 | Lead | SOC Wannier with symmetry |

## What QE CAN Do (that agents sometimes think it can't)

Based on batch 3 analysis, agents incorrectly skipped these. **Before claiming "QE cannot do X", check this list.**

### Verified in this knowledge base (with working input files)
| Capability | QE Tool | Workflow # |
|-----------|---------|-----------|
| XAS / XANES (K-edge, L-edge) | xspectra.x | #15 |
| Quantum transport / conductance | pwcond.x | #17 |
| NEB / transition states / reaction barriers | neb.x | #16 |
| Self-consistent Hubbard U and V | hp.x | #10 |
| Berry phase / spontaneous polarization | pw.x (lberry) | #22 |
| Anomalous Hall conductivity (AHC) | postw90.x (berry_task=ahc) | #12 |
| Optical absorption (TDDFPT) | turbo_lanczos.x | #14 |
| Car-Parrinello MD | cp.x | #21 |
| Born-Oppenheimer MD | pw.x (calculation='md') | #27 |
| Wannier band interpolation | wannier90.x | #11 |
| Magnetic anisotropy energy (MAE) | pw.x (SOC + angle1/angle2) | #28 |
| Hybrid functional (HSE06) | pw.x (input_dft='hse') + ADDITIONAL_K_POINTS or open_grid.x | #26 — **NSCF/bands forbidden; see Gotcha #40** |
| van der Waals DFT-D3 | pw.x (vdw_corr='dft-d3') | #25 |
| DFT+U (static Hubbard U) | pw.x (HUBBARD card) | #23 |
| Dielectric function (IPA) | epsilon.x | #13 |
| Electric field / dielectric constant | pw.x (lelfield) | #24 |

### Available but not separately verified (use QE/W90 examples)
| Capability | QE Tool | Where to find examples |
|-----------|---------|----------------------|
| EELS / inelastic X-ray scattering | turbo_eels.x | TDDFPT/examples |
| Magnon / spin-wave dispersion | turbo_magnon.x | TDDFPT/examples |
| GW quasiparticle energies | pw4gww.x → gww.x | GWW/examples |
| BSE excitonic optical spectra | bse_main.x | GWW/examples |
| Koopmans functional band gaps | kcw.x + kcwpp_interp.x | KCW/examples |
| EPW: superconducting Tc, λ, α²F | epw.x (Eliashberg) | EPW/pb |
| EPW: carrier mobility vs T | epw.x (IBTE/SERTA) | EPW docs |
| EPW: phonon-assisted indirect absorption | epw.x | EPW docs |
| EPW: polarons (small and large) | epw.x (polaron module) | EPW docs |
| Spin Hall conductivity (SHC) | postw90.x (berry_task=shc) | W90/tutorial29 |
| Shift current (nonlinear optical) | postw90.x (berry_task=sc) | W90/tutorial17 |
| Orbital magnetization | postw90.x (berry_task=morb) | W90 docs |
| Kubo-Greenwood optical conductivity | postw90.x (berry_task=kubo) | W90 docs |
| Boltzmann transport: σ, S, κ_e | postw90.x (BoltzWann) | W90/tutorial17 |
| Gyrotropic: Berry curvature dipole, natural optical activity | postw90.x (gyrotropic module) | W90 docs |
| Wannier DOS, Fermi surface | postw90.x | W90/tutorial11, tutorial06 |
| Raman intensities | ph.x (lraman=.true.) | PHonon/example01 (NC PPs only!) |
| Electron-phonon coupling λ | ph.x (electron_phonon) | PHonon/example03 |
| Phonon thermodynamics (F, Cv, S) | matdyn.x (dos=.true.) | phonon_dispersion/ |
| Electro-optic tensor | ph.x (epsil=.true.) | PHonon/example01 |
| Piezoelectric tensor | ph.x | PHonon docs |
| Temperature-dependent bands (AHC) | postahc.x | QE docs |
| Anharmonic phonon lifetimes | d3hess.x | QE/D3Q |
| Thermal conductivity (Green-Kubo) | all_currents.x (QEHeat) | QEHeat docs |
| NMR chemical shifts | QE-GIPAW | qe-gipaw, GIPAW PPs required |
| EPR g-tensor | QE-GIPAW | qe-gipaw |
| Core-level shifts (XPS) | initial_state.x | PP/CLS_IS_example |
| STM images | pp.x (plot_num=5) | PP/example04 |
| Band-decomposed charge | pp.x (plot_num=7) | PP/example01 |
| NCI analysis | pp.x (plot_num=19,20) | PP docs |
| Kinetic energy density | pp.x (plot_num=22) | PP docs |
| ESM electrochemistry | pw.x (assume_isolated='esm') | PW/ESM_example |
| 3D-RISM implicit solvation | rism1d.x + pw.x (trism) | QE docs |
| Band unfolding | bands_unfold.x (EPW ZG) | EPW docs |
| Phonon diffuse scattering | disca.x (EPW ZG) | EPW docs |

## What QE CANNOT Do

Use external codes for these:

| Capability | External Code | Notes |
|-----------|--------------|-------|
| GW (production) | Yambo, BerkeleyGW | QE's gww.x works but Yambo/BGW are standard |
| DMFT | TRIQS, w2dynamics | Dynamical mean-field theory |
| Phase-space integration | BoltzTraP2 | Boltzmann transport (semiclassical) |
| NEGF transport | TranSIESTA, QuantumATK | Non-equilibrium Green's function |
| Machine learning potentials | LAMMPS + ML | Not DFT |
| Large-scale MD (>1000 atoms) | LAMMPS, VASP | QE scales to ~100-200 atoms |

## Special PP Requirements by Workflow

See [PSEUDOPOTENTIALS.md](PSEUDOPOTENTIALS.md) for full decision tree, download URLs, and special PP sources.

| Workflow | PP Requirement | Available Locally? | Where to Get |
|----------|---------------|-------------------|-------------|
| epsilon.x, turbo_*.x | NC only (no USPP) | SG15, PseudoDojo NC | Local |
| SOC (lspinorb) | Fully relativistic (FR) | PseudoDojo nc-fr, SG15 FR | Local |
| XSpectra | TM PPs + core-hole PP | In `workflows/xspectra/pseudo/` | QE source; generate with ld1.x |
| GW (gww.x, pw4gww.x) | NC only | SG15, PseudoDojo NC | Local |
| EPW | NC only | SG15, PseudoDojo NC | Local |
| KCW | NC only | PseudoDojo NC | Local |
| Berry phase (lberry) | Any (NC, US, PAW) | All local libraries | — |
| GIPAW (NMR) | PPs with GIPAW reconstruction | Download from assets | `GIPAW_DavideCeresoli.zip` in QMatSuite assets |

## Common QE Gotchas

These are hard-won lessons from running 55+ papers and 24 verified workflows. Every item below caused real debugging time (hours, not minutes).

### Input file syntax

1. **NEVER put comments (`!` lines) inside ATOMIC_POSITIONS, K_POINTS, or CELL_PARAMETERS cards.**
   QE will crash with "Bad real number" — extremely confusing error message.

2. **`diago_david_ndim` goes in `&ELECTRONS`, not `&SYSTEM`.** Wrong namelist → silently ignored.

3. **`efield_cart` goes in `&ELECTRONS`, not `&CONTROL`.** Putting it in &CONTROL gives "bad line in namelist" error. This is counterintuitive but confirmed by QE source.

4. **DFT+U: Use the `HUBBARD {ortho-atomic}` card (QE 7.x syntax).**
   ```
   HUBBARD ortho-atomic
   U Ni-3d 6.0
   ```
   The old `lda_plus_u=.true.` + `Hubbard_U(i)` syntax still works but is deprecated.

5. **ALWAYS use `ibrav=0` with explicit `CELL_PARAMETERS`.** Never `ibrav=1,2,3,...`.
   ibrav coordinate conventions are confusing and caused 23K characters of debugging in batch 2.

### Berry phase / polarization

6. **`lberry` requires `calculation='nscf'`, NOT `'scf'`.**
   With `calculation='scf'`, QE silently ignores lberry — no error, no polarization output.
   Correct workflow: SCF first → NSCF with `lberry=.true.`, `gdir=N`, `nppstr=M`.
   The k-grid along the berry direction must equal nppstr (e.g., `4 4 7` for gdir=3, nppstr=7).
   USPP works fine with lberry despite old docs claiming NC-only.

### Wannier90

7. **NSCF k-points for Wannier90 must be explicit `K_POINTS crystal`**, NOT `K_POINTS automatic`.
   The k-point list must be the full uniform grid matching `mp_grid` in the .win file.
   `K_POINTS automatic` causes pw2wannier90.x to crash with "k-points mismatch".

8. **Wannier90 lattice in `.win` must match QE exactly.** Copy CELL_PARAMETERS values verbatim with the same units. Even tiny rounding differences cause "Direct lattice mismatch" error.

9. **`postw90.x` berry settings require the correct `fermi_energy`.** Extract from SCF output:
   `grep "Fermi energy" scf.out`. Wrong Fermi energy → AHC off by orders of magnitude.

### XSpectra

10. **XSpectra needs a core wavefunction file.** Generate it with:
    `$QE_ROOT/XSpectra/tools/upf2plotcore.sh PP.UPF > element.wfc`
    The core-hole PP (`Ch_*`) is different from the ground-state PP (`C_*`).

### Pseudopotentials

11. **"S matrix not positive definite"** → ecutwfc too low. Increase by 50-100%.

12. **ecutrho: 8× ecutwfc for ultrasoft/PAW, 4× for NC** (if not stated in paper).

13. **epsilon.x does NOT support USPP.** Will crash with "USPP are not implemented". Use NC PPs (SG15 or PseudoDojo).

14. **HGH PPs for heavy elements** often have minimal valence (e.g., Pb with 4 electrons instead of 14). Always check `z_valence` in the UPF header.

15. **SG15 FR naming is easy to miss:** `Si_ONCV_PBE_FR-1.1.upf` (note the `_FR`). Using SR PP for SOC calculation silently gives wrong results with no error.

16. **Never mix PAW and US PPs** in the same calculation. QE will crash.

17. **Raman intensities (`lraman=.true.`) require NC PPs.** USPP crashes with "phonon code with US-PP and raman not yet available". Use SG15 or PseudoDojo NC.

### Magnetic / SOC calculations

18. **`starting_magnetization` must be set in BOTH SCF and NSCF for magnetic SOC.** NSCF re-initializes wavefunctions. Without `starting_magnetization`, the NSCF may start from a non-magnetic state and never correct itself (it's non-self-consistent). This silently produces zero magnetization and wrong Berry curvature / AHC.

19. **SOC requires fully-relativistic (FR) pseudopotentials.** Scalar-relativistic PPs silently give wrong results — no error message, just missing spin-orbit splitting.

20. **Noncollinear+SOC+Hubbard SCF typically plateaus at ~5-10×10⁻⁸ Ry accuracy. ALWAYS start with conv_thr = 1e-7 Ry, which is hard lesson learned by multiple agents and you MUST respect. Anything conv_thr lower than 5×10⁻⁸ Ry risk failure of convergence, so you should only try when there is evidence showing tighter SCF is required, before which you should always first run conv_thr = 1e-7 Ry, which most probably works.** regardless of conv_thr setting. Setting conv_thr tighter than this plateau wastes hours. If accuracy oscillates at a constant level for **>10** iterations, the calculation might have reached its numerical floor — kill and rerun with looser convergence. But only do this if you see exactly same number or oscillating multiple times. Do not draw conclusion too soon: it might just be converging slowly. If there is convergence problem, decreasing mixing_beta is a good way to try. **Start with mixing_beta = 0.2 or 0.3 for noncollinear+SOC+Hubbard SCF.**

### Wannier90 + Berry curvature / AHC

21. **Frozen window orbital character rule.**
    Before writing `.win`, check the pseudopotential file header for each element to identify ALL valence orbitals (e.g., `5s2 5p4` for Te, `6s2 6p3` for Bi). Compare against your `begin projections` block. Any orbital in the PP valence but NOT in your projections will produce DFT bands that must be excluded from the frozen window — either by raising `dis_froz_min` above them or by using `exclude_bands`. If these non-projection bands enter the frozen window, disentanglement is forced to absorb wrong-character states into your Wannier manifold. Occupied states are generally more important than unoccupied states in this regard. Quantities that integrate over all occupied states (orbital magnetization, orbital Hall) are severely affected; quantities that depend mainly on Fermi-surface topology (AHC) are more robust but not immune. Example: in Bi₂Se₃ with Bi:p + Se:p projections, the Bi-6s and Se-4s bands sit in the deep valence and must be excluded — this is standard practice in Wannier calculations. **When determining exclusion of bands, analyze the eigenstates in ALL k-points rather than just Gamma point.**

22. **`dis_froz_max` ceiling: number of frozen bands should stay below num_wann at every k.**
    Wannier90 will error if at any k-point, the frozen band count is larger than num_wann. But silent problem might happen if at some k-points, the frozen band count equals num_wann, because disentanglement has zero freedom — the Wannier manifold is forced to absorb those specific bands regardless of character. This is the "locked-k" regime. For band-interpolation uses (transport, DOS), a small locked fraction may be ok. For Berry-observable production (m_orb, AHC, SHC, polarization, optical/shift current), the locked-k fraction should be zero — any nonzero value might produce silent gauge discontinuity that corrupts Berry quantities while leaving band interpolation visually clean. Compute locked fraction from ndimwin in .chk or .wout; consider rejecting recipes with nonzero locked-k for Berry-observable use. 
    
    A single dfroz value is NEVER sufficient justification for m_orb, AHC, SHC, optical/shift current, or any Berry-curvature-derived observable. Scan dfroz within the range and verify a plateau: ideally, a contiguous range where the target observable is stable. But sometimes the plateau can be small or peaky, in which case ideally one should extend basis and num_wann, but many papers just live with imperfect plateau and try to converge other parameters choosing a dfroz where signal is clearest. Use your best judgement here. Independent of your decision, you MUST show dis_froz_max variance near the value you choose, which is important information about confidence.

23. **`dis_froz_max` floor: must be ABOVE the Fermi energy or CBM with some margin.**
    The frozen window should contain E_F so that all states near E_F are preserved exactly during disentanglement. Setting `dis_froz_max < E_F` lets disentanglement mix states near E_F, corrupting Berry curvature. Use E_F + 2 eV (for metal) or CBM+2eV (for insulator) as a starting point. (Wannier90 Tutorial 18 uses `dis_froz_max=30` for Fe with E_F≈17.7 eV.)

24. **Berry-observable quality is NOT implied by band interpolation quality.**
    Band distance η2, WF spread ratios, and visual DFT-vs-Wannier band agreement are zeroth-order checks on energy eigenvalues. Berry observables (m_orb, AHC, SHC, optical/shift current) depend on k-space derivatives of the Bloch manifold — first-order quantum-geometric properties of the gauge. Standard checks can pass while the gauge is (a) k-discontinuous due to locked-k points (Lesson 22), (b) symmetry-broken (Lesson 39), or (c) sublattice-symmetrized in altermagnets such that sublattice contributions cancel the observable to zero. For Berry-observable production like m_orb, a single converged dfroz recipe is never sufficient. Scan `dis_froz_max` across a meaningful range (bounded above by the num_wann energy ceiling from NSCF and by the character coverage of your basis) and require a plateau: a contiguous range where physical quantities are all approximately stable. No plateau indicates basis insufficient; consider returning to projection choice and extend. Again, many paper just live with this and only report best value, but you should always do such scan to inform yourself, and decide whether to expand basis judging from the plateau or peak behavior.

25. **Consider `num_iter = 0` (projection-only, no MLWF spread minimization).** The default Wannier90 behavior is to do disentanglement, then run MLWF minimization (`num_iter > 0`) to minimize total spread. For Berry observables, MLWF minimization should not have any effect although it can rotate the gauge away from the atomic-orbital character defined by projections and land in a gauge that cancels the target observable (although theoretically it should not). Running `num_iter = 0` keeps the gauge fixed at the projected atomic basis (after disentanglement), preserving orbital character at the cost of slightly larger spreads. Keep this option in mind if you run into problems.

26. **Semicore bands contaminate Wannier disentanglement.** For elements with semicore states (e.g., Ni with SG15 FR: 3s/3p at -83 to -42 eV), set `dis_win_min` above the semicore bands (e.g., `dis_win_min=5` eV). Without this, semicore bands consume Wannier functions that should represent valence/conduction states.

27. **Never use `exclude_bands` in pw2wannier90.** It causes eigenvalue index mismatch with Wannier90. Use Wannier90 energy windows (`dis_win_min/max`, `dis_froz_min/max`) instead.

28. **Adaptive Berry mesh refinement is essential for converged AHC/SHC.**
    Berry curvature has delta-function-like spikes at avoided crossings that uniform meshes converge extremely slowly on. Always use adaptive refinement:
    - **postw90.x:** set `berry_curv_adpt_kmesh = 5` and
      `berry_curv_adpt_kmesh_thresh = 100`.
    - **WannierBerri:** set `adpt_num_iter = 5` (or more) in `wberri.run()`.
      WannierBerri's adaptive refinement is automatic (no threshold needed)
      and recursive. `adpt_num_iter=0` means NO adaptive refinement — never
      use this for production AHC.
    Without adaptive refinement, even 300³ uniform meshes can show 50-100%
    drift between mesh sizes and noisy, oscillating σ(E) curves for systems
    with sharp Berry curvature features.

29. **Off-diagonal AHC components are a Wannier quality diagnostic, not just a k-mesh diagnostic.**
    For systems where symmetry forbids certain σ_ij components, large forbidden components indicate a problem. **First check Wannier band interpolation quality** (plot Wannier bands vs DFT bands along a high-symmetry path). If bands don't match, no amount of Berry mesh refinement will fix the AHC — the Wannier Hamiltonian itself is wrong. Only after confirming good band interpolation should you increase the Berry k-mesh.

30. **Spinor doubling: `num_wann = 2 × N_orbitals` for SOC.** With SOC, each orbital projection produces two Wannier functions (spin-up/down spinor). For Ni s;p;d: (1+3+5)×2 = 18 WFs.

31. **Always compare Wannier-interpolated bands to DFT bands before computing any derived quantity (AHC, SHC, orbital magnetization, etc.).** This is the single most important Wannier diagnostic and community standard practice. Compare along nscf kmesh or plot both along a high-symmetry path. If Wannier bands deviate from DFT bands by >50 meV near E_F, any Berry-curvature-derived quantity is unreliable. Fix the Wannier fitting first before proceeding.

32. **DFT k-mesh for Wannier fitting ≠ Berry k-mesh for derived quantities.** Two different k-meshes matter: (1) the DFT NSCF k-mesh that generates input for Wannier90 — determines Wannier function quality; (2) the interpolation mesh for Berry curvature or other post-processing — determines BZ sampling. Increasing (2) cannot compensate for a poor (1). For noncollinear+SOC calculations, the DFT k-mesh typically needs to be significantly denser than for collinear calculations to achieve comparable Wannier quality.

33. **Minimal Wannier basis may fail for strongly hybridized systems.** When the target orbitals hybridize strongly with ligand states, a minimal-orbital basis can give diffuse WFs (a few with spreads 3-5× larger than others). Signs of trouble: Ω_total much larger than Ω_I, large spread variance across WFs, poor band interpolation near E_F. Remedies: extend the basis (add more orbital types), tune dis_win carefully, increase DFT k-mesh.

34. **WannierBerri memory scales as num_wann² × NKFFT³.** A 60³ grid with 18 WFs may use ~1 GB, but 80³ with 32 WFs can exceed 70 GB in serial mode. Before increasing grid size, estimate memory from a smaller run. If projected memory exceeds available RAM (OOM is very likely happen for any sensible research calculation if you use NKdiv=1), use block decomposition (`NKdiv > 1` in `Grid()`) which processes the BZ in independent blocks with bounded per-block memory. If running WannierBerri with Ray (`parallel=True`), set `OPENBLAS_NUM_THREADS=1` and `MKL_NUM_THREADS=1` before launching, otherwise each Ray worker spawns BLAS threads and the total thread count explodes.

35. **"Disentanglement convergence criteria not satisfied" = hard stop.** Do not ignore this warning in the `.wout` file. The Wannier functions are untrustworthy. Fix projections, windows, or k-mesh before proceeding.

36. **Ω_I vs Ω_total ratio.** Ω_I is the gauge-invariant lower bound on spread. If Ω_total > 2× Ω_I, the disentanglement is struggling — the outer window likely contains bands that don't belong. Narrow the window or add more WFs.

37. **WF centers must sit on atoms (for atomic-like projections).** If WF centers drift to interstitial positions or wrong atoms, the projections are incorrect. Check the Final State WF centres in `.wout` against your atomic positions.

38. **Set `transl_inv = True` in postw90.x for AHC/SHC.** The default is False, which degrades the position matrix accuracy and corrupts Berry curvature. WannierBerri defaults to True. When using postw90, always set this explicitly.

39. **WannierBerri: always call system.set_symmetry() and use symmetrize=True for AHC/SHC**. Standard Wannier90 MLWFs break crystal symmetry. Without explicit symmetrization, symmetry-forbidden AHC components (σ_yz, σ_zx) can be as large as or larger than the physical component. This is documented behavior, not a bug. Use system.set_symmetry(symmetry_gen=[...]) with the magnetic point group generators, then symmetrize=True in wberri.run(). Check: after symmetrization, forbidden components must vanish. After calculation, you MUST verify symmetry-forbidden AHC components being zero, or at least much smaller than signal in σ_xy, otherwise the physics in σ_xy is garbage.

### Hybrid functionals (HSE06, PBE0, B3LYP) — CRITICAL

40. **NEVER use `calculation='nscf'` or `calculation='bands'` with hybrid functionals.**
    This is a fundamental QE limitation, NOT a bug. The EXX README (`tutorials/qe-7.5-examples/PW/examples/EXX_example/README`) states explicitly:
    *"non-scf and band calculations are not presently implemented."*

    **What happens if you try:** QE will either crash with *"hybrid XC not allowed"* or
    silently attempt to compute the full Fock exchange for arbitrary k-points. This
    requires integrals over all (k+q) points that were never computed during SCF,
    causing the calculation to **hang indefinitely** — using 100% CPU, writing nothing
    to disk for hours, and never producing output. This cost a 4-hour debugging session.

    **The correct approaches for hybrid band structures:**

    **Method A: `ADDITIONAL_K_POINTS` card (simplest, QE 6.7+)**
    Add band-path k-points directly in the SCF input:
    ```
    K_POINTS automatic
      8 8 1 0 0 0
    ADDITIONAL_K_POINTS tpiba_b
      4
        gG 40
        M  40
        K  40
        gG  1
    ```
    Then run: `pw.x (SCF)` → `bands.x (lsym=.false.)` → `plotband.x`.
    Working example: `tutorials/qe-7.5-examples/PP/examples/exx_scf_bands_example/`
    Timing: ~9 min on 1 CPU for 2-atom Si with 72 band k-points and 2×2×2 EXX mesh.

    **Gotcha:** ACE (Adaptively Compressed Exchange) may crash with *"Cholesky failed
    in invchol"* when zero-weight k-points are present (GitLab issue #207). Fix: use
    `ace=.false.` in `&SYSTEM` (slower but correct), or set tiny non-zero weights.

    **Method B: `open_grid.x` → Wannier90 (best for interpolation)**
    Unfold the SCF k-grid and feed to Wannier90 for band interpolation:
    `pw.x (SCF, nbnd=N)` → `open_grid.x` → `wannier90.x -pp` →
    `pw2wannier90.x (prefix='<prefix>_open')` → `wannier90.x`
    Working example: `tutorials/qe-7.5-examples/PP/examples/W90_open_grid_example/`
    Key detail: pw2wannier90.x must use `prefix='<scf_prefix>_open'` (open_grid adds `_open`).

    **`open_grid.x` works correctly with SOC (`noncolin+lspinorb`).** Tested and
    validated: open_grid Wannier bands match NSCF-based Wannier bands to sub-meV
    accuracy. If Wannier-interpolated bands look wrong after using open_grid, the
    problem is almost certainly in your `_band.dat` parser (see Gotcha #46), energy
    windows, or projections — not in open_grid.x itself. This includes hybrid+SOC
    workflows.

    **Method C: `band_interpolation.x` (quick Fourier interpolation)**
    `pw.x (SCF on dense grid, nbnd=N)` → `band_interpolation.x`
    Working example: `tutorials/qe-7.5-examples/PP/examples/exx_interpolated_bands_example/`
    Less accurate than Wannier90 but much simpler.

41. **Hybrid SCF uses ACE by default — this is why it's fast.** ACE (Adaptively Compressed
    Exchange) projects the Fock operator onto a low-rank basis during SCF, making each
    iteration nearly as cheap as PBE. A 2-atom HSE06 SCF can finish in <1 second.
    But ACE projectors are ONLY valid at the SCF k-points. This is why NSCF at
    arbitrary k-points is fundamentally broken — there are no ACE projectors for those k-points.

42. **NC PPs are recommended for hybrid functionals.** USPP works but has additional approximations (smooth grid). PAW with hybrids is listed as *"not currently functional"* in the EXX README.

43. **The EXX q-mesh (`nqx1,nqx2,nqx3`) must be converged separately.** `nqx=1` often overestimates band gaps. Higher nqx dramatically increases cost because ADDITIONAL_K_POINTS generate (nqx)³ × N_bandpath additional EXX integrals.

44. **`nqx` must divide `nk` — QE silently overrides incompatible values.**
    The EXX q-mesh must be commensurate with the k-mesh: `nqx` must be a divisor of `nk` in each direction. If it is not, QE silently falls back to the nearest compatible value, preferring smaller meshes. **There is a bug in the warning logic** (`idx > 1` guard in `PW/src/exx_base.f90` line 302): the first fallback (e.g., nqx=3→2) prints **no warning at all**. Only the second and later fallbacks trigger the message `"EXX: WARNING: q-point mesh has been updated!"`.

    **Always verify** the actual q-mesh by checking `grep "EXX: q-point mesh" scf.out` —
    do not trust that your input was used.

    Valid nqx values for common k-grids (divisors of nk):
    - 6×6: nqx ∈ {1, 2, 3, 6}
    - 8×8: nqx ∈ {1, 2, 4, 8}
    - 10×10: nqx ∈ {1, 2, 5, 10}
    - 12×12: nqx ∈ {1, 2, 3, 4, 6, 12}
    - 14×14: nqx ∈ {1, 2, 7, 14}
    - 16×16: nqx ∈ {1, 2, 4, 8, 16}

    **This is especially important when testing convergence in nqx.** If two different nqx inputs give exactly the same energy, do not conclude convergence — check whether QE actually used different q-meshes. Identical results from "nqx=2" and "nqx=3" on a 14×14 grid means both were silently reduced to nqx=2.
    Source: `PW/src/exx_base.f90` lines 290–334.

45. **No disk writes during EXX computation is NORMAL.** During the EXX self-consistency loop, QE does NOT write intermediate results to `outdir`. The `tmp/` directory will appear empty for the entire calculation. Results are only written at the very end. Do not interpret an empty `tmp/` as a sign that the calculation is stuck — check CPU usage instead (`ps aux | grep pw.x`). If CPU is at 100%, EXX is computing.

46. **Wannier90 `_band.dat` parsing: detect band boundaries, don't assume them.**
    Bands are concatenated as `(k_distance, energy)` pairs with NO blank-line separators. The number of k-points per band depends on path definition and is not simply `total_lines / num_wann`. Find band boundaries by detecting k-path resets (`k[i+1] < k[i]`). **Sanity check:** if the k-path returns to its starting point (e.g., G→...→G), the energies at the first and last k-point of each band must agree exactly. A mismatch means the parser is wrong, not the data. Do not blame upstream tools (open_grid.x, pw2wannier90, etc.) before verifying your own parsing.

### General workflow wisdom

47. **Cross-material knowledge: extract principles, not parameters.** Workflow lessons (use FR PPs, use explicit k-points, use energy windows) transfer across materials. Numerical parameters (dis_froz_max value, fermi_energy, ecutwfc) are system-specific and must be re-derived for each system.
