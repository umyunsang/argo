# Quarto 편집 원본

`thesis-ko.qmd`를 편집한 뒤 이 디렉터리에서 실행한다.

```sh
quarto render thesis-ko.qmd --to typst --no-execute
```

검증 도구: Quarto 1.10.18, Pandoc 3.10, Typst 0.15.1. 결과는 `thesis-template-20260905.pdf`이다. `.typ` 생성 파일이나 PDF를 직접 수정하지 않는다. AppleMyungjo, Times New Roman, Arial 글꼴이 필요하며 글꼴 파일은 포함하지 않는다. 다른 글꼴을 쓰면 조판을 다시 점검한다.

- `thesis-template.typ`: A4 1단과 조판 규칙.
- `thesis-template.csl`: 인용·참고문헌 표시 규칙.
- `references-current-evidence.bib`: 보존된 기존 서지 원자료.
- `references-template.bib`: 제목의 표시용 sentence case 사본. 저자 등 사실 정보는 유지한다.
- `figures/current-evidence-20260905/*.svg`: 세 개의 흑백 벡터 시스템 그림. 링크가 아닌 실제 파일을 포함한다.

측정 기준 시점은 2026년 9월 5일 05:13:55 KST이다. 추가 실험 없이 현재 근거만 작성한 원고이며, 96회 지정 입력 검사를 에이전트 성공률로 해석하지 않는다.

제공 양식의 `최소 10매 ... 이내`는 상충하고, 장당 약 1,000자의 계산·허용 범위도 불명확하다. 17쪽 PDF의 분량 충족을 단정하지 않는다. 한글/Word 작성 문구와 달리 사용자의 명시 지시대로 Quarto를 사용했다. HWP/DOCX 제출 필요 여부와 정확한 분량 기준은 학과 확인 사항이다.

이 폴더는 판본 사본이다. 저장소에서 계속 편집할 때의 기준 원고는 `paper/manuscript/thesis-ko.qmd`이며, 이전 2단판은 별도로 보존한다.
